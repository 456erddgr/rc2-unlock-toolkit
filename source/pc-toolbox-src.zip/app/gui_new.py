# -*- coding: utf-8 -*-
"""
RC2 搞机工具箱 - 苹果风格无边框界面
作者：软糖布丁

视觉：无边框自绘窗口 + 圆角 + 液态玻璃分层 + 平滑动效 + 高清 DPI
"""

import os
import sys
import time
import threading
import tkinter as tk
from tkinter import filedialog, messagebox

import theme as T
import engine as E
import features as F
from widgets import Card, AButton, StatBox, ProgressBar, draw_rr

APP_NAME = "RC2 搞机工具箱"
APP_VER = "3.1"
AUTHOR = "软糖布丁"

PAGES = [
    ("overview", "总览"),
    ("perf", "性能"),
    ("memory", "内存/虚拟内存"),
    ("fan", "风扇/温度"),
    ("root", "Root/模块"),
    ("apps", "应用管理"),
    ("backup", "分区备份"),
    ("flash", "刷机/恢复"),
    ("screen", "投屏/截图"),
    ("tools", "实用工具"),
    ("about", "关于/免责"),
]


DISCLAIMER = """【重要提示 · 请务必阅读】

本软件（RC2 搞机工具箱）是给 DJI RC2 遥控器（rc331 / Android 11）使用的第三方工具，
作者：软糖布丁。它不是大疆官方软件，也未获得大疆任何授权或认可。

本软件会通过 adb/root 直接修改设备底层参数，包括但不限于：
  • CPU / GPU 频率与调度策略、温控开关
  • 虚拟内存（zram / 磁盘 swap）
  • 系统属性、Magisk 模块
  • 分区镜像（备份 / 刷回）

使用本软件可能导致的后果：
  1. 设备过热、卡死、自动重启
  2. 系统无法启动（变砖）、屏幕黑屏
  3. 数据丢失（分区刷写错误不可恢复）
  4. 官方保修失效

作者不对任何数据丢失、设备损坏、保修失效承担责任。
请务必在操作前自行备份重要数据，并确认你了解自己在做什么。

★ 绝对不要做的事：
  • 不要 unexport pwmchip0（那是屏幕背光，会导致黑屏）
  • 不要关闭 zram 后不重新开启（会导致系统卡死）
  • 不要一口气 dd 写入超大文件（会挤爆内存触发重启）
  • 除 dji_apk 外的数据分区不要刷回（会显示"损坏"）

点「我已阅读并同意」表示你已理解并自愿承担全部风险。
此同意只需一次，之后不再询问。
"""


class App:
    def __init__(self, root):
        self.root = root
        self.cur = None
        self._drag = None
        self._resize_mode = None
        self._resize_start = None
        self._busy = False

        root.overrideredirect(True)
        root.configure(bg=T.BG)
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        w, h = min(1440, sw - 80), min(900, sh - 100)
        x, y = (sw - w) // 2, (sh - h) // 2 - 20
        root.geometry("%dx%d+%d+%d" % (w, h, x, y))
        root.minsize(1120, 720)

        self._build_window()
        self._bind_window_events()
        self.show("overview")
        self._start_status_loop()
        self._fade_in()

    # ---------- 窗口骨架 ----------
    def _build_window(self):
        # 外层（用于圆角背景）
        self.shell = tk.Canvas(self.root, bg=T.BG, highlightthickness=0, bd=0)
        self.shell.pack(fill="both", expand=True)
        self.shell.bind("<Configure>", self._draw_shell)

        self.main = tk.Frame(self.shell, bg=T.BG3)
        self._main_win = None

        # 顶栏
        self.top = tk.Frame(self.main, bg=T.BG2, height=T.TOPBAR_H)
        self.top.pack(side="top", fill="x")
        self.top.pack_propagate(False)
        self._build_topbar()

        # 主体
        body = tk.Frame(self.main, bg=T.BG3)
        body.pack(side="top", fill="both", expand=True)

        self.side = tk.Frame(body, bg=T.BG2, width=T.SIDEBAR_W)
        self.side.pack(side="left", fill="y")
        self.side.pack_propagate(False)
        self._build_sidebar()

        right = tk.Frame(body, bg=T.BG3)
        right.pack(side="left", fill="both", expand=True)

        self.content = tk.Frame(right, bg=T.BG3)
        self.content.pack(side="top", fill="both", expand=True, padx=16, pady=(14, 8))

        self._build_console(right)

    def _draw_shell(self, e=None):
        w = self.shell.winfo_width()
        h = self.shell.winfo_height()
        if w < 20 or h < 20:
            return
        self.shell.delete("shell")
        draw_rr(self.shell, 0, 0, w, h, T.WIN_RADIUS, T.BG3,
                T.STROKE_HI, 1, tags="shell")
        if self._main_win is None:
            self._main_win = self.shell.create_window(
                T.WIN_RADIUS // 2, T.WIN_RADIUS // 2, anchor="nw",
                window=self.main,
                width=w - T.WIN_RADIUS, height=h - T.WIN_RADIUS)
        else:
            self.shell.itemconfig(self._main_win,
                                  width=w - T.WIN_RADIUS,
                                  height=h - T.WIN_RADIUS)

    def _build_topbar(self):
        left = tk.Frame(self.top, bg=T.BG2)
        left.pack(side="left", padx=(16, 0), pady=10)
        tk.Label(left, text="RC2", bg=T.BG2, fg=T.BLUE,
                 font=("Segoe UI", 16, "bold")).pack(side="left")
        tk.Label(left, text="搞机工具箱  v" + APP_VER, bg=T.BG2, fg=T.TXT2,
                 font=(T.FONT, 9)).pack(side="left", padx=(8, 0), pady=(5, 0))

        # 右侧窗口按钮
        btns = tk.Frame(self.top, bg=T.BG2)
        btns.pack(side="right", padx=(0, 10), pady=12)
        self._winbtn(btns, "—", T.YELLOW, self._minimize)
        self._winbtn(btns, "□", T.GREEN, self._toggle_max)
        self._winbtn(btns, "✕", T.RED, self._close, last=True)

        # 设备状态
        self.dev_label = tk.Label(self.top, text="● 未连接", bg=T.BG2, fg=T.RED,
                                  font=(T.FONT, 9, "bold"))
        self.dev_label.pack(side="right", padx=16)
        AButton(self.top, "刷新设备", self.refresh_device, T.CARD_HI,
                width=88, height=28, text_color=T.TXT,
                font_size=9).pack(side="right", pady=14)

    def _winbtn(self, parent, txt, color, cmd, last=False):
        f = tk.Frame(parent, bg=T.BG2)
        f.pack(side="left", padx=(0, 8 if not last else 0))
        c = tk.Canvas(f, width=13, height=13, bg=T.BG2, highlightthickness=0, bd=0)
        c.pack()
        circ = c.create_oval(0, 0, 12, 12, fill=color, outline=color)
        lbl = c.create_text(6, 6, text="", fill="", font=(T.FONT, 8, "bold"))
        def enter(_):
            c.itemconfig(circ, fill=T.lighten(color, 0.25))
            c.itemconfig(lbl, text=txt, fill=T.darken(color, 0.55))
        def leave(_):
            c.itemconfig(circ, fill=color)
            c.itemconfig(lbl, text="", fill="")
        c.bind("<Enter>", enter)
        c.bind("<Leave>", leave)
        c.bind("<Button-1>", lambda e: cmd())

    def _build_sidebar(self):
        tk.Frame(self.side, bg=T.BG2, height=6).pack()
        self.nav_items = {}
        for key, label in PAGES:
            self._nav_row(key, label)

    def _nav_row(self, key, label):
        f = tk.Frame(self.side, bg=T.BG2, cursor="hand2")
        f.pack(fill="x", padx=10, pady=1)
        bar = tk.Frame(f, bg=T.BG2, width=3)
        bar.pack(side="left", fill="y")
        lbl = tk.Label(f, text=label, bg=T.BG2, fg=T.TXT2,
                       font=(T.FONT, 10), anchor="w", padx=12, pady=7)
        lbl.pack(side="left", fill="x", expand=True)

        def enter(_):
            if self.cur != key:
                f.config(bg=T.CARD)
                lbl.config(bg=T.CARD, fg=T.TXT)

        def leave(_):
            if self.cur != key:
                f.config(bg=T.BG2)
                lbl.config(bg=T.BG2, fg=T.TXT2)

        def click(_):
            self.show(key)

        for w in (f, lbl):
            w.bind("<Enter>", enter)
            w.bind("<Leave>", leave)
            w.bind("<Button-1>", click)
        self.nav_items[key] = (f, lbl, bar)

    def _build_console(self, parent):
        wrap = tk.Frame(parent, bg=T.CARD, height=140)
        wrap.pack(side="bottom", fill="x", padx=16, pady=(0, 14))
        wrap.pack_propagate(False)
        head = tk.Frame(wrap, bg=T.CARD)
        head.pack(fill="x", padx=12, pady=(8, 0))
        tk.Label(head, text="运行日志", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 9, "bold")).pack(side="left")
        AButton(head, "复制", self._copy_log, T.CARD_HI, width=52, height=22,
                text_color=T.TXT2, font_size=8).pack(side="right", padx=3)
        AButton(head, "清空", self._clear_log, T.CARD_HI, width=52, height=22,
                text_color=T.TXT2, font_size=8).pack(side="right", padx=3)

        self.log_text = tk.Text(wrap, bg="#090b11", fg="#8fd18f", bd=0,
                                font=(T.FONT_MONO, 9), wrap="word",
                                insertbackground=T.TXT, height=5)
        self.log_text.pack(fill="both", expand=True, padx=12, pady=(6, 10))
        self.log_text.configure(state="disabled")
        for lv, col in (("info", "#8fd18f"), ("err", "#ff6b6b"),
                        ("warn", "#ffd166"), ("hdr", "#64d2ff"),
                        ("dim", "#7a8399"), ("ok", "#32d74b")):
            self.log_text.tag_config(lv, foreground=col)

    # ---------- 窗口拖拽 / 缩放 ----------
    def _bind_window_events(self):
        for w in (self.top, self.main):
            w.bind("<Button-1>", self._drag_start)
            w.bind("<B1-Motion>", self._drag_move)
        self.shell.bind("<Motion>", self._cursor_shape)
        self.shell.bind("<Button-1>", self._edge_press)
        self.shell.bind("<B1-Motion>", self._edge_move)
        self.shell.bind("<ButtonRelease-1>", self._edge_release)
        self.root.bind("<Escape>", lambda e: None)

    def _drag_start(self, e):
        if e.y_root - self.root.winfo_rooty() < T.TOPBAR_H:
            self._drag = (e.x_root - self.root.winfo_x(),
                          e.y_root - self.root.winfo_y())

    def _drag_move(self, e):
        if self._drag:
            self.root.geometry("+%d+%d" % (e.x_root - self._drag[0],
                                           e.y_root - self._drag[1]))

    def _cursor_shape(self, e):
        edge = 8
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        x, y = e.x, e.y
        cur = ""
        if x < edge or x > w - edge or y < edge or y > h - edge:
            cur = "sizing"
        self.shell.config(cursor=cur)

    def _edge_press(self, e):
        edge = 8
        w = self.root.winfo_width()
        h = self.root.winfo_height()
        m = None
        if e.y > h - edge:
            m = "s"
        elif e.y < edge:
            m = "n"
        elif e.x > w - edge:
            m = "e"
        elif e.x < edge:
            m = "w"
        if m:
            self._resize_mode = m
            self._resize_start = (e.x_root, e.y_root,
                                  self.root.winfo_width(),
                                  self.root.winfo_height(),
                                  self.root.winfo_x(),
                                  self.root.winfo_y())

    def _edge_move(self, e):
        if not self._resize_mode or not self._resize_start:
            return
        rx, ry, rw, rh, ox, oy = self._resize_start
        dx = e.x_root - rx
        dy = e.y_root - ry
        nw, nh, nx, ny = rw, rh, ox, oy
        if "e" in self._resize_mode:
            nw = max(1120, rw + dx)
        if "s" in self._resize_mode:
            nh = max(720, rh + dy)
        if "w" in self._resize_mode:
            nw = max(1120, rw - dx)
            nx = ox + (rw - nw)
        if "n" in self._resize_mode:
            nh = max(720, rh - dy)
            ny = oy + (rh - nh)
        self.root.geometry("%dx%d+%d+%d" % (nw, nh, nx, ny))

    def _edge_release(self, _):
        self._resize_mode = None
        self._resize_start = None

    def _minimize(self):
        try:
            self.root.overrideredirect(False)
            self.root.iconify()
        except Exception:
            pass

    def _toggle_max(self):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        if self.root.winfo_width() >= sw - 60:
            self.root.geometry("1280x820+%d+%d" % ((sw - 1280) // 2,
                                                   (sh - 820) // 2))
        else:
            self.root.geometry("%dx%d+0+0" % (sw, sh - 1))

    def _close(self):
        if messagebox.askyesno("退出", "确定退出 RC2 搞机工具箱？"):
            self.root.destroy()

    def _fade_in(self):
        """启动淡入动效"""
        try:
            self.root.attributes("-alpha", 0.0)
        except Exception:
            return
        def step(i, total=10):
            if i > total:
                try:
                    self.root.attributes("-alpha", 1.0)
                except Exception:
                    pass
                return
            try:
                self.root.attributes("-alpha", i / float(total))
            except Exception:
                return
            self.root.after(16, lambda: step(i + 1, total))
        step(1)

    # ---------- 导航 ----------
    def show(self, key):
        self.cur = key
        for k, (f, lbl, bar) in self.nav_items.items():
            if k == key:
                f.config(bg=T.CARD)
                lbl.config(bg=T.CARD, fg=T.TXT, font=(T.FONT, 10, "bold"))
                bar.config(bg=T.BLUE)
            else:
                f.config(bg=T.BG2)
                lbl.config(bg=T.BG2, fg=T.TXT2, font=(T.FONT, 10))
                bar.config(bg=T.BG2)
        for w in self.content.winfo_children():
            w.destroy()
        builder = {
            "overview": self.page_overview,
            "perf": self.page_perf,
            "memory": self.page_memory,
            "fan": self.page_fan,
            "root": self.page_root,
            "apps": self.page_apps,
            "backup": self.page_backup,
            "flash": self.page_flash,
            "screen": self.page_screen,
            "tools": self.page_tools,
            "about": self.page_about,
        }.get(key)
        if builder:
            try:
                builder()
            except Exception as e:
                self.log("页面加载失败: %s" % e, "err")

    # ---------- 日志 ----------
    def log(self, msg, level="info"):
        def do():
            try:
                ts = time.strftime("%H:%M:%S")
                self.log_text.configure(state="normal")
                self.log_text.insert("end", "[%s] %s\n" % (ts, msg), (level,))
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
            except Exception:
                pass
        try:
            self.root.after(0, do)
        except Exception:
            pass

    def _clear_log(self):
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

    def _copy_log(self):
        txt = self.log_text.get("1.0", "end").strip()
        self.root.clipboard_clear()
        self.root.clipboard_append(txt)
        self.log("已复制日志", "ok")

    def bg(self, fn, *a, **kw):
        def wrap():
            try:
                fn(*a, **kw)
            except Exception as e:
                self.log("任务异常: %s" % e, "err")
        t = threading.Thread(target=wrap, daemon=True)
        t.start()
        return t

    # ---------- 设备 ----------
    def refresh_device(self):
        def work():
            serial = E.device_serial()
            if serial:
                info = E.DeviceInfo()
                def upd():
                    self.dev_label.config(
                        text="● %s  %s" % (info.model, info.serial), fg=T.GREEN)
                self.root.after(0, upd)
                self.log("设备: %s | Android %s | %s | root=%s" % (
                    info.model, info.android, info.abi,
                    "是" if info.root else "否"), "hdr")
            else:
                def upd2():
                    self.dev_label.config(text="● 未连接", fg=T.RED)
                self.root.after(0, upd2)
                self.log("未检测到设备，请插 USB 并开启 USB 调试", "warn")
        self.bg(work)

    def _start_status_loop(self):
        def tick():
            try:
                if E.is_connected():
                    m = E.mem_info()
                    av = m["available"]
                    pct = int(av * 100 / m["total"]) if m["total"] else 0
                    if hasattr(self, "_mem_box") and self._mem_box.winfo_exists():
                        self._mem_box.set(E.kb_human(av),
                                          "%d%% 可用" % pct,
                                          T.GREEN if pct > 30 else T.ORANGE)
                    if hasattr(self, "_mem_bar") and self._mem_bar.winfo_exists():
                        self._mem_bar.set(1 - pct / 100.0,
                                          T.GREEN if pct > 30 else T.ORANGE)
                    if hasattr(self, "_cpu_lbl") and self._cpu_lbl.winfo_exists():
                        f = E.cpu_freq()
                        t = E.cpu_temp()
                        self._cpu_lbl.config(text="%s MHz   %s℃" % (
                            f or "-", t if t else "-"))
            except Exception:
                pass
            try:
                self.root.after(3000, tick)
            except Exception:
                pass
        try:
            self.root.after(900, tick)
        except Exception:
            pass
