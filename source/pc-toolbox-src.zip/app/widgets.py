# -*- coding: utf-8 -*-
"""RC2 搞机工具箱 - 苹果风格控件（圆角/动效/玻璃）"""

import math
import tkinter as tk
import theme as T


def rr_points(x1, y1, x2, y2, r, steps=8):
    r = max(0, min(r, (x2 - x1) // 2, (y2 - y1) // 2))
    pts = []
    corners = [
        (x2 - r, y1 + r, -90, 0),
        (x2 - r, y2 - r, 0, 90),
        (x1 + r, y2 - r, 90, 180),
        (x1 + r, y1 + r, 180, 270),
    ]
    for cx, cy, a0, a1 in corners:
        for i in range(steps + 1):
            ang = math.radians(a0 + (a1 - a0) * i / float(steps))
            pts.append(cx + r * math.cos(ang))
            pts.append(cy + r * math.sin(ang))
    return pts


def draw_rr(cv, x1, y1, x2, y2, r, fill, outline=None, width=1, tags=""):
    pts = rr_points(x1, y1, x2, y2, r)
    kw = {"fill": fill, "smooth": True, "tags": tags}
    if outline:
        kw["outline"] = outline
        kw["width"] = width
    else:
        kw["outline"] = fill
    return cv.create_polygon(pts, **kw)


class Card(tk.Frame):
    def __init__(self, master, title=None, padx=16, pady=14, **kw):
        bg = kw.pop("bg", T.CARD)
        tk.Frame.__init__(self, master, bg=bg, **kw)
        self.inner = tk.Frame(self, bg=bg)
        self.inner.pack(fill="both", expand=True, padx=padx, pady=pady)
        if title:
            tk.Label(self.inner, text=title, bg=bg, fg=T.TXT,
                     font=(T.FONT, 10, "bold"),
                     anchor="w").pack(fill="x", pady=(0, 8))


class AButton(tk.Canvas):
    """苹果风按钮：圆角 + 悬停高亮 + 按下偏移"""

    def __init__(self, master, text, command=None, color=T.BLUE,
                 width=140, height=36, text_color="#ffffff", font_size=10,
                 radius=None, bold=True):
        try:
            mbg = master["bg"]
        except Exception:
            mbg = T.CARD
        tk.Canvas.__init__(self, master, bg=mbg, highlightthickness=0, bd=0,
                           width=width, height=height)
        self._cmd = command
        self._base = color
        self._bw, self._bh = width, height
        self._text = text
        self._tcolor = text_color
        self._fsize = font_size
        self._bold = bold
        self._r = radius if radius is not None else T.RADIUS_SM
        self._enabled = True
        self._hovering = False
        self._draw(self._base)
        self.bind("<Button-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)

    def _draw(self, fill, offset=0):
        self.delete("all")
        draw_rr(self, 1, 1 + offset, self._bw - 1, self._bh - 1 + offset,
                self._r, fill)
        style = "bold" if self._bold else "normal"
        col = self._tcolor if self._enabled else T.TXT3
        self.create_text(self._bw // 2, self._bh // 2 + offset,
                         text=self._text, fill=col,
                         font=(T.FONT, self._fsize, style))

    def _on_press(self, _):
        if self._enabled:
            self._draw(T.darken(self._base, 0.18), 1)

    def _on_release(self, _):
        if not self._enabled:
            return
        if self._hovering:
            self._draw(T.lighten(self._base, 0.16))
        else:
            self._draw(self._base)
        if self._cmd:
            self._cmd()

    def _on_enter(self, _):
        self._hovering = True
        if self._enabled:
            self._draw(T.lighten(self._base, 0.16))

    def _on_leave(self, _):
        self._hovering = False
        if self._enabled:
            self._draw(self._base)

    def set_enabled(self, v):
        self._enabled = v
        self._draw(self._base if v else T.CARD_HI, 0)

    def set_text(self, t):
        self._text = t
        self._draw(T.lighten(self._base, 0.16) if self._hovering else self._base)


RoundedButton = AButton


class StatBox(tk.Frame):
    def __init__(self, master, label, value="-", sub="", color=T.TXT,
                 bg=None, width=132):
        self._bg = bg or T.CARD
        tk.Frame.__init__(self, master, bg=self._bg, width=width)
        self.pack_propagate(False)
        self.grid_propagate(False)
        tk.Label(self, text=label, bg=self._bg, fg=T.TXT2,
                 font=(T.FONT, 8), anchor="w").pack(fill="x")
        self.val = tk.Label(self, text=value, bg=self._bg, fg=color,
                            font=(T.FONT, 17, "bold"), anchor="w")
        self.val.pack(fill="x")
        self.sub = tk.Label(self, text=sub, bg=self._bg, fg=T.TXT3,
                            font=(T.FONT, 8), anchor="w")
        self.sub.pack(fill="x")

    def set(self, value, sub=None, color=None):
        self.val.config(text=str(value))
        if color:
            self.val.config(fg=color)
        if sub is not None:
            self.sub.config(text=sub)


StatTile = StatBox


class ProgressBar(tk.Canvas):
    def __init__(self, master, width=300, height=7, color=T.BLUE, bg=None):
        self._bg = bg or T.CARD
        tk.Canvas.__init__(self, master, width=width, height=height,
                           bg=self._bg, highlightthickness=0, bd=0)
        self._bw, self._bh = width, height
        self._color = color
        self._pct = 0.0
        self._draw()

    def _draw(self):
        self.delete("all")
        draw_rr(self, 0, 0, self._bw, self._bh, self._bh // 2, T.STROKE)
        fw = self._bw * max(0.0, min(1.0, self._pct))
        if fw > 3:
            draw_rr(self, 0, 0, fw, self._bh, self._bh // 2, self._color)

    def set(self, pct, color=None):
        self._pct = pct
        if color:
            self._color = color
        self._draw()


Bar = ProgressBar


def hsep(master, bg=T.CARD):
    f = tk.Frame(master, bg=T.STROKE, height=1)
    f.pack(fill="x", pady=6)
    return f
