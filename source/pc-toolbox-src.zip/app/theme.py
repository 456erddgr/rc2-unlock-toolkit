# -*- coding: utf-8 -*-
"""RC2 搞机工具箱 - 苹果风视觉系统（无边框 / 圆角 / 液态玻璃 / 动效）"""

# ===== 背景层次（深空渐变感）=====
BG        = "#0b0d12"   # 最外层
BG2       = "#101319"   # 顶栏/侧栏
BG3       = "#141821"   # 内容区底
CARD      = "#181d29"   # 卡片
CARD_HI   = "#202636"   # 卡片高亮/悬停
STROKE    = "#2b3244"   # 描边
STROKE_HI = "#3a4460"

# ===== 文字 =====
TXT       = "#f5f7fa"
TXT2      = "#9ba5bd"
TXT3      = "#5d6678"

# ===== 苹果系统色 =====
BLUE      = "#0a84ff"
PURPLE    = "#bf5af2"
GREEN     = "#32d74b"
ORANGE    = "#ff9f0a"
RED       = "#ff453a"
CYAN      = "#64d2ff"
PINK      = "#ff375f"
YELLOW    = "#ffd60a"
TEAL      = "#40c8e0"

# ===== 尺寸 =====
SIDEBAR_W = 208
TOPBAR_H  = 56
RADIUS    = 12
RADIUS_SM = 8
WIN_RADIUS = 14

# ===== 字体 =====
FONT      = "Microsoft YaHei UI"
FONT_MONO = "Consolas"


def lerp_color(c1, c2, t):
    """颜色插值，用于动画过渡"""
    t = max(0.0, min(1.0, t))
    h1 = c1.lstrip("#")
    h2 = c2.lstrip("#")
    r1, g1, b1 = (int(h1[i:i+2], 16) for i in (0, 2, 4))
    r2, g2, b2 = (int(h2[i:i+2], 16) for i in (0, 2, 4))
    r = int(r1 + (r2 - r1) * t)
    g = int(g1 + (g2 - g1) * t)
    b = int(b1 + (b2 - b1) * t)
    return "#%02x%02x%02x" % (r, g, b)


def lighten(c, amount):
    return lerp_color(c, "#ffffff", amount)


def darken(c, amount):
    return lerp_color(c, "#000000", amount)

