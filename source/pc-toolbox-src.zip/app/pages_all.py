    # ================= 总览（苹果风）=================
    def page_overview(self):
        wrap = tk.Frame(self.content, bg=T.BG3)
        wrap.pack(fill="both", expand=True)

        # 顶部大卡：设备 + 内存
        c1 = Card(wrap, "设备")
        c1.pack(fill="x", pady=(0, 10))
        top = tk.Frame(c1.inner, bg=T.CARD)
        top.pack(fill="x")

        self._ov_name = tk.Label(top, text="-", bg=T.CARD, fg=T.TXT,
                                 font=(T.FONT, 20, "bold"), anchor="w")
        self._ov_name.pack(anchor="w")
        self._ov_sub = tk.Label(top, text="-", bg=T.CARD, fg=T.TXT2,
                                font=(T.FONT, 9), anchor="w")
        self._ov_sub.pack(anchor="w", pady=(2, 0))

        # 内存条
        memrow = tk.Frame(c1.inner, bg=T.CARD)
        memrow.pack(fill="x", pady=(14, 0))
        self._mem_box = StatBox(memrow, "可用内存", "-", "", T.GREEN,
                                bg=T.CARD, width=170)
        self._mem_box.pack(side="left")
        right = tk.Frame(memrow, bg=T.CARD)
        right.pack(side="left", fill="x", expand=True, padx=(20, 0))
        self._mem_bar = ProgressBar(right, width=520, height=9, bg=T.CARD)
        self._mem_bar.pack(fill="x", pady=(10, 0))

        # 三块数据
        c2 = Card(wrap, "实时状态")
        c2.pack(fill="x", pady=(0, 10))
        row = tk.Frame(c2.inner, bg=T.CARD)
        row.pack(fill="x")
        self._cpu_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.CYAN,
                                 font=(T.FONT, 13, "bold"))
        self._cpu_lbl.pack(side="left")
        tk.Label(row, text="CPU", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 28))
        self._gpu_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.PURPLE,
                                 font=(T.FONT, 13, "bold"))
        self._gpu_lbl.pack(side="left")
        tk.Label(row, text="GPU", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 28))
        self._bat_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.GREEN,
                                 font=(T.FONT, 13, "bold"))
        self._bat_lbl.pack(side="left")
        tk.Label(row, text="电池", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 28))
        self._gov_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.ORANGE,
                                 font=(T.FONT, 13, "bold"))
        self._gov_lbl.pack(side="left")
        tk.Label(row, text="调度", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 0))

        # 快捷操作
        c3 = Card(wrap, "快捷操作")
        c3.pack(fill="x")
        acts = [("刷新数据", self._ov_refresh, T.BLUE),
                ("性能模式", lambda: self._perf_set("perf"), T.ORANGE),
                ("释放内存", self._drop_caches, T.GREEN),
                ("重启设备", self._reboot, T.RED)]
        brow = tk.Frame(c3.inner, bg=T.CARD)
        brow.pack(fill="x")
        for txt, cmd, col in acts:
            AButton(brow, txt, cmd, col, width=124, height=34).pack(
                side="left", padx=(0, 10))

        self._ov_refresh()

    def _ov_refresh(self):
        def work():
            info = E.DeviceInfo()
            m = E.mem_info()
            g = E.gpu_freq()
            b = E.battery()
            temp = E.cpu_temp()
            gov = E.cpu_governor()
            freq = E.cpu_freq()
            bat = b.get("capacity") or "-"
            st = b.get("status") or ""
            def upd():
                self._ov_name.config(text=info.model)
                self._ov_sub.config(text=("Android " + info.android +
                                         "  ·  " + info.abi +
                                         "  ·  " + info.serial +
                                         "  ·  " +
                                         ("已 Root" if info.root else "未 Root")))
                av = m["available"]
                pct = int(av * 100 / m["total"]) if m["total"] else 0
                col = T.GREEN if pct > 30 else (T.ORANGE if pct > 15 else T.RED)
                self._mem_box.set(E.kb_human(av),
                                  "共 " + E.kb_human(m["total"]), col)
                self._mem_bar.set(1 - pct / 100.0, col)
                c1 = (str(freq) + " MHz") if freq else "-"
                if temp:
                    c1 = c1 + "  " + str(temp) + chr(176) + "C"
                self._cpu_lbl.config(text=c1)
                self._gpu_lbl.config(text=(str(g) + " MHz") if g else "-")
                self._bat_lbl.config(text=str(bat) + "% " + st)
                self._gov_lbl.config(text=gov)
            self.root.after(0, upd)
            self.log("总览已刷新", "ok")
        self.bg(work)

    # ================= 页面：性能 =================
    def page_perf(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)

        c1 = Card(wrap, "CPU / GPU 状态")
        c1.pack(fill="x", pady=(0, 8))
        self._perf_grid = tk.Frame(c1.inner, bg=T.CARD)
        self._perf_grid.pack(fill="x")
        self._perf_labels = {}
        for i, name in enumerate(["调度策略", "小核上限", "大核上限",
                                  "超大核上限", "当前频率", "GPU 上限"]):
            f = tk.Frame(self._perf_grid, bg=T.CARD)
            f.grid(row=0, column=i, sticky="w", padx=(0, 22))
            tk.Label(f, text=name, bg=T.CARD, fg=T.TXT2,
                     font=(T.FONT, 8)).pack(anchor="w")
            v = tk.Label(f, text="-", bg=T.CARD, fg=T.CYAN,
                         font=(T.FONT, 10, "bold"))
            v.pack(anchor="w")
            self._perf_labels[name] = v

        c2 = Card(wrap, "性能模式（点一下就生效）")
        c2.pack(fill="x", pady=(0, 8))
        brow = tk.Frame(c2.inner, bg=T.CARD)
        brow.pack(fill="x")
        modes = [("省电", "save", T.GREEN, "schedutil + GPU 最低"),
                 ("均衡", "bal", T.BLUE, "schedutil + GPU 最高"),
                 ("性能", "perf", T.ORANGE, "performance + 三簇拉满"),
                 ("极速", "ext", T.RED, "拉满 + 解温控（会热）")]
        for label, key, col, tip in modes:
            box = tk.Frame(brow, bg=T.CARD)
            box.pack(side="left", padx=(0, 14))
            RoundedButton(box, label, lambda k=key: self._perf_set(k), col,
                          width=100, height=36).pack()
            tk.Label(box, text=tip, bg=T.CARD, fg=T.TXT3,
                     font=(T.FONT, 7)).pack(pady=(2, 0))

        c3 = Card(wrap, "说明")
        c3.pack(fill="x")
        tk.Label(c3.inner, text=(
            "• CPU 是三簇结构：小核 cpu0-3 / 大核 cpu4-6 / 超大核 cpu7\n"
            "• 极速模式会关闭温控保护，长时间使用请留意温度\n"
            "• 修改立即生效，重启后恢复系统默认（如需常驻请看「Root/模块」）"
        ), bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
            anchor="w").pack(fill="x")

        self._perf_refresh()

    def _perf_refresh(self):
        def work():
            d = F.current_perf()
            def upd():
                self._perf_labels["调度策略"].config(text=d.get("governor", "-"))
                for k, key in (("小核上限", "cpu0_max"), ("大核上限", "cpu4_max"),
                               ("超大核上限", "cpu7_max")):
                    v = d.get(key, 0)
                    self._perf_labels[k].config(text="%s MHz" % v if v else "-")
                self._perf_labels["当前频率"].config(text="%s MHz" % (d.get("cur_freq") or "-"))
                self._perf_labels["GPU 上限"].config(text="%s MHz" % (d.get("gpu") or "-"))
            self.root.after(0, upd)
        self.bg(work)

    def _perf_set(self, level):
        names = {"save": "省电", "bal": "均衡", "perf": "性能", "ext": "极速"}
        self.log("正在切换到「%s」模式…" % names.get(level, level), "hdr")
        def work():
            ok, txt = F.set_performance(level)
            for line in txt.splitlines()[:12]:
                if line.strip():
                    self.log("  " + line.strip())
            self.log("「%s」%s" % (names.get(level, level), "已生效" if ok else "失败"),
                     "info" if ok else "err")
            self._perf_refresh()
        self.bg(work)

    # ================= 页面：内存/虚拟内存 =================
    def page_memory(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)

        c1 = Card(wrap, "内存与虚拟内存")
        c1.pack(fill="x", pady=(0, 8))
        self._mem_rows = tk.Frame(c1.inner, bg=T.CARD)
        self._mem_rows.pack(fill="x")

        c2 = Card(wrap, "虚拟内存使用倾向（swappiness）")
        c2.pack(fill="x", pady=(0, 8))
        top = tk.Frame(c2.inner, bg=T.CARD)
        top.pack(fill="x")
        self._sw_val = tk.Label(top, text="60", bg=T.CARD, fg=T.ORANGE,
                                font=(T.FONT, 18, "bold"))
        self._sw_val.pack(side="left")
        tk.Label(top, text="/ 100（内核上限 100）", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 9)).pack(side="left", padx=(6, 0), pady=(8, 0))
        self._sw = tk.Scale(c2.inner, from_=0, to=100, orient="horizontal",
                            bg=T.CARD, fg=T.TXT, troughcolor=T.STROKE,
                            highlightthickness=0, bd=0, showvalue=0,
                            command=lambda v: self._sw_val.config(text=str(int(float(v)))))
        self._sw.pack(fill="x", pady=(6, 4))
        hint = tk.Label(c2.inner, text=(
            "低 = 少用虚拟内存，多用真实内存（更快，但内存紧张）\n"
            "高 = 积极换出到 swap（真实内存更宽松，但 IO 增多）"
        ), bg=T.CARD, fg=T.TXT3, font=(T.FONT, 8), justify="left", anchor="w")
        hint.pack(fill="x")

        brow = tk.Frame(c2.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(8, 0))
        RoundedButton(brow, "应用并立即生效", self._apply_swappiness,
                      T.BLUE, width=140, height=32).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "释放缓存", self._drop_caches,
                      T.GREEN, width=100, height=32).pack(side="left")

        c3 = Card(wrap, "zram 容量")
        c3.pack(fill="x", pady=(0, 8))
        zrow = tk.Frame(c3.inner, bg=T.CARD)
        zrow.pack(fill="x")
        self._zram_label = tk.Label(zrow, text="-", bg=T.CARD, fg=T.PURPLE,
                                    font=(T.FONT, 12, "bold"))
        self._zram_label.pack(side="left")
        tk.Label(zrow, text="  范围 256MB ~ 6GB", bg=T.CARD, fg=T.TXT3,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 0), pady=(4, 0))
        zrow2 = tk.Frame(c3.inner, bg=T.CARD)
        zrow2.pack(fill="x", pady=(8, 0))
        self._zram_scale = tk.Scale(zrow2, from_=256, to=6144, orient="horizontal",
                                    resolution=64, bg=T.CARD, fg=T.TXT,
                                    troughcolor=T.STROKE, highlightthickness=0, bd=0)
        self._zram_scale.pack(side="left", fill="x", expand=True)
        RoundedButton(zrow2, "应用", self._apply_zram, T.PURPLE,
                      width=70, height=30).pack(side="left", padx=(8, 0))

        c4 = Card(wrap, "说明")
        c4.pack(fill="x")
        tk.Label(c4.inner, text=(
            "• 「总内存」是物理内存（1.79GB），任何软件都改不了，这是硬件事实\n"
            "• 能改的是 swap 总量：zram（压缩内存，快）+ 磁盘 swap（慢，后备）\n"
            "• zram 优先级必须高于磁盘 swap，否则系统会严重卡顿\n"
            "★ 绝不要关闭 zram 后不重新开启，会导致系统卡死"
        ), bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
            anchor="w").pack(fill="x")

        self._mem_refresh()

    def _mem_refresh(self):
        def work():
            st = F.swap_status()
            mem = st["mem"]
            sw = F.get_swappiness()
            zm = F.zram_size_mb()
            def upd():
                for w in self._mem_rows.winfo_children():
                    w.destroy()
                rows = [
                    ("可用内存", E.kb_human(mem["available"]),
                     E.kb_human(mem["total"]),
                     T.GREEN if mem["available"] > 300 * 1024 else T.ORANGE),
                    ("swap 总计", E.kb_human(mem["swap_total"] - mem["swap_free"]),
                     E.kb_human(mem["swap_total"]), T.CYAN),
                ]
                for r in st["zram"]:
                    rows.append(("zram", E.kb_human(r["used"]), E.kb_human(r["size"]),
                                 T.PURPLE))
                for r in st["disk"]:
                    rows.append(("磁盘 swap", E.kb_human(r["used"]), E.kb_human(r["size"]),
                                 T.BLUE))
                if not st["zram"] and not st["disk"]:
                    rows.append(("swap", "未启用", "-", T.TXT3))
                for name, v, total, col in rows:
                    f = tk.Frame(self._mem_rows, bg=T.CARD)
                    f.pack(fill="x", pady=2)
                    tk.Label(f, text=name, bg=T.CARD, fg=T.TXT2, width=14,
                             anchor="w", font=(T.FONT, 9)).pack(side="left")
                    tk.Label(f, text=v, bg=T.CARD, fg=col,
                             font=(T.FONT, 10, "bold")).pack(side="left")
                    tk.Label(f, text=" / " + total, bg=T.CARD, fg=T.TXT3,
                             font=(T.FONT, 9)).pack(side="left")
                if sw.isdigit():
                    self._sw.set(int(sw))
                    self._sw_val.config(text=sw)
                self._zram_label.config(text="%d MB（当前）" % zm if zm else "-")
            self.root.after(0, upd)
        self.bg(work)

    def _apply_swappiness(self):
        val = int(self._sw.get())
        def work():
            ok, cur = F.set_swappiness(val)
            self.log("swappiness -> %s %s" % (cur, "OK" if ok else "失败"),
                     "info" if ok else "err")
            F.drop_caches()
            self.log("已释放缓存")
            self._mem_refresh()
        self.bg(work)

    def _apply_zram(self):
        mb = int(self._zram_scale.get())
        if not messagebox.askyesno("确认", "调整 zram 到 %dMB？\n\n期间 swap 会短暂中断，约 5-10 秒。\n请确保设备当前不忙碌。" % mb):
            return
        self.log("正在调整 zram 到 %dMB…" % mb, "hdr")
        def work():
            ok, txt = F.resize_zram(mb)
            for line in txt.splitlines()[:8]:
                if line.strip():
                    self.log("  " + line.strip())
            self.log("zram %s" % ("已调整" if ok else "调整失败"),
                     "info" if ok else "err")
            self._mem_refresh()
        self.bg(work)

    def _drop_caches(self):
        def work():
            ok, _ = F.drop_caches()
            self.log("内存缓存已释放" if ok else "释放失败", "info" if ok else "err")
            self._ov_refresh()
            if self.cur == "memory":
                self._mem_refresh()
        self.bg(work)

    def _reboot(self):
        if not messagebox.askyesno("确认重启", "确定要重启设备吗？"):
            return
        def work():
            self.log("正在重启设备…", "warn")
            E.adb("reboot", timeout=30)
        self.bg(work)

    # ================= 页面：风扇/温度 =================
    def page_fan(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)

        c1 = Card(wrap, "温度")
        c1.pack(fill="x", pady=(0, 8))
        self._temp_rows = tk.Frame(c1.inner, bg=T.CARD)
        self._temp_rows.pack(fill="x")

        c2 = Card(wrap, "风扇状态")
        c2.pack(fill="x", pady=(0, 8))
        self._fan_label = tk.Label(c2.inner, text="读取中…", bg=T.CARD, fg=T.TXT,
                                   font=(T.FONT, 10), justify="left", anchor="w")
        self._fan_label.pack(fill="x")

        c3 = Card(wrap, "说明（如实告知）")
        c3.pack(fill="x")
        tk.Label(c3.inner, text=(
            "实测结论：本机风扇由内核 pwm-fan 驱动独占控制。\n"
            "  • pwmchip4 ch0（风扇）export 返回 1，用户空间无法操作\n"
            "  • cooling_device 0-22 里没有 fan 类型\n"
            "  • 风扇由内核 thermal-engine 根据温度自动调速\n\n"
            "所以本工具只做温度监控，不提供「手动调速」——\n"
            "因为做不到，写出来也是假的。\n\n"
            "★ pwmchip0 ch3 是屏幕背光，绝不能碰（unexport 会黑屏）"
        ), bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
            anchor="w").pack(fill="x")

        brow = tk.Frame(c3.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(10, 0))
        RoundedButton(brow, "刷新温度", self._fan_refresh, T.BLUE,
                      width=110, height=30).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "黑屏急救", self._fix_screen, T.RED,
                      width=110, height=30).pack(side="left")


        self._fan_refresh()

    def _fan_refresh(self):
        def work():
            st = F.fan_status()
            def upd():
                for w in self._temp_rows.winfo_children():
                    w.destroy()
                if not st["zones"]:
                    tk.Label(self._temp_rows, text="读不到温度传感器",
                             bg=T.CARD, fg=T.TXT3, font=(T.FONT, 9)).pack(anchor="w")
                for z, t in st["zones"]:
                    f = tk.Frame(self._temp_rows, bg=T.CARD)
                    f.pack(fill="x", pady=2)
                    tk.Label(f, text="thermal_zone" + str(z), bg=T.CARD, fg=T.TXT2,
                             width=16, anchor="w", font=(T.FONT, 9)).pack(side="left")
                    col = T.GREEN if t < 50 else (T.ORANGE if t < 65 else T.RED)
                    tk.Label(f, text=str(t) + chr(176) + "C", bg=T.CARD, fg=col,
                             font=(T.FONT, 11, "bold")).pack(side="left")
                tval = str(st["temp"]) if st["temp"] else "-"
                msg = ("驱动: " + str(st["driver"]) + "   当前最高温: " + tval
                       + chr(176) + "C   调速: 内核自动")
                self._fan_label.config(text=msg)
            self.root.after(0, upd)
        self.bg(work)

    def _fix_screen(self):
        if not messagebox.askyesno("黑屏急救", "只有屏幕黑掉（背光被误关）时才需要。继续吗？"):
            return
        def work():
            ok, txt = F.backlight_fix()
            self.log("黑屏急救: " + (txt or "已执行"), "info" if ok else "err")
        self.bg(work)

    # ================= 页面：Root/模块 =================
    def page_root(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)

        c1 = Card(wrap, "Root 状态")
        c1.pack(fill="x", pady=(0, 8))
        self._root_label = tk.Label(c1.inner, text="检测中...", bg=T.CARD, fg=T.TXT,
                                    font=(T.FONT, 10), justify="left", anchor="w")
        self._root_label.pack(fill="x")
        brow = tk.Frame(c1.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(10, 0))
        RoundedButton(brow, "重新检测 Root", self._root_refresh, T.BLUE,
                      width=120, height=32).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "一键开启 adb root", self._root_adb, T.ORANGE,
                      width=150, height=32).pack(side="left")

        c2 = Card(wrap, "Magisk 模块")
        c2.pack(fill="x", pady=(0, 8))
        self._mod_box = tk.Frame(c2.inner, bg=T.CARD)
        self._mod_box.pack(fill="x")
        mrow = tk.Frame(c2.inner, bg=T.CARD)
        mrow.pack(fill="x", pady=(8, 0))
        RoundedButton(mrow, "刷新列表", self._mod_refresh, T.BLUE,
                      width=100, height=30).pack(side="left", padx=(0, 8))
        RoundedButton(mrow, "安装模块 zip", self._mod_install, T.PURPLE,
                      width=130, height=30).pack(side="left")

        c3 = Card(wrap, "说明")
        c3.pack(fill="x")
        tk.Label(c3.inner, text=("• 本工具用绝对路径 /debug_ramdisk/su，这是旧版失效的根因" + NL +
                                "• 模块停用后重启才生效；紧急时可在 recovery 删 /data/adb/modules/xxx"),
                 bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
                 anchor="w").pack(fill="x")

        self._root_refresh()
        self._mod_refresh()

    def _root_refresh(self):
        def work():
            d = F.root_status()
            lines = []
            lines.append("Root: " + ("可用" if d["has_root"] else "不可用"))
            lines.append("su 路径: " + str(d["su_path"] or "未找到"))
            lines.append("uid: " + str(d["uid"] or "-"))
            lines.append("Magisk: " + str(d["magisk"] or "-"))
            lines.append("zygote_policy: " + str(d["zygote"] or "-"))
            txt = NL.join(lines)
            col = T.GREEN if d["has_root"] else T.RED
            self.root.after(0, lambda: self._root_label.config(text=txt, fg=col))
            self.log("Root 检测: " + ("可用" if d["has_root"] else "不可用"),
                     "info" if d["has_root"] else "warn")
        self.bg(work)

    def _root_adb(self):
        self.log("正在开启 adb root...", "hdr")
        def work():
            ok, txt = F.root_adb_enable()
            for l in txt.splitlines()[:6]:
                if l.strip():
                    self.log("  " + l.strip())
            self.log("adb root " + ("已开启" if ok else "失败"), "info" if ok else "err")
            self._root_refresh()
        self.bg(work)

    def _mod_refresh(self):
        def work():
            mods = F.list_modules()
            def upd():
                for w in self._mod_box.winfo_children():
                    w.destroy()
                if not mods:
                    tk.Label(self._mod_box, text="没有读取到模块（或无 root）",
                             bg=T.CARD, fg=T.TXT3, font=(T.FONT, 9)).pack(anchor="w")
                    return
                for m in mods:
                    f = tk.Frame(self._mod_box, bg=T.CARD)
                    f.pack(fill="x", pady=2)
                    col = T.TXT3 if m["disabled"] else T.GREEN
                    st = "已停用" if m["disabled"] else "启用中"
                    tk.Label(f, text=m["name"], bg=T.CARD, fg=T.TXT, width=30,
                             anchor="w", font=(T.FONT, 9)).pack(side="left")
                    tk.Label(f, text=st, bg=T.CARD, fg=col,
                             font=(T.FONT, 9)).pack(side="left")
                    nm = m["name"]
                    en = m["disabled"]
                    RoundedButton(f, "启用" if en else "停用",
                                  lambda n=nm, e=en: self._mod_toggle(n, e),
                                  T.CARD_HI, width=54, height=22,
                                  text_color=T.TXT2, font_size=8).pack(side="right", padx=3)
            self.root.after(0, upd)
            self.log("模块数: " + str(len(mods)))
        self.bg(work)

    def _mod_toggle(self, name, enable):
        def work():
            ok, txt = F.toggle_module(name, enable)
            self.log(("启用 " if enable else "停用 ") + name + (" OK" if ok else " 失败"),
                     "info" if ok else "err")
            self._mod_refresh()
        self.bg(work)

    def _mod_install(self):
        p = filedialog.askopenfilename(title="选择 Magisk 模块",
                                       filetypes=[("Magisk 模块", "*.zip")])
        if not p:
            return
        self.log("安装模块: " + os.path.basename(p), "hdr")
        def work():
            ok, txt = F.install_module(p)
            for l in txt.splitlines()[-8:]:
                if l.strip():
                    self.log("  " + l.strip())
            self.log("模块安装 " + ("成功（重启生效）" if ok else "失败"),
                     "info" if ok else "err")
            self._mod_refresh()
        self.bg(work)

    # ================= 页面：应用管理 =================
    def page_apps(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)
        c1 = Card(wrap, "已安装应用（第三方）")
        c1.pack(fill="both", expand=True, pady=(0, 8))
        brow = tk.Frame(c1.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(0, 6))
        RoundedButton(brow, "刷新列表", self._apps_refresh, T.BLUE,
                      width=100, height=30).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "导出选中 APK", self._app_pull, T.GREEN,
                      width=130, height=30).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "卸载选中", self._app_uninstall, T.RED,
                      width=100, height=30).pack(side="left")
        self._app_count = tk.Label(brow, text="", bg=T.CARD, fg=T.TXT3,
                                   font=(T.FONT, 8))
        self._app_count.pack(side="left", padx=(12, 0))
        lb = tk.Frame(c1.inner, bg=T.CARD)
        lb.pack(fill="both", expand=True)
        sb = tk.Scrollbar(lb, bg=T.CARD_HI, troughcolor=T.CARD, bd=0,
                          highlightthickness=0, width=10)
        sb.pack(side="right", fill="y")
        self._app_list = tk.Listbox(lb, bg="#0d0f16", fg=T.TXT, bd=0,
                                    selectbackground=T.BLUE,
                                    font=(T.FONT_MONO, 9),
                                    highlightthickness=0,
                                    yscrollcommand=sb.set)
        self._app_list.pack(side="left", fill="both", expand=True)
        sb.config(command=self._app_list.yview)
        self._apps_data = []
        self._apps_refresh()

    def _apps_refresh(self):
        def work():
            pkgs = F.list_packages(third_party=True, include_disabled=True)
            info = []
            for p in pkgs:
                d = F.package_detail(p)
                info.append((p, d))
            def upd():
                self._app_list.delete(0, "end")
                self._apps_data = info
                for p, d in info:
                    flag = "[停用] " if d["disabled"] else ""
                    self._app_list.insert("end", flag + p + "   v" + str(d["version"]))
                self._app_count.config(text="共 " + str(len(info)) + " 个")
            self.root.after(0, upd)
            self.log("应用列表: " + str(len(info)) + " 个")
        self.bg(work)

    def _sel_app(self):
        cur = self._app_list.curselection()
        if not cur:
            messagebox.showinfo("提示", "请先在列表里选一个应用")
            return None
        idx = cur[0]
        if idx >= len(self._apps_data):
            return None
        return self._apps_data[idx][0]

    def _app_uninstall(self):
        pkg = self._sel_app()
        if not pkg:
            return
        if not messagebox.askyesno("确认卸载", "确定卸载 " + pkg + " ?"):
            return
        def work():
            r = F.uninstall(pkg)
            self.log("卸载 " + pkg + ": " + (r.out or r.err),
                     "info" if "Success" in r.text() else "err")
            self._apps_refresh()
        self.bg(work)

    def _app_pull(self):
        pkg = self._sel_app()
        if not pkg:
            return
        def work():
            ok, msg, path = F.pull_apk(pkg)
            self.log(("导出成功: " + str(path)) if ok else ("导出失败: " + msg),
                     "info" if ok else "err")
        self.bg(work)

    # ================= 页面：分区备份 =================
    def page_backup(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)
        c1 = Card(wrap, "备份关键分区")
        c1.pack(fill="x", pady=(0, 8))
        tk.Label(c1.inner, text=("会备份 " + str(len(F.BACKUP_PARTS)) + " 个分区到设备 /data/local/tmp/rc2backup/" + NL +
                                "然后可一键拉到电脑。备份前请确认设备剩余空间充足。"),
                 bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
                 anchor="w").pack(fill="x")
        brow = tk.Frame(c1.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(10, 0))
        RoundedButton(brow, "开始备份全部分区", self._do_backup, T.BLUE,
                      width=160, height=36).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "备份并拉到电脑", self._backup_and_pull, T.GREEN,
                      width=160, height=36).pack(side="left")

        c2 = Card(wrap, "分区列表")
        c2.pack(fill="both", expand=True, pady=(0, 8))
        lb = tk.Frame(c2.inner, bg=T.CARD)
        lb.pack(fill="both", expand=True)
        sb = tk.Scrollbar(lb, bg=T.CARD_HI, troughcolor=T.CARD, bd=0,
                          highlightthickness=0, width=10)
        sb.pack(side="right", fill="y")
        self._part_list = tk.Listbox(lb, bg="#0d0f16", fg=T.TXT, bd=0,
                                     font=(T.FONT_MONO, 9),
                                     highlightthickness=0,
                                     yscrollcommand=sb.set)
        self._part_list.pack(side="left", fill="both", expand=True)
        sb.config(command=self._part_list.yview)

        c3 = Card(wrap, "安全提醒")
        c3.pack(fill="x")
        tk.Label(c3.inner, text=("★ 只有 dji_apk 分区可安全刷回，其他数据分区刷回会显示「损坏」" + NL +
                                "★ 备份文件很大（boot 96MB、dji_apk 512MB），注意磁盘空间"),
                 bg=T.CARD, fg=T.ORANGE, font=(T.FONT, 9), justify="left",
                 anchor="w").pack(fill="x")
        self._backup_refresh_parts()

    def _backup_refresh_parts(self):
        def work():
            parts = F.list_partitions()
            def upd():
                self._part_list.delete(0, "end")
                for p in parts:
                    self._part_list.insert("end", p)
            self.root.after(0, upd)
            self.log("设备分区共 " + str(len(parts)) + " 个")
        self.bg(work)

    def _do_backup(self):
        if not messagebox.askyesno("确认", "开始备份全部关键分区？可能需要几分钟。"):
            return
        self.log("===== 开始备份分区 =====", "hdr")
        def work():
            results, total = F.backup_all(on_log=lambda m: self.log(m))
            okn = sum(1 for _, ok, _ in results if ok)
            self.log("备份完成: " + str(okn) + "/" + str(len(results)) +
                     "  总计 " + E.human(total),
                     "info" if okn == len(results) else "warn")
        self.bg(work)

    def _backup_and_pull(self):
        if not messagebox.askyesno("确认", "备份全部分区并拉到电脑？"):
            return
        self.log("===== 备份并拉取 =====", "hdr")
        def work():
            results, total = F.backup_all(on_log=lambda m: self.log(m))
            okn = sum(1 for _, ok, _ in results if ok)
            self.log("备份完成 " + str(okn) + "/" + str(len(results)),
                     "info" if okn == len(results) else "warn")
            self.log("正在拉取到电脑...", "hdr")
            ok, dest, msg = F.pull_backup()
            self.log(("已保存到: " + dest) if ok else ("拉取失败: " + msg),
                     "info" if ok else "err")
        self.bg(work)

    # ================= 页面：刷机/恢复 =================
    def page_flash(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)
        c1 = Card(wrap, "Fastboot 操作")
        c1.pack(fill="x", pady=(0, 8))
        tk.Label(c1.inner, text=("刷机需要先进入 fastboot 模式。BL 已解锁时才能刷写分区。"),
                 bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
                 anchor="w").pack(fill="x")
        brow = tk.Frame(c1.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(10, 0))
        RoundedButton(brow, "进入 fastboot", self._to_fastboot, T.ORANGE,
                      width=120, height=32).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "重启到系统", self._to_system, T.BLUE,
                      width=120, height=32).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "检查 BL 解锁", self._check_bl, T.GREEN,
                      width=130, height=32).pack(side="left")

        c2 = Card(wrap, "刷写分区")
        c2.pack(fill="x", pady=(0, 8))
        self._flash_label = tk.Label(c2.inner, text="未选择镜像", bg=T.CARD,
                                     fg=T.TXT3, font=(T.FONT, 9), anchor="w")
        self._flash_label.pack(fill="x")
        self._flash_img = None
        brow2 = tk.Frame(c2.inner, bg=T.CARD)
        brow2.pack(fill="x", pady=(8, 0))
        RoundedButton(brow2, "选择镜像", self._pick_img, T.CARD_HI,
                      width=100, height=30, text_color=T.TXT).pack(side="left", padx=(0, 8))
        RoundedButton(brow2, "刷到 boot_b", lambda: self._flash("boot_b"), T.RED,
                      width=110, height=30).pack(side="left", padx=(0, 8))
        RoundedButton(brow2, "刷到 dji_apk", lambda: self._flash("dji_apk"), T.ORANGE,
                      width=130, height=30).pack(side="left")

        c3 = Card(wrap, "危险提示")
        c3.pack(fill="x")
        warn = ("危险: 刷错分区可能让设备无法开机（变砖）" + NL +
                "只有 dji_apk 可以安全刷回" + NL +
                "刷 boot 前务必确认镜像正确，并已备份原 boot" + NL +
                "不确定就不要刷")
        tk.Label(c3.inner, text=warn, bg=T.CARD, fg=T.RED,
                 font=(T.FONT, 9), justify="left", anchor="w").pack(fill="x")

    def _to_fastboot(self):
        if not messagebox.askyesno("确认", "重启到 fastboot 模式？"):
            return
        def work():
            self.log("重启到 bootloader...", "warn")
            E.adb("reboot", "bootloader", timeout=30)
        self.bg(work)

    def _to_system(self):
        def work():
            r = E._run([E.FASTBOOT, "reboot"], timeout=30)
            self.log("fastboot reboot: " + (r.text() or "OK"),
                     "info" if r.ok else "err")
        self.bg(work)

    def _check_bl(self):
        def work():
            r = E._run([E.FASTBOOT, "getvar", "unlocked"], timeout=20)
            self.log("BL 解锁状态: " + (r.text() or "未知"),
                     "info" if r.ok else "warn")
        self.bg(work)

    def _pick_img(self):
        p = filedialog.askopenfilename(title="选择镜像",
                                       filetypes=[("镜像", "*.img"), ("所有", "*.*")])
        if p:
            self._flash_img = p
            self._flash_label.config(text=p)

    def _flash(self, part):
        if not self._flash_img:
            messagebox.showinfo("提示", "请先选择镜像文件")
            return
        ok = messagebox.askyesno("危险操作", "确定把该镜像刷到 " + part + " 吗？刷错可能变砖！")
        if not ok:
            return
        self.log("刷写 " + part + " <- " + os.path.basename(self._flash_img), "hdr")
        def work():
            r = E._run([E.FASTBOOT, "flash", part, self._flash_img], timeout=600)
            for l in r.text().splitlines()[-6:]:
                if l.strip():
                    self.log("  " + l.strip())
            self.log("刷写 " + ("完成" if r.ok else "失败"),
                     "info" if r.ok else "err")
        self.bg(work)

    # ================= 页面：投屏/截图 =================
    def page_screen(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)
        c1 = Card(wrap, "投屏（scrcpy）")
        c1.pack(fill="x", pady=(0, 8))
        info = ("scrcpy 路径: " + E.SCRCPY + NL +
                "状态: " + ("已就绪" if os.path.isfile(E.SCRCPY) else "未找到 scrcpy.exe"))
        self._scrcpy_label = tk.Label(c1.inner, text=info, bg=T.CARD,
                                      fg=T.TXT2, font=(T.FONT, 8),
                                      justify="left", anchor="w")
        self._scrcpy_label.pack(fill="x")
        brow = tk.Frame(c1.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(10, 0))
        RoundedButton(brow, "启动投屏（省内存）",
                      lambda: self._scrcpy(["--max-size=1280", "--max-fps=30"]),
                      T.BLUE, width=170, height=34).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "启动投屏（高清）",
                      lambda: self._scrcpy(["--max-size=1920", "--bit-rate=8M"]),
                      T.PURPLE, width=160, height=34).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "停止投屏", self._scrcpy_stop, T.RED,
                      width=100, height=34).pack(side="left")

        c2 = Card(wrap, "截图 / 录屏")
        c2.pack(fill="x", pady=(0, 8))
        brow2 = tk.Frame(c2.inner, bg=T.CARD)
        brow2.pack(fill="x")
        RoundedButton(brow2, "截图保存", self._screenshot, T.GREEN,
                      width=110, height=34).pack(side="left", padx=(0, 8))
        RoundedButton(brow2, "录制屏幕", self._record, T.ORANGE,
                      width=110, height=34).pack(side="left", padx=(0, 8))
        RoundedButton(brow2, "打开输出目录", lambda: self._open_dir(E.OUT),
                      T.CARD_HI, width=120, height=34,
                      text_color=T.TXT).pack(side="left")

        c3 = Card(wrap, "说明")
        c3.pack(fill="x")
        tk.Label(c3.inner, text=("投屏用 scrcpy，独立窗口不占用本界面。" + NL +
                                "截图/录屏文件保存在 out 目录。"),
                 bg=T.CARD, fg=T.TXT2, font=(T.FONT, 9), justify="left",
                 anchor="w").pack(fill="x")

    def _scrcpy(self, args):
        if not os.path.isfile(E.SCRCPY):
            messagebox.showerror("找不到 scrcpy", "未找到: " + E.SCRCPY)
            return
        if not E.is_connected():
            messagebox.showerror("未连接设备", "请先插 USB 并开启 USB 调试")
            return
        import subprocess
        self.log("启动投屏: " + " ".join(args), "hdr")
        try:
            kw = {}
            if os.name == "nt":
                kw["creationflags"] = 0x00000008
            subprocess.Popen([E.SCRCPY] + args, cwd=E.SCRCPY_DIR, **kw)
            self.log("投屏已启动（独立窗口）")
        except Exception as e:
            self.log("投屏启动失败: " + str(e), "err")
            messagebox.showerror("启动失败", str(e))

    def _scrcpy_stop(self):
        E._run(["taskkill", "/F", "/IM", "scrcpy.exe"], timeout=20)
        self.log("已停止投屏")

    def _screenshot(self):
        def work():
            E.ensure_out()
            name = "shot_" + time.strftime("%Y%m%d_%H%M%S") + ".png"
            remote = "/data/local/tmp/" + name
            r = E.adb_shell("screencap -p " + remote, timeout=60)
            if not r.ok:
                self.log("截图失败: " + r.text(), "err")
                return
            local = os.path.join(E.OUT, name)
            r2 = E.adb("pull", remote, local, timeout=120)
            E.adb_shell("rm -f " + remote, timeout=15)
            if r2.ok:
                self.log("截图已保存: " + local)
            else:
                self.log("拉取失败: " + r2.text(), "err")
        self.bg(work)

    def _record(self):
        self.log("开始录屏（关闭 scrcpy 窗口停止）", "hdr")
        E.ensure_out()
        dst = os.path.join(E.OUT, "rec_" + time.strftime("%Y%m%d_%H%M%S") + ".mp4")
        self._scrcpy(["--record=" + dst, "--max-size=1280"])

    def _open_dir(self, path):
        try:
            os.makedirs(path, exist_ok=True)
            os.startfile(path)
        except Exception as e:
            self.log("打开目录失败: " + str(e), "err")

    # ================= 页面：实用工具 =================
    def page_tools(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)
        c1 = Card(wrap, "常用工具")
        c1.pack(fill="x", pady=(0, 8))
        grid = tk.Frame(c1.inner, bg=T.CARD)
        grid.pack(fill="x")
        tools = [
            ("导出系统信息", self._dump_info, T.BLUE),
            ("查看日志(logcat)", self._logcat, T.GREEN),
            ("安装 APK", self._install_apk, T.PURPLE),
            ("无线 ADB", self._wireless, T.ORANGE),
            ("屏幕常亮", self._stay_awake, T.CYAN),
            ("清理临时文件", self._clean_tmp, T.RED),
            ("重挂 SD 卡", self._remount, T.CARD_HI),
            ("查看分区详情", self._part_detail, T.CARD_HI),
        ]
        for i, (txt, cmd, col) in enumerate(tools):
            r, c = divmod(i, 4)
            RoundedButton(grid, txt, cmd, col, width=140, height=34,
                          text_color=T.TXT if col == T.CARD_HI else "#ffffff"
                          ).grid(row=r, column=c, padx=4, pady=4)

        c2 = Card(wrap, "执行自定义 shell 命令")
        c2.pack(fill="x", pady=(0, 8))
        self._cmd_entry = tk.Entry(c2.inner, bg="#0d0f16", fg=T.TXT, bd=0,
                                    insertbackground=T.TXT,
                                    font=(T.FONT_MONO, 10))
        self._cmd_entry.pack(fill="x", ipady=6)
        brow = tk.Frame(c2.inner, bg=T.CARD)
        brow.pack(fill="x", pady=(8, 0))
        RoundedButton(brow, "以 root 执行", lambda: self._run_cmd(True), T.RED,
                      width=130, height=30).pack(side="left", padx=(0, 8))
        RoundedButton(brow, "以普通用户执行", lambda: self._run_cmd(False), T.BLUE,
                      width=150, height=30).pack(side="left")
        tk.Label(brow, text="结果输出到下方日志", bg=T.CARD, fg=T.TXT3,
                 font=(T.FONT, 8)).pack(side="left", padx=(12, 0))

        c3 = Card(wrap, "危险操作")
        c3.pack(fill="x")
        brow3 = tk.Frame(c3.inner, bg=T.CARD)
        brow3.pack(fill="x")
        RoundedButton(brow3, "重启设备", self._reboot, T.RED,
                      width=110, height=32).pack(side="left", padx=(0, 8))
        RoundedButton(brow3, "重启到 recovery", self._to_recovery, T.ORANGE,
                      width=150, height=32).pack(side="left")

    def _run_cmd(self, root):
        cmd = self._cmd_entry.get().strip()
        if not cmd:
            return
        self.log("$ " + cmd, "hdr")
        def work():
            r = E.sh(cmd, timeout=120) if root else E.adb_shell(cmd, timeout=120)
            for l in r.text().splitlines()[:30]:
                self.log("  " + l)
            if not r.text():
                self.log("  (无输出)")
        self.bg(work)

    def _dump_info(self):
        def work():
            info = E.DeviceInfo()
            m = E.mem_info()
            b = E.battery()
            t = E.cpu_temp()
            lines = ["===== RC2 设备信息 =====",
                     "型号: " + info.model,
                     "品牌: " + info.brand,
                     "系统: Android " + info.android + " (SDK " + info.sdk + ")",
                     "ABI: " + info.abi,
                     "内核: " + info.kernel,
                     "序列号: " + info.serial,
                     "槽位: " + info.slot,
                     "BL: " + info.bootloader,
                     "Root: " + ("是" if info.root else "否"),
                     "zygote_policy: " + info.zygote_policy,
                     "----- 内存 -----",
                     "总内存: " + E.kb_human(m["total"]),
                     "可用: " + E.kb_human(m["available"]),
                     "swap 总: " + E.kb_human(m["swap_total"]),
                     "----- 状态 -----",
                     "CPU: " + str(E.cpu_freq()) + "MHz  " +
                     str(t) + "C  " + E.cpu_governor(),
                     "GPU: " + str(E.gpu_freq()) + "MHz",
                     "电池: " + str(b.get("capacity")) + "% " +
                     str(b.get("status")),
                     ]
            E.ensure_out()
            path = os.path.join(E.OUT, "device_info_" +
                                 time.strftime("%Y%m%d_%H%M%S") + ".txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write(NL.join(lines))
            for l in lines:
                self.log(l)
            self.log("已保存: " + path, "info")
        self.bg(work)

    def _logcat(self):
        def work():
            r = E.adb_shell("logcat -d -t 80", timeout=40)
            for l in r.out.splitlines()[-40:]:
                self.log(l)
            self.log("日志行数获取完成")
        self.bg(work)

    def _install_apk(self):
        p = filedialog.askopenfilename(title="选择 APK",
                                       filetypes=[("APK", "*.apk")])
        if not p:
            return
        self.log("安装: " + os.path.basename(p), "hdr")
        def work():
            r = E.adb("install", "-r", "--abi", "arm64-v8a", p, timeout=600)
            self.log(r.text()[-500:] or "完成",
                     "info" if "Success" in r.text() else "err")
        self.bg(work)

    def _wireless(self):
        def work():
            E.adb("tcpip", "5555", timeout=30)
            r = E.adb_shell("ip addr show wlan0 2>/dev/null | grep inet | head -1", timeout=20)
            m = __import__("re").search(r"inet (\d+\.\d+\.\d+\.\d+)", r.out)
            if m:
                ip = m.group(1)
                self.log("设备 IP: " + ip + ":5555", "info")
                self.log("在电脑执行: adb connect " + ip + ":5555")
            else:
                self.log("取不到 WiFi IP，请确认已连 WiFi", "warn")
        self.bg(work)

    def _stay_awake(self):
        def work():
            E.adb_shell("svc power stayon true", timeout=20)
            self.log("屏幕常亮已开启")
        self.bg(work)

    def _clean_tmp(self):
        def work():
            r = E.sh("rm -f /data/local/tmp/*.png /data/local/tmp/*.log " +
                     "/data/local/tmp/rc2task.sh 2>/dev/null; echo done")
            self.log("临时文件已清理" if r.ok else "清理失败",
                     "info" if r.ok else "err")
        self.bg(work)

    def _remount(self):
        def work():
            r = E.sh("mount -o remount,rw /system 2>&1 || echo NOT_SUPPORTED")
            self.log(r.text()[:300], "info" if r.ok else "warn")
        self.bg(work)

    def _part_detail(self):
        def work():
            r = E.sh("df -h /data /system /cache 2>/dev/null")
            for l in r.out.splitlines():
                self.log(l)
        self.bg(work)

    def _to_recovery(self):
        if not messagebox.askyesno("确认", "重启到 recovery？"):
            return
        self.bg(lambda: E.adb("reboot", "recovery", timeout=30))

    # ================= 页面：关于/免责 =================
    def page_about(self):
        wrap = tk.Frame(self.content, bg=T.BG)
        wrap.pack(fill="both", expand=True)
        c1 = Card(wrap, "关于")
        c1.pack(fill="x", pady=(0, 8))
        tk.Label(c1.inner, text=APP_NAME, bg=T.CARD, fg=T.TXT,
                 font=(T.FONT, 16, "bold"), anchor="w").pack(fill="x")
        tk.Label(c1.inner, text="版本 v" + APP_VER + "    作者：" + AUTHOR,
                 bg=T.CARD, fg=T.TXT2, font=(T.FONT, 10),
                 anchor="w").pack(fill="x", pady=(4, 0))
        tk.Label(c1.inner, text="专为 DJI RC2 遥控器（rc331 / Android 11）打造",
                 bg=T.CARD, fg=T.TXT3, font=(T.FONT, 9),
                 anchor="w").pack(fill="x", pady=(2, 0))

        c2 = Card(wrap, "免责声明（全文）")
        c2.pack(fill="both", expand=True, pady=(0, 8))
        txt = tk.Text(c2.inner, bg="#0d0f16", fg=T.TXT2, bd=0,
                      font=(T.FONT, 9), wrap="word", height=14)
        sb = tk.Scrollbar(c2.inner, bg=T.CARD_HI, troughcolor=T.CARD, bd=0,
                          highlightthickness=0, width=10,
                          command=txt.yview)
        sb.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True)
        txt.configure(yscrollcommand=sb.set)
        txt.insert("1.0", DISCLAIMER)
        txt.configure(state="disabled")

        c3 = Card(wrap, "配置")
        c3.pack(fill="x")
        cfg = ("adb: " + E.ADB + NL +
               "fastboot: " + E.FASTBOOT + NL +
               "scrcpy: " + E.SCRCPY + NL +
               "输出目录: " + E.OUT)
        tk.Label(c3.inner, text=cfg, bg=T.CARD, fg=T.TXT3,
                 font=(T.FONT_MONO, 8), justify="left",
                 anchor="w").pack(fill="x")
