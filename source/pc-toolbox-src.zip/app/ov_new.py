    # ================= 总览（苹果风）=================
    def page_overview(self):
        wrap = tk.Frame(self.content, bg=T.BG3)
        wrap.pack(fill="both", expand=True)

        # 顶部大卡：设备 + 内存
        c1 = Card(wrap, "设备")
        c1.pack(fill="x", pady=(0, 10))
        top = tk.Frame(c1.inner, bg=T.CARD)
        top.pack(fill="x")

        self._ov_name = tk.Label(top, text="-", bg=T.CARD, fg=T.TXT,
                                 font=(T.FONT, 20, "bold"), anchor="w")
        self._ov_name.pack(anchor="w")
        self._ov_sub = tk.Label(top, text="-", bg=T.CARD, fg=T.TXT2,
                                font=(T.FONT, 9), anchor="w")
        self._ov_sub.pack(anchor="w", pady=(2, 0))

        # 内存条
        memrow = tk.Frame(c1.inner, bg=T.CARD)
        memrow.pack(fill="x", pady=(14, 0))
        self._mem_box = StatBox(memrow, "可用内存", "-", "", T.GREEN,
                                bg=T.CARD, width=170)
        self._mem_box.pack(side="left")
        right = tk.Frame(memrow, bg=T.CARD)
        right.pack(side="left", fill="x", expand=True, padx=(20, 0))
        self._mem_bar = ProgressBar(right, width=520, height=9, bg=T.CARD)
        self._mem_bar.pack(fill="x", pady=(10, 0))

        # 三块数据
        c2 = Card(wrap, "实时状态")
        c2.pack(fill="x", pady=(0, 10))
        row = tk.Frame(c2.inner, bg=T.CARD)
        row.pack(fill="x")
        self._cpu_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.CYAN,
                                 font=(T.FONT, 13, "bold"))
        self._cpu_lbl.pack(side="left")
        tk.Label(row, text="CPU", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 28))
        self._gpu_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.PURPLE,
                                 font=(T.FONT, 13, "bold"))
        self._gpu_lbl.pack(side="left")
        tk.Label(row, text="GPU", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 28))
        self._bat_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.GREEN,
                                 font=(T.FONT, 13, "bold"))
        self._bat_lbl.pack(side="left")
        tk.Label(row, text="电池", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 28))
        self._gov_lbl = tk.Label(row, text="-", bg=T.CARD, fg=T.ORANGE,
                                 font=(T.FONT, 13, "bold"))
        self._gov_lbl.pack(side="left")
        tk.Label(row, text="调度", bg=T.CARD, fg=T.TXT2,
                 font=(T.FONT, 8)).pack(side="left", padx=(6, 0))

        # 快捷操作
        c3 = Card(wrap, "快捷操作")
        c3.pack(fill="x")
        acts = [("刷新数据", self._ov_refresh, T.BLUE),
                ("性能模式", lambda: self._perf_set("perf"), T.ORANGE),
                ("释放内存", self._drop_caches, T.GREEN),
                ("重启设备", self._reboot, T.RED)]
        brow = tk.Frame(c3.inner, bg=T.CARD)
        brow.pack(fill="x")
        for txt, cmd, col in acts:
            AButton(brow, txt, cmd, col, width=124, height=34).pack(
                side="left", padx=(0, 10))

        self._ov_refresh()

    def _ov_refresh(self):
        def work():
            info = E.DeviceInfo()
            m = E.mem_info()
            g = E.gpu_freq()
            b = E.battery()
            temp = E.cpu_temp()
            gov = E.cpu_governor()
            freq = E.cpu_freq()
            bat = b.get("capacity") or "-"
            st = b.get("status") or ""
            def upd():
                self._ov_name.config(text=info.model)
                self._ov_sub.config(text=("Android " + info.android +
                                         "  ·  " + info.abi +
                                         "  ·  " + info.serial +
                                         "  ·  " +
                                         ("已 Root" if info.root else "未 Root")))
                av = m["available"]
                pct = int(av * 100 / m["total"]) if m["total"] else 0
                col = T.GREEN if pct > 30 else (T.ORANGE if pct > 15 else T.RED)
                self._mem_box.set(E.kb_human(av),
                                  "共 " + E.kb_human(m["total"]), col)
                self._mem_bar.set(1 - pct / 100.0, col)
                c1 = (str(freq) + " MHz") if freq else "-"
                if temp:
                    c1 = c1 + "  " + str(temp) + chr(176) + "C"
                self._cpu_lbl.config(text=c1)
                self._gpu_lbl.config(text=(str(g) + " MHz") if g else "-")
                self._bat_lbl.config(text=str(bat) + "% " + st)
                self._gov_lbl.config(text=gov)
            self.root.after(0, upd)
            self.log("总览已刷新", "ok")
        self.bg(work)

