# -*- coding: utf-8 -*-
"""RC2 搞机工具箱 安装程序入口"""
import ctypes
import json
import os
import shutil
import subprocess
import sys
import threading
import time

APP_NAME = "RC2 搞机工具箱"
APP_VER = "6.0"
AUTHOR = "软糖布丁"
EXE_NAME = "RC2搞机工具箱.exe"


def res_dir():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


def payload_exe():
    """要安装的那份主程序（打包后在 _MEIPASS/payload 里）"""
    p = os.path.join(res_dir(), "payload", EXE_NAME)
    if os.path.isfile(p):
        return p
    p2 = os.path.join(os.path.dirname(app_dir()), "dist", EXE_NAME)
    if os.path.isfile(p2):
        return p2
    return p


def default_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    return os.path.join(base, "RC2DeviceToolbox")


def short_path(p):
    return p


class Api(object):
    def __init__(self):
        self.installed_path = ""
        self.agree_file = os.path.join(app_dir(), ".rc2_installer_agreed")
        self.start_exe = None

    # ---------- 基础 ----------
    def hello(self):
        return {"ok": True, "name": APP_NAME, "ver": APP_VER,
                "author": AUTHOR, "default_dir": default_dir()}

    def agree(self):
        try:
            with open(self.agree_file, "w", encoding="utf-8") as f:
                f.write(time.strftime("%Y-%m-%d %H:%M:%S"))
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "msg": str(e)}

    def quit(self):
        threading.Timer(0.4, lambda: os._exit(0)).start()
        return {"ok": True}

    # ---------- 安装 ----------
    def choose_dir(self):
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            root.attributes("-topmost", True)
            d = filedialog.askdirectory(title="选择安装位置",
                                        initialdir=default_dir())
            root.destroy()
            if d:
                return {"ok": True, "dir": os.path.join(d, "RC2DeviceToolbox")}
        except Exception as e:
            return {"ok": False, "msg": str(e)}
        return {"ok": False, "msg": "已取消"}

    def install(self, target=None):
        target = target or default_dir()
        src = payload_exe()
        if not os.path.isfile(src):
            return {"ok": False, "msg": "安装包内缺少主程序：%s" % src}
        try:
            os.makedirs(target, exist_ok=True)
            dst = os.path.join(target, EXE_NAME)
            shutil.copy2(src, dst)
            # 写一个卸载脚本
            uninst = os.path.join(target, "卸载 RC2 搞机工具箱.bat")
            with open(uninst, "w", encoding="gbk", errors="replace") as f:
                f.write("@echo off\r\n")
                f.write("chcp 65001 >nul\r\n")
                f.write("echo 正在卸载 RC2 搞机工具箱…\r\n")
                f.write('del /f /q "%%~dp0%s" 2>nul\r\n' % EXE_NAME)
                f.write('del /f /q "%s" 2>nul\r\n'
                        % os.path.join(os.environ.get("USERPROFILE", ""),
                                       "Desktop", "RC2 搞机工具箱.lnk"))
                f.write('del /f /q "%s" 2>nul\r\n'
                        % os.path.join(os.environ.get("APPDATA", ""),
                                       "Microsoft", "Windows", "Start Menu",
                                       "Programs", "RC2 搞机工具箱.lnk"))
                f.write('rmdir /s /q "%%~dp0" 2>nul\r\n')
                f.write("echo 卸载完成\r\n")
                f.write("pause\r\n")
            ok1 = self._shortcut_desktop(dst)
            ok2 = self._shortcut_startmenu(dst)
            self.installed_path = dst
            return {"ok": True, "path": dst, "desktop": ok1, "startmenu": ok2,
                    "size": os.path.getsize(dst)}
        except Exception as e:
            return {"ok": False, "msg": "%s: %s" % (type(e).__name__, e)}

    def _ps_shortcut(self, link_path, target):
        ps = (
            "$W = New-Object -ComObject WScript.Shell;"
            "$s = $W.CreateShortcut('%s');"
            "$s.TargetPath = '%s';"
            "$s.WorkingDirectory = '%s';"
            "$s.IconLocation = '%s,0';"
            "$s.Description = '%s';"
            "$s.Save()"
        ) % (link_path, target, os.path.dirname(target), target, APP_NAME)
        try:
            subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy",
                            "Bypass", "-Command", ps],
                           capture_output=True, timeout=40,
                           creationflags=0x08000000 if os.name == "nt" else 0)
            return os.path.isfile(link_path)
        except Exception:
            return False

    def _shortcut_desktop(self, target):
        desk = os.path.join(os.environ.get("USERPROFILE", ""), "Desktop")
        if not os.path.isdir(desk):
            return False
        return self._ps_shortcut(os.path.join(desk, APP_NAME + ".lnk"), target)

    def _shortcut_startmenu(self, target):
        base = os.path.join(os.environ.get("APPDATA", ""), "Microsoft",
                            "Windows", "Start Menu", "Programs")
        if not os.path.isdir(base):
            return False
        return self._ps_shortcut(os.path.join(base, APP_NAME + ".lnk"), target)

    # ---------- 完成 ----------
    def launch(self):
        target = self.installed_path or os.path.join(default_dir(), EXE_NAME)
        if not os.path.isfile(target):
            return {"ok": False, "msg": "找不到已安装的程序"}
        if getattr(sys, "frozen", False):
            base = os.path.dirname(sys.executable)
        else:
            base = os.path.dirname(os.path.abspath(__file__))
        return {"ok": True, "path": target}


def find_edge():
    cands = [
        r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
        r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    ]
    for p in cands:
        if os.path.isfile(p):
            return p
    try:
        import winreg
        with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe") as k:
            p = winreg.QueryValueEx(k, "")[0]
            if os.path.isfile(p):
                return p
    except Exception:
        pass
    return None


def seed_profile(prof):
    try:
        os.makedirs(prof, exist_ok=True)
        open(os.path.join(prof, "First Run"), "w").close()
        d = os.path.join(prof, "Default")
        os.makedirs(d, exist_ok=True)
        prefs = {
            "signin": {"allowed": False, "allowed_on_next_startup": False},
            "sync": {"requested": False},
            "browser": {"has_seen_welcome_page": True,
                        "check_default_browser": False},
            "profile": {"exit_type": "Normal"},
        }
        with open(os.path.join(d, "Preferences"), "w", encoding="utf-8") as f:
            json.dump(prefs, f)
    except Exception:
        pass


def main():
    import inst_server as S

    api = Api()
    S.UI_BASE = os.path.join(res_dir(), "installer", "ui") ;
    if not os.path.isdir(S.UI_BASE):
        S.UI_BASE = os.path.join(res_dir(), "ui")
    port = S.find_port()
    S.serve(api, port)
    url = "http://127.0.0.1:%d/" % port

    edge = find_edge()
    if not edge:
        ctypes.windll.user32.MessageBoxW(
            0, "没有找到 Microsoft Edge，无法启动安装界面。",
            APP_NAME, 0x10)
        return
    prof = os.path.join(app_dir(), ".data", "edge_installer")
    seed_profile(prof)
    args = [
        edge,
        "--app=" + url,
        "--window-size=1020,760",
        "--window-position=520,220",
        "--user-data-dir=" + prof,
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-features=msEdgeSidebarV2,msImplicitSignin,"
        "msEdgeIdentityBubble,msEdgeSync,msEdgeSyncPromo,msEdgeSigninPromo,"
        "msEdgeFirstRunExperience,msEdgeWelcomePage,msEdgeAccountBubble",
        "--disable-sync",
        "--disable-extensions",
        "--disable-background-networking",
    ]
    proc = subprocess.Popen(args)
    proc.wait()


if __name__ == "__main__":
    main()
