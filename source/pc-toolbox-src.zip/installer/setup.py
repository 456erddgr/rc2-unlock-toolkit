# -*- coding: utf-8 -*-
"""
RC2 搞机工具箱 - 安装程序（图形界面 exe）
作者：软糖布丁
"""
import os
import sys
import shutil
import subprocess
import tkinter as tk
from tkinter import messagebox

APP_NAME = "RC2 搞机工具箱"
APP_VER = "4.0"
AUTHOR = "软糖布丁"
EXE_NAME = "RC2搞机工具箱.exe"
FOLDER = "RC2DeviceToolbox"

BG = "#0b0d12"
CARD = "#181d29"
TXT = "#f5f7fa"
TXT2 = "#9ba5bd"
TXT3 = "#5d6678"
BLUE = "#0a84ff"
GREEN = "#32d74b"
RED = "#ff453a"
STROKE = "#2b3244"
FONT = "Microsoft YaHei UI"


def res_dir():
    if getattr(sys, "frozen", False):
        return getattr(sys, "_MEIPASS", os.path.dirname(sys.executable))
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def src_exe():
    base = res_dir()
    for cand in (os.path.join(base, EXE_NAME),
                 os.path.join(os.path.dirname(base), "dist", EXE_NAME),
                 os.path.join(base, "dist", EXE_NAME)):
        if os.path.isfile(cand):
            return cand
    return None


def dest_dir():
    return os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                        FOLDER)


RISK = """本软件（RC2 搞机工具箱）是给 DJI RC2 遥控器使用的第三方工具，
作者：软糖布丁。它不是大疆官方软件，也未获得大疆任何授权或认可。

本软件会通过 adb / root 直接读写设备底层参数，包括 CPU/GPU 频率、
温控、虚拟内存（zram/swap）、系统属性、Magisk 模块、分区镜像等。

可能导致的后果：
  1. 设备过热、卡死、自动重启
  2. 系统无法启动（变砖）、屏幕黑屏
  3. 数据丢失（分区刷写错误不可恢复）
  4. 官方保修失效

作者不对任何数据丢失、设备损坏、保修失效承担责任。
请在操作前自行备份重要数据。

★ 绝对不要做：
  • 不要 unexport pwmchip0（屏幕背光，会黑屏）
  • 不要关闭 zram 后不重新开启（会卡死）
  • 除 dji_apk 外的数据分区不要刷回（会显示"损坏"）

点「同意并安装」表示你已理解并自愿承担全部风险。
"""


def rr(cv, x1, y1, x2, y2, r, fill, outline=None):
    import math
    r = max(0, min(r, (x2 - x1) // 2, (y2 - y1) // 2))
    pts = []
    for cx, cy, a0, a1 in ((x2 - r, y1 + r, -90, 0), (x2 - r, y2 - r, 0, 90),
                           (x1 + r, y2 - r, 90, 180), (x1 + r, y1 + r, 180, 270)):
        for i in range(9):
            ang = math.radians(a0 + (a1 - a0) * i / 8.0)
            pts.append(cx + r * math.cos(ang))
            pts.append(cy + r * math.sin(ang))
    kw = {"fill": fill, "smooth": True, "outline": outline or fill, "width": 1}
    return cv.create_polygon(pts, **kw)


class Btn(tk.Canvas):
    def __init__(self, master, text, cmd, color=BLUE, w=180, h=42, fs=11):
        tk.Canvas.__init__(self, master, width=w, height=h, bg=BG,
                           highlightthickness=0, bd=0)
        self._cmd = cmd
        self._c = color
        self._w, self._h = w, h
        self._t = text
        self._fs = fs
        self._dis = False
        self._draw(color)
        self.bind("<Button-1>", lambda e: self._click())
        self.bind("<Enter>", lambda e: self._draw(self._lighter()))
        self.bind("<Leave>", lambda e: self._draw(color))

    def _lighter(self):
        h = self._c.lstrip("#")
        r, g, b = (int(h[i:i+2], 16) for i in (0, 2, 4))
        return "#%02x%02x%02x" % (min(255, r+28), min(255, g+28), min(255, b+28))

    def _draw(self, fill):
        self.delete("all")
        rr(self, 1, 1, self._w-1, self._h-1, 9, fill)
        self.create_text(self._w//2, self._h//2, text=self._t,
                         fill="#ffffff" if not self._dis else TXT3,
                         font=(FONT, self._fs, "bold"))

    def _click(self):
        if not self._dis and self._cmd:
            self._cmd()

    def disable(self):
        self._dis = True
        self._draw(CARD)


class Setup:
    def __init__(self, root):
        self.root = root
        self.agreed = False
        self.installed = False
        root.overrideredirect(True)
        root.configure(bg=BG)
        w, h = 780, 640
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        root.geometry("%dx%d+%d+%d" % (w, h, (sw-w)//2, (sh-h)//2))
        self._build()
        self._fade()

    def _build(self):
        head = tk.Frame(self.root, bg="#101319", height=86)
        head.pack(fill="x")
        head.pack_propagate(False)
        tk.Label(head, text="RC2 搞机工具箱", bg="#101319", fg=TXT,
                 font=(FONT, 18, "bold")).pack(anchor="w", padx=24, pady=(16, 0))
        tk.Label(head, text="版本 v%s    作者：%s" % (APP_VER, AUTHOR),
                 bg="#101319", fg=TXT2, font=(FONT, 9)).pack(anchor="w", padx=24)

        close = tk.Canvas(head, width=28, height=28, bg="#101319",
                          highlightthickness=0, bd=0)
        close.place(relx=1.0, x=-18, y=16, anchor="ne")
        c = close.create_text(14, 14, text="✕", fill=TXT2,
                              font=(FONT, 13, "bold"))
        close.bind("<Button-1>", lambda e: self.root.destroy())
        close.bind("<Enter>", lambda e: close.itemconfig(c, fill=RED))
        close.bind("<Leave>", lambda e: close.itemconfig(c, fill=TXT2))
        head.bind("<Button-1>", self._drag)
        head.bind("<B1-Motion>", self._move)
        head._d = None

        body = tk.Frame(self.root, bg=BG)
        body.pack(fill="both", expand=True, padx=20, pady=14)

        tk.Label(body, text="安装位置", bg=BG, fg=TXT2,
                 font=(FONT, 9), anchor="w").pack(fill="x")
        tk.Label(body, text=dest_dir(), bg=BG, fg=BLUE,
                 font=(FONT, 9), anchor="w").pack(fill="x", pady=(0, 10))

        tk.Label(body, text="使用前必读（免责声明）", bg=BG, fg=TXT,
                 font=(FONT, 11, "bold"), anchor="w").pack(fill="x")
        box = tk.Frame(body, bg=CARD)
        box.pack(fill="both", expand=True, pady=(6, 12))
        txt = tk.Text(box, bg="#090b11", fg=TXT2, bd=0,
                      font=(FONT, 9), wrap="word")
        sb = tk.Scrollbar(box, bg=STROKE, troughcolor=CARD, bd=0,
                          highlightthickness=0, width=10, command=txt.yview)
        sb.pack(side="right", fill="y")
        txt.pack(side="left", fill="both", expand=True, padx=10, pady=8)
        txt.configure(yscrollcommand=sb.set)
        txt.insert("1.0", RISK)
        txt.configure(state="disabled")

        self.status = tk.Label(body, text="请阅读上述条款后点击「同意并安装」",
                               bg=BG, fg=TXT3, font=(FONT, 9), anchor="w")
        self.status.pack(fill="x")

        foot = tk.Frame(self.root, bg="#101319", height=72)
        foot.pack(fill="x")
        foot.pack_propagate(False)
        self.btn_cancel = Btn(foot, "退出", self.root.destroy, CARD, 100, 40, 10)
        self.btn_cancel.pack(side="right", padx=(8, 20), pady=16)
        self.btn_ok = Btn(foot, "同意并安装", self._install, GREEN, 170, 40, 10)
        self.btn_ok.pack(side="right", padx=8, pady=16)
        self.btn_run = Btn(foot, "立即运行", self._run, BLUE, 130, 40, 10)

    def _drag(self, e):
        self.root._d = (e.x_root - self.root.winfo_x(),
                        e.y_root - self.root.winfo_y())

    def _move(self, e):
        d = getattr(self.root, "_d", None)
        if d:
            self.root.geometry("+%d+%d" % (e.x_root-d[0], e.y_root-d[1]))

    def _fade(self):
        try:
            self.root.attributes("-alpha", 0.0)
        except Exception:
            return
        def step(i, n=10):
            if i > n:
                try: self.root.attributes("-alpha", 1.0)
                except Exception: pass
                return
            try: self.root.attributes("-alpha", i/float(n))
            except Exception: return
            self.root.after(16, lambda: step(i+1, n))
        step(1)

    def _install(self):
        self.btn_ok.disable()
        self.status.config(text="正在安装…", fg=BLUE)
        self.root.update()

        src = src_exe()
        if not src:
            self.status.config(text="安装失败：找不到主程序", fg=RED)
            messagebox.showerror("安装失败",
                                 "找不到 " + EXE_NAME + "\n\n"
                                 "请确认安装包完整。")
            self.btn_ok.disable()
            return

        dest = dest_dir()
        try:
            os.makedirs(dest, exist_ok=True)
            target = os.path.join(dest, EXE_NAME)
            self.status.config(text="复制程序文件…")
            self.root.update()
            shutil.copy2(src, target)
            self.status.config(text="创建桌面快捷方式…")
            self.root.update()
            ok1 = self._shortcut(
                os.path.join(os.path.expanduser("~"), "Desktop"),
                target, dest)
            self.status.config(text="创建开始菜单项…")
            self.root.update()
            start_menu = os.path.join(
                os.environ.get("APPDATA", ""),
                "Microsoft", "Windows", "Start Menu", "Programs")
            ok2 = self._shortcut(os.path.join(start_menu, APP_NAME),
                                 target, dest)

            self.installed = True
            msg = ("安装完成！" if ok1 or ok2 else "已安装，但快捷方式创建失败")
            self.status.config(text=msg + "  位置：" + dest, fg=GREEN)
            self.btn_ok.disable()
            self.btn_cancel.pack_forget()
            self.btn_run.pack(side="right", padx=(8, 20), pady=16)
            self.btn_run._cmd = lambda: self._run()
        except Exception as e:
            self.status.config(text="安装失败：" + str(e), fg=RED)
            messagebox.showerror("安装失败", str(e))

    def _shortcut(self, folder, target, workdir):
        try:
            os.makedirs(folder, exist_ok=True)
            name = os.path.join(folder, APP_NAME + ".lnk")
            ps = (
                '$s=(New-Object -ComObject WScript.Shell).CreateShortcut("%s");'
                '$s.TargetPath="%s";'
                '$s.WorkingDirectory="%s";'
                '$s.Description="%s - %s";'
                '$s.Save()'
            ) % (name, target, workdir, APP_NAME, AUTHOR)
            r = subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps],
                capture_output=True, timeout=30,
                creationflags=0x08000000 if os.name == "nt" else 0)
            return os.path.isfile(name)
        except Exception:
            return False

    def _run(self):
        dest = dest_dir()
        target = os.path.join(dest, EXE_NAME)
        if os.path.isfile(target):
            subprocess.Popen([target], cwd=dest,
                             creationflags=0x00000008 if os.name == "nt" else 0)
        self.root.destroy()


def main():
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            import ctypes
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass
    root = tk.Tk()
    Setup(root)
    root.mainloop()


if __name__ == "__main__":
    main()
