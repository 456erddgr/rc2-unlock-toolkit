# -*- coding: utf-8 -*-
import os
from PIL import Image
ROOT = r"E:\我的项目\RC2-DeviceToolbox"
src = os.path.join(ROOT, "app.png")
dst = os.path.join(ROOT, "installer", "ui", "logo.png")
if os.path.isfile(src):
    im = Image.open(src).convert("RGBA")
    im.save(dst)
    print("logo ->", dst, os.path.getsize(dst))
else:
    print("missing", src)
