# -*- coding: utf-8 -*-
"""安装器的本地 HTTP 服务（只用标准库）"""
import json
import os
import posixpath
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlparse

UI_BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ui")

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
}


def make_handler(api):
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *a):
            pass

        def _send(self, code, body, ctype="application/json; charset=utf-8"):
            if isinstance(body, str):
                body = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            path = unquote(urlparse(self.path).path)
            if path in ("/", ""):
                path = "/index.html"
            rel = posixpath.normpath(path).lstrip("/")
            if rel.startswith(".."):
                return self._send(403, "forbidden")
            full = os.path.join(UI_BASE, rel.replace("/", os.sep))
            if not os.path.isfile(full):
                return self._send(404, "not found")
            ext = os.path.splitext(full)[1].lower()
            with open(full, "rb") as f:
                data = f.read()
            self._send(200, data, MIME.get(ext, "application/octet-stream"))

        def do_POST(self):
            path = unquote(urlparse(self.path).path)
            if not path.startswith("/api/"):
                return self._send(404, "no api")
            name = path[5:]
            fn = getattr(api, name, None)
            if fn is None:
                return self._send(200, json.dumps(
                    {"ok": False, "msg": "unknown api: " + name}))
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {}
            args = payload.get("args") or []
            try:
                res = fn(*args)
            except Exception as e:
                res = {"ok": False, "msg": "%s: %s" % (type(e).__name__, e)}
            self._send(200, json.dumps(res, ensure_ascii=False))

    return Handler


def serve(api, port):
    httpd = ThreadingHTTPServer(("127.0.0.1", port), make_handler(api))
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd


def find_port(start=47820, tries=60):
    import socket
    for p in range(start, start + tries):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("127.0.0.1", p))
            s.close()
            return p
        except OSError:
            continue
    raise RuntimeError("no free port")
