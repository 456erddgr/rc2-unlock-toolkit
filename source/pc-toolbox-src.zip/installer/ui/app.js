const API = '/api/';
let STEP = 1;
let TARGET = '';
let INFO = {};

async function call(m, ...args) {
  const r = await fetch(API + m, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({args: args}),
    signal: AbortSignal.timeout(120000)
  });
  const t = await r.text();
  try { return JSON.parse(t); } catch (e) { return {ok: false, msg: t}; }
}

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function toast(msg) {
  let el = document.querySelector('.toast');
  if (!el) { el = document.createElement('div'); el.className = 'toast';
    document.body.appendChild(el); }
  el.textContent = msg;
  el.classList.add('on');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('on'), 2400);
}

function setStep(n) {
  STEP = n;
  document.querySelectorAll('.step').forEach(el => {
    const s = +el.dataset.s;
    el.classList.toggle('on', s === n);
    el.classList.toggle('done', s < n);
  });
}

const DISCLAIMER = `
<h4>一、这是什么</h4>
<p>RC2 搞机工具箱是给 DJI RC2 遥控器（rc331 / Android 11）用的第三方工具，
作者：软糖布丁。它通过 adb 与 root 直接读写系统底层参数。</p>
<h4>二、它具体会改什么</h4>
<ul>
<li>CPU 三簇上限频率与调度策略、GPU 频率档位</li>
<li>虚拟内存（zram 大小、磁盘 swap 文件、swappiness）</li>
<li>系统属性、Magisk 模块的启用与停用</li>
<li>分区镜像的读取备份与刷写（boot_a / boot_b / dji_apk / vbmeta_a）</li>
<li>开机动画的生成与替换</li>
</ul>
<h4>三、可能导致的后果（<span class="risk">请务必看清楚</span>）</h4>
<ol class="risk">
<li>CPU / GPU 频率设置过高 → 设备过热、卡死、自动重启、电池加速老化。</li>
<li>刷写分区出错 → 系统无法启动（俗称变砖），只能用官方工具或送修恢复。</li>
<li>误操作 pwmchip0（屏幕背光）→ 直接黑屏。急救：<b>sh /data/adb/modules/rc2_allscripts/scripts/fix_screen.sh</b></li>
<li>关闭 zram 或写入超大 swap → 内存耗尽，系统卡死。</li>
<li>解锁或回锁 Bootloader → 官方保修失效；<b>回锁会让遥控器直接变砖，本工具已永久移除该功能。</b></li>
<li>分区写错 → 数据永久丢失，无法恢复。</li>
</ol>
<h4>四、责任声明</h4>
<p>本软件为个人学习与研究用途的第三方工具，<b>与 DJI 大疆公司没有任何关联</b>，
不是官方软件，也未被官方授权或认可。使用者需自行承担全部风险：因使用本软件
导致的任何设备损坏、数据丢失、保修失效、飞行事故或其它损失，作者不承担任何责任。</p>
<h4>五、绝对不要做的事</h4>
<ol>
<li>不要 unexport / export pwmchip0（那是屏幕背光，会黑屏）</li>
<li>不要用 dd 一次性写入超过 1GB 的文件（本机可用内存仅约 1.7GB）</li>
<li>不要把 swappiness 设成超过 100（内核上限）</li>
<li>不要把 extra_free_kbytes 设成超过 32MB（会触发 OOM）</li>
<li>不要刷写 dji_apk 以外的数据分区</li>
<li>不要尝试回锁 Bootloader</li>
</ol>
<h4>六、使用建议</h4>
<p>每次改动前先备份对应分区；一次只改一项，改完观察稳定性；
遇到异常先重启，黑屏则用上面的急救脚本恢复背光。</p>
<h4>七、同意</h4>
<p>点击下方「同意并继续」表示你已完整阅读并理解以上全部条款，
并自愿承担由此带来的一切风险。</p>
`;

function renderTerms() {
  document.getElementById('page').innerHTML = `
  <div class="card">
    <h3>使用前必读 · 免责声明</h3>
    <div class="terms">${DISCLAIMER}</div>
  </div>`;
  document.getElementById('btnNext').textContent = '同意并继续';
  document.getElementById('btnNext').disabled = false;
}

function renderPath() {
  setStep(2);
  document.getElementById('page').innerHTML = `
  <div class="card">
    <h3>选择安装位置</h3>
    <p>工具箱只有一个 exe 文件，所有工具（adb / fastboot / scrcpy / 界面）都已内置在里面，
不需要额外依赖。</p>
    <div class="pathrow">
      <div class="pathbox" id="pathbox">${esc(TARGET)}</div>
      <button class="mini" onclick="chooseDir()">更改…</button>
    </div>
    <div class="tip">建议保持默认路径，装到用户目录不需要管理员权限。</div>
  </div>
  <div class="card">
    <h3>将要创建</h3>
    <p>· 程序文件：RC2搞机工具箱.exe<br>
       · 桌面快捷方式<br>
       · 开始菜单快捷方式<br>
       · 卸载入口（在安装目录里）</p>
  </div>`;
  document.getElementById('btnNext').textContent = '开始安装';
  document.getElementById('btnNext').disabled = false;
}

async function chooseDir() {
  const r = await call('choose_dir');
  if (r && r.ok && r.dir) {
    TARGET = r.dir;
    const el = document.getElementById('pathbox');
    if (el) el.textContent = TARGET;
  }
}

function renderInstall() {
  setStep(3);
  document.getElementById('page').innerHTML = `
  <div class="card">
    <h3>正在安装</h3>
    <p id="instTip">正在解压程序文件…</p>
    <div class="bar"><i id="barFill"></i></div>
    <div class="tip" id="instSub">请稍候，文件较大（约 30MB）</div>
  </div>`;
  document.getElementById('btnNext').disabled = true;
  let p = 0;
  const t = setInterval(() => {
    p = Math.min(92, p + 7 + Math.random() * 8);
    const f = document.getElementById('barFill');
    if (f) f.style.width = p + '%';
  }, 180);
  call('install', TARGET).then(r => {
    clearInterval(t);
    const f = document.getElementById('barFill');
    if (f) f.style.width = (r && r.ok ? 100 : 100) + '%';
    setTimeout(() => {
      if (r && r.ok) {
        renderDone(r);
      } else {
        toast((r && (r.msg || r.err)) || '安装失败');
        document.getElementById('btnNext').disabled = false;
        document.getElementById('btnNext').textContent = '重试';
      }
    }, 420);
  });
}

function renderDone(r) {
  setStep(4);
  document.getElementById('page').innerHTML = `
  <div class="card">
    <div class="done-big">
      <div class="done-ring">✓</div>
      <div class="done-t">安装完成</div>
      <div class="done-s">已安装到：${esc(r.path || TARGET)}</div>
      <label class="chk"><input type="checkbox" id="chkRun" checked>
        立即启动 RC2 搞机工具箱</label>
    </div>
  </div>
  <div class="card">
    <h3>下一步</h3>
    <p>1. 用 USB 线把遥控器连到电脑（需要能传数据，不能只是充电）<br>
       2. 打开工具箱，先在「关于/免责」里读一遍风险<br>
       3. 需要 root 功能时，确认遥控器已装「ADB 直接 ROOT」模块<br>
       4. Fastboot 刷机前，先让遥控器进入 bootloader（工具箱里有按钮）</p>
  </div>`;
  const b = document.getElementById('btnNext');
  b.textContent = '完成并启动';
  b.disabled = false;
  b.dataset.done = '1';
}

async function boot() {
  const h = await call('hello');
  if (h && h.ok) {
    INFO = h;
    TARGET = h.default_dir;
    const pv = document.getElementById('pver');
    if (pv) pv.textContent = 'v' + h.ver;
  }
  renderTerms();
}

document.getElementById('btnQuit').onclick = () => { call('quit'); };

document.getElementById('btnNext').onclick = async () => {
  const b = document.getElementById('btnNext');
  if (STEP === 1) {
    const r = await call('agree');
    if (!r || !r.ok) { toast('写入同意标记失败，请检查磁盘权限'); return; }
    renderPath();
  } else if (STEP === 2) {
    renderInstall();
  } else if (STEP === 4) {
    if (document.getElementById('chkRun') && document.getElementById('chkRun').checked) {
      await call('launch');
    }
    call('quit');
  }
};

boot();
