# ============================================================
# build-apk.ps1 — RC2 APK 通用构建脚本
#
# 用法:
#   .\build-apk.ps1 -Root <项目目录> -Out <输出apk> [-MinApi 30]
#
# 项目目录结构:
#   <Root>/AndroidManifest.xml
#   <Root>/res/              (可选)
#   <Root>/src/              (Java 源码根)
#
# 重要: aapt2 对含中文的绝对路径会编码失败，因此脚本会
#       cd 到项目目录，全程使用相对路径。
# ============================================================

param(
    [Parameter(Mandatory=$true)][string]$Root,
    [Parameter(Mandatory=$true)][string]$Out,
    [string]$MinApi = "30"
)

$ErrorActionPreference = 'Stop'

$SDK  = 'E:\我的项目\rc331work\sdk'
$JDK  = 'C:\Program Files\Microsoft\jdk-21.0.12.101-hotspot'
$JAVA = "$JDK\bin\java.exe"
$JAVAC= "$JDK\bin\javac.exe"
$SEVENZIP = 'C:\Program Files\7-Zip\7z.exe'

$Root = (Resolve-Path $Root).Path
if (Test-Path "$Root\build") { Remove-Item "$Root\build" -Recurse -Force }
New-Item -ItemType Directory -Path "$Root\build" | Out-Null

# 输出路径转为绝对（在 cd 之前解析）
if (-not [System.IO.Path]::IsPathRooted($Out)) { $Out = Join-Path $Root $Out }

Push-Location $Root
try {
    Write-Host "[1/7] aapt2 compile"
    if (Test-Path 'res') {
        & "$SDK\aapt2.exe" compile --dir res -o build/res.zip
        if ($LASTEXITCODE -ne 0) { throw "aapt2 compile 失败" }
    }

    Write-Host "[2/7] aapt2 link"
    $linkArgs = @('link','-o','build/base.apk','-I',"$SDK\android.jar",
                  '--manifest','AndroidManifest.xml','--java','build/gen','--auto-add-overlay')
    if (Test-Path 'build/res.zip') { $linkArgs += 'build/res.zip' }
    & "$SDK\aapt2.exe" @linkArgs
    if ($LASTEXITCODE -ne 0) { throw "aapt2 link 失败" }

    Write-Host "[3/7] javac"
    New-Item -ItemType Directory -Path 'build/classes' -Force | Out-Null
    $javaFiles = @()
    if (Test-Path 'src') { $javaFiles += (Get-ChildItem -Path 'src' -Recurse -Filter *.java | ForEach-Object { $_.FullName }) }
    if (Test-Path 'build/gen') { $javaFiles += (Get-ChildItem -Path 'build/gen' -Recurse -Filter *.java | ForEach-Object { $_.FullName }) }
    if ($javaFiles.Count -gt 0) {
        # 注意：必须用 -classpath 而不是 -bootclasspath。
        # -bootclasspath 会屏蔽 JDK 的 java.lang.invoke.LambdaMetafactory，
        # 导致所有 lambda 表达式报"找不到符号 metafactory"。
        & $JAVAC -encoding UTF-8 -source 8 -target 8 -classpath "$SDK\android.jar" `
                 -d 'build/classes' -Xlint:-options @javaFiles
        if ($LASTEXITCODE -ne 0) { throw "javac 失败" }
    }

    Write-Host "[4/7] d8"
    $classFiles = @(Get-ChildItem -Path 'build/classes' -Recurse -Filter *.class | ForEach-Object { $_.FullName })
    if ($classFiles.Count -gt 0) {
        # 用 r8.jar 的 D8 入口。build-tools 自带的 d8.jar（8.2.2-dev）在 JDK21 下
        # 处理含匿名内部类的代码会抛 NullPointerException: String.length()。
        & $JAVA -cp "$SDK\r8.jar" com.android.tools.r8.D8 --min-api $MinApi `
                --lib "$SDK\android.jar" --output 'build' @classFiles
        if ($LASTEXITCODE -ne 0) { throw "d8 失败" }
    }

    Write-Host "[5/7] 打包"
    Copy-Item 'build/base.apk' 'build/unsigned.apk'
    if (Test-Path 'build/classes.dex') {
        # 关键: 必须进 APK 根目录且名字就叫 classes.dex。
        # 先复制成临时目录里的 classes.dex，再 cd 进去打包，
        # 否则 7z 会把 "build\classes.dex" 这个带路径的名字塞进去，
        # 导致安装时报 INSTALL_FAILED_INVALID_APK: code is missing。
        $stage = 'build\dexstage'
        New-Item -ItemType Directory -Path $stage -Force | Out-Null
        Copy-Item 'build/classes.dex' "$stage\classes.dex" -Force
        Push-Location $stage
        try {
            & $SEVENZIP a -tzip '..\unsigned.apk' 'classes.dex' | Out-Null
        } finally { Pop-Location }
        Remove-Item $stage -Recurse -Force
    }

    Write-Host "[6/7] zipalign"
    & "$SDK\zipalign.exe" -f -p 4 'build/unsigned.apk' 'build/aligned.apk'
    if ($LASTEXITCODE -ne 0) { throw "zipalign 失败" }

    Write-Host "[7/7] 签名"
    & $JAVA -cp "$SDK\lib\apksigner.jar" com.android.apksigner.ApkSignerTool sign `
        --ks "$SDK\debug.keystore" --ks-pass pass:rc2debug123 --key-pass pass:rc2debug123 `
        --ks-key-alias rc2debug --min-sdk-version $MinApi `
        --out $Out 'build/aligned.apk'
    if ($LASTEXITCODE -ne 0) { throw "签名失败" }

    Write-Host ""
    Write-Host "构建成功: $Out" -ForegroundColor Green
    Get-Item $Out | Select-Object Name, Length | Format-List
}
finally {
    Pop-Location
}
