package com.rc2.toolbox;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** 应用页：第三方应用管理 + 大疆隐藏软件显示/恢复 */
public class AppsPage {
    public static View build(Context c, MainActivity host) {
        LinearLayout page = UI.page(c);
        LinearLayout hideCard = UI.card(c);
        hideCard.addView(UI.sectionTitle(c, "大疆隐藏软件（已禁用）"));
        TextView loading = UI.dim(c, "读取中…");
        hideCard.addView(loading);
        page.addView(hideCard);

        LinearLayout appCard = UI.card(c);
        appCard.addView(UI.sectionTitle(c, "第三方应用"));
        TextView loading2 = UI.dim(c, "读取中…");
        appCard.addView(loading2);
        page.addView(appCard);

        host.runBg(() -> {
            RootShell.Result r = RootShell.exec("pm list packages -d 2>/dev/null");
            List<String> disabled = new ArrayList<>();
            for (String l : r.out.split("\n")) {
                String t = l.trim();
                if (t.startsWith("package:")) disabled.add(t.substring(8).trim());
            }
            List<ApplicationInfo> apps = c.getPackageManager().getInstalledApplications(
                    PackageManager.MATCH_ALL);
            List<String> third = new ArrayList<>();
            List<String> thirdLabel = new ArrayList<>();
            for (ApplicationInfo a : apps) {
                if ((a.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                    third.add(a.packageName);
                    thirdLabel.add(a.loadLabel(c.getPackageManager()).toString());
                }
            }
            final List<String> fDisabled = disabled;
            final List<String> fThird = third;
            final List<String> fThirdLabel = thirdLabel;
            host.toast("已读取: 隐藏 " + fDisabled.size() + " / 第三方 " + fThird.size());
            uiRender(host, () -> {
                hideCard.removeView(loading);
                if (fDisabled.isEmpty()) hideCard.addView(UI.dim(c, "没有已禁用的应用（大疆隐藏软件需先被系统隐藏）"));
                for (String pkg : fDisabled) {
                    hideCard.addView(appRow(c, host, pkg, true));
                }
                appCard.removeView(loading2);
                for (int i = 0; i < fThird.size(); i++) {
                    appCard.addView(appRow(c, host, fThird.get(i), false));
                }
            });
        });
        return UI.scroll(c, page);
    }

    private static void uiRender(MainActivity host, Runnable r) {
        host.post(r);
    }

    private static View appRow(Context c, MainActivity host, final String pkg, boolean hidden) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UI.dp(5), 0, UI.dp(5));
        TextView name = new TextView(c);
        name.setText(hidden ? pkg : labelOf(c, pkg));
        name.setTextSize(13);
        name.setTextColor(0xFFFFFFFF);
        name.setMaxLines(1);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(name);
        TextView open = UI.button2(c, "打开");
        TextView stop = UI.button2(c, "停止");
        TextView en = UI.button2(c, hidden ? "恢复" : "禁用");
        open.setTextSize(12); open.setPadding(UI.dp(10), UI.dp(5), UI.dp(10), UI.dp(5));
        stop.setTextSize(12); stop.setPadding(UI.dp(10), UI.dp(5), UI.dp(10), UI.dp(5));
        en.setTextSize(12); en.setPadding(UI.dp(10), UI.dp(5), UI.dp(10), UI.dp(5));
        LinearLayout btns = new LinearLayout(c);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.addView(open); btns.addView(stop); btns.addView(en);
        row.addView(btns);
        open.setOnClickListener(v -> host.runBg(() -> {
            Intent i = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) { host.toast(pkg + " 无启动入口"); return; }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        }));
        stop.setOnClickListener(v -> host.runBg(() -> {
            RootShell.Result rr = RootShell.exec("am force-stop " + pkg);
            host.toast("停止 " + pkg + (rr.isSuccess() ? " 完成" : " 失败"));
        }));
        en.setOnClickListener(v -> host.runBg(() -> {
            RootShell.Result rr = RootShell.exec(hidden
                    ? "pm enable " + pkg : "pm disable-user --user 0 " + pkg);
            host.toast((hidden ? "恢复" : "禁用") + " " + pkg + (rr.isSuccess() ? " 完成" : " 失败"));
        }));
        return row;
    }

    private static String labelOf(Context c, String pkg) {
        try {
            ApplicationInfo a = c.getPackageManager().getApplicationInfo(pkg, 0);
            return a.loadLabel(c.getPackageManager()).toString();
        } catch (Exception e) { return pkg; }
    }
}
