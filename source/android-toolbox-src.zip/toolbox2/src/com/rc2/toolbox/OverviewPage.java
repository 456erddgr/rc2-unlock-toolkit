package com.rc2.toolbox;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 总览页：内存/swap/CPU/GPU/温度/电池/权限模式，全彩色状态 */
public class OverviewPage {

    public static View build(Context c, MainActivity host) {
        LinearLayout page = UI.page(c);

        // 顶部大数字卡片（当前状态）
        LinearLayout hero = UI.card(c);
        page.addView(hero);

        // 硬件信息
        LinearLayout hw = UI.card(c);
        hw.addView(UI.sectionTitle(c, "硬件状态"));
        page.addView(hw);

        // 虚拟内存
        LinearLayout swap = UI.card(c);
        swap.addView(UI.sectionTitle(c, "虚拟内存"));
        page.addView(swap);

        // 权限
        LinearLayout perm = UI.card(c);
        perm.addView(UI.sectionTitle(c, "权限与环境"));
        page.addView(perm);

        refresh(c, host, hero, hw, swap, perm);

        TextView btn = UI.button(c, "刷新数据", UI.ACCENT);
        btn.setOnClickListener(v -> {
            refresh(c, host, hero, hw, swap, perm);
            host.toast("已刷新");
        });
        LinearLayout btnCard = UI.card(c);
        btnCard.addView(btn);
        page.addView(btnCard);

        return UI.scroll(c, page);
    }

    private static void refresh(Context c, MainActivity host, LinearLayout hero,
                               LinearLayout hw, LinearLayout swap, LinearLayout perm) {
        MemInfo.Mem m = MemInfo.get();

        // ---- 顶部：内存大数字 ----
        rebuild(hero, c);
        int pct = m.totalKb > 0 ? (int) ((m.totalKb - m.availKb) * 100 / m.totalKb) : 0;
        TextView big = new TextView(c);
        big.setText("内存占用 " + pct + "%");
        big.setTextSize(26);
        big.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        big.setTextColor(UI.levelColor(pct));
        big.setGravity(Gravity.CENTER);
        big.setPadding(0, UI.dp(4), 0, UI.dp(2));
        hero.addView(big);

        TextView sub = new TextView(c);
        sub.setText("可用 " + MemInfo.mb(m.availKb) + " / 总共 " + MemInfo.mb(m.totalKb));
        sub.setTextSize(13);
        sub.setTextColor(UI.TEXT_DIM);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, 0, 0, UI.dp(6));
        hero.addView(sub);

        // 内存进度条（彩色的）
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackground(UI.rounded(UI.CARD_HI, UI.dp(4), 0, 0));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, UI.dp(7));
        blp.topMargin = UI.dp(2);
        blp.bottomMargin = UI.dp(4);
        bar.setLayoutParams(blp);
        View fill = new View(c);
        fill.setBackground(UI.rounded(UI.levelColor(pct), UI.dp(4), 0, 0));
        fill.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(0.01f, pct / 100f)));
        View rest = new View(c);
        rest.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(0.01f, 1f - pct / 100f)));
        bar.addView(fill);
        bar.addView(rest);
        hero.addView(bar);

        // ---- 硬件 ----
        rebuild(hw, c);
        hw.addView(UI.kvRow(c, "CPU 策略", CpuGpu.governor(), UI.ACCENT2));
        hw.addView(UI.kvRow(c, "CPU 频率", CpuGpu.curFreqMhz(), UI.ACCENT));
        hw.addView(UI.kvRow(c, "GPU 频率", CpuGpu.gpuCurMhz(), UI.ACCENT));

        long cpuT = m.cpuTempC;
        hw.addView(UI.kvRow(c, "CPU 温度",
                cpuT > -100 ? cpuT + "℃" : "读取受限", UI.tempColor(cpuT)));

        if (m.batteryPct >= 0) {
            int bp = (int) m.batteryPct;
            String txt = bp + "%" + (m.charging ? " 充电中" : "");
            hw.addView(UI.kvRow(c, "电池", txt,
                    bp <= 20 ? UI.DANGER : (bp <= 40 ? UI.WARN : UI.OK)));
            if (m.batteryTempC > -100)
                hw.addView(UI.kvRow(c, "电池温度", m.batteryTempC + "℃", UI.TEXT_DIM));
        } else {
            hw.addView(UI.kvRow(c, "电池", "读取失败", UI.DANGER));
        }

        // ---- 虚拟内存 ----
        rebuild(swap, c);
        if (m.diskActive) {
            swap.addView(UI.kvRow(c, "磁盘 swap",
                    MemInfo.mb(m.diskSwapKb) + "（已用 " + MemInfo.mb(m.diskUsedKb) + "）", UI.OK));
            swap.addView(UI.kvRow(c, "优先级", String.valueOf(m.diskPriority), UI.TEXT_DIM));
        } else {
            swap.addView(UI.kvRow(c, "磁盘 swap", "未启用", UI.WARN));
        }
        if (m.zramActive) {
            swap.addView(UI.kvRow(c, "zram 压缩",
                    MemInfo.mb(m.zramSizeKb) + "（已用 " + MemInfo.mb(m.zramUsedKb) + "）", UI.OK));
        } else {
            swap.addView(UI.kvRow(c, "zram 压缩", "未启用", UI.TEXT_DIM));
        }

        // ---- 权限 ----
        rebuild(perm, c);
        RootShell.Mode mode = RootShell.detect();
        String modeText;
        int modeColor;
        switch (mode) {
            case ROOT: modeText = "Root 完整权限"; modeColor = UI.OK; break;
            case ADB:  modeText = "ADB 通道（降级）"; modeColor = UI.WARN; break;
            default:   modeText = "受限（仅读取）"; modeColor = UI.DANGER; break;
        }
        perm.addView(UI.kvRow(c, "权限模式", modeText, modeColor));
        perm.addView(UI.kvRow(c, "开机 swap 模块",
                SysFile.exists("/data/adb/modules/rc2_swapfile/swapctl.sh")
                        ? "已安装" : "未安装",
                SysFile.exists("/data/adb/modules/rc2_swapfile/swapctl.sh") ? UI.OK : UI.WARN));
        perm.addView(UI.kvRow(c, "工具箱版本", "v2.1", UI.TEXT_DIM));
    }

    /** 保留标题，清掉后面所有内容 */
    private static void rebuild(LinearLayout card, Context c) {
        int keep = 0;
        // 第一个子是 sectionTitle 则保留
        if (card.getChildCount() > 0) keep = 1;
        if (card.getChildCount() > keep) {
            card.removeViews(keep, card.getChildCount() - keep);
        }
    }
}
