package com.rc2.toolbox;

import java.io.BufferedReader;
import java.io.FileReader;

/** 免 root 安全读系统文件（/proc /sys），全部带兜底 */
public class SysFile {

    public static String read(String path) {
        try {
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new FileReader(path));
            String l;
            while ((l = r.readLine()) != null) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(l);
            }
            r.close();
            return sb.toString().trim();
        } catch (Exception e) {
            return "";
        }
    }

    public static String readLine(String path) {
        try {
            BufferedReader r = new BufferedReader(new FileReader(path));
            String l = r.readLine();
            r.close();
            return l == null ? "" : l.trim();
        } catch (Exception e) {
            return "";
        }
    }

    public static long readLong(String path) { return parseLong(readLine(path)); }

    public static long parseLong(String s) {
        if (s == null || s.isEmpty()) return 0;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((c >= '0' && c <= '9') || (i == 0 && c == '-')) sb.append(c);
            else if (sb.length() > 0) break;
        }
        if (sb.length() == 0 || sb.toString().equals("-")) return 0;
        try { return Long.parseLong(sb.toString()); } catch (Exception e) { return 0; }
    }

    public static java.util.List<String> readLines(String path) {
        java.util.List<String> out = new java.util.ArrayList<>();
        try {
            BufferedReader r = new BufferedReader(new FileReader(path));
            String l;
            while ((l = r.readLine()) != null) {
                String t = l.trim();
                if (!t.isEmpty()) out.add(t);
            }
            r.close();
        } catch (Exception ignored) {}
        return out;
    }

    /** 按任意空白（空格/TAB 混合）切分，这是 /proc/swaps 的正确解析方式 */
    public static String[] splitWs(String s) {
        if (s == null || s.trim().isEmpty()) return new String[0];
        return s.trim().split("\\s+");
    }

    /** 文件/目录是否存在（不走 shell，避免依赖 su） */
    public static boolean exists(String path) {
        try { return new java.io.File(path).exists(); } catch (Exception e) { return false; }
    }
}
