package com.rc2.toolbox;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** RC2 工具箱 v2.0 宿主：左侧苹果风导航 + 内容区 + 测试钩子 */
public class MainActivity extends Activity {
    public static final String TAG = "RC2Toolbox";
    private static final String[] NAV = {"总览", "性能", "风扇", "虚拟内存", "应用", "工具箱", "文件", "模块", "开机动画", "网络", "日志", "电池", "自启", "系统"};
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout navBar, contentWrap;
    private android.widget.ScrollView scrollNav;
    private TextView statusBar;
    private int curPage = -1;
    private TextView[] navItems;

    /** 版本号（从 Manifest 读，供同意页/系统页显示） */
    public String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "2.20";
        }
    }

    private final Runnable statusTick = new Runnable() {
        @Override public void run() {
            try { refreshStatusBar(); } catch (Throwable t) { Log.e(TAG, "tick", t); }
            ui.postDelayed(this, 8000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        // ★ 启动性能修复（v2.25）：绝不在 onCreate 里同步跑 su 命令。
        //   旧版 switchPage(0) 会立刻调总览页，而总览页要跑十几条 su（每条 100-300ms，
        //   且 RootShell.exec 是 synchronized 串行），冷启动实测 2.8 秒白屏 ——
        //   用户点图标后长时间看不到界面，表现为「点了没反应」。
        //   现在：先把骨架 UI 画上屏，再 post 到主线程空闲时加载数据。
        super.onCreate(b);
        UI.init(this);
        if (!AgreementPage.hasAgreed(this)) {
            // ★ 未同意：只显示条款页（纯静态文本，不跑任何 su）
            setContentView(AgreementPage.build(this, this));
            return;
        }
        setContentView(buildRootView());
        // 先让空白骨架上屏（窗口立刻可见，消除白屏等待）
        final Intent it = getIntent();
        ui.post(() -> {
            try {
                boolean hasPage = handleExtras(it);
                // 页面切换本身也会同步跑 su，放在这里时首帧已上屏，
                // 用户看到的是「正在加载」而不是黑屏
                if (!hasPage) switchPage(0);
                ui.post(statusTick);
            } catch (Throwable t) {
                Log.e(TAG, "首屏加载异常", t);
            }
        });
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handleExtras(i); }

    /** 返回 true 表示 extras 已指定页面 */
    private boolean handleExtras(Intent i) {
        if (i == null) return false;
        boolean hasPage = false;
        if (i.hasExtra("page")) {
            int p = i.getIntExtra("page", 0);
            if (p >= 0 && p < NAV.length) { switchPage(p); hasPage = true; }
        }
        if (i.hasExtra("action")) {
            final String a = i.getStringExtra("action");
            int sz = i.getIntExtra("size", -1);
            Log.i(TAG, "test hook action=" + a + " size=" + sz);
            runTestAction(a, sz, i);
        }
        return hasPage;
    }

    /** 构建根视图（主题切换后可重复调用） */
    private android.view.View buildRootView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.HORIZONTAL);
        root.setBackgroundColor(UI.BG);

        // 左导航（苹果风侧栏，紧凑项）
        navBar = new LinearLayout(this);
        navBar.setOrientation(LinearLayout.VERTICAL);
        navBar.setBackgroundColor(0xFF0A0A0C);
        navBar.setPadding(UI.dp(10), UI.dp(12), UI.dp(10), UI.dp(12));
        TextView logo = new TextView(this);
        logo.setText("RC2"); logo.setTextSize(20);
        logo.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        logo.setTextColor(UI.ACCENT);
        logo.setPadding(0, 0, 0, UI.dp(2));
        navBar.addView(logo);
        TextView sub = new TextView(this);
        sub.setText("工具箱 v2.25"); sub.setTextSize(10); sub.setTextColor(UI.TEXT_DIM);
        sub.setPadding(0, 0, 0, UI.dp(6));
        navBar.addView(sub);

        // 主题切换按钮
        LinearLayout themeRow = new LinearLayout(this);
        themeRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView btnMono = new TextView(this);
        btnMono.setText("黑白");
        btnMono.setTextSize(11);
        btnMono.setGravity(Gravity.CENTER);
        btnMono.setPadding(0, UI.dp(5), 0, UI.dp(5));
        btnMono.setTextColor(UI.TEXT);
        btnMono.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btnMono.setBackground(UI.rounded(UI.CARD_HI, UI.dp(6), 0, 0));
        btnMono.setOnClickListener(v -> {
            UI.toggleMono();
            rebuildUi();
        });
        TextView btnLight = new TextView(this);
        btnLight.setText("亮色");
        btnLight.setTextSize(11);
        btnLight.setGravity(Gravity.CENTER);
        btnLight.setPadding(0, UI.dp(5), 0, UI.dp(5));
        btnLight.setTextColor(UI.TEXT);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp2.leftMargin = UI.dp(4);
        btnLight.setLayoutParams(lp2);
        btnLight.setBackground(UI.rounded(UI.CARD_HI, UI.dp(6), 0, 0));
        btnLight.setOnClickListener(v -> {
            UI.toggleLight();
            rebuildUi();
        });
        themeRow.addView(btnMono);
        themeRow.addView(btnLight);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.bottomMargin = UI.dp(8);
        themeRow.setLayoutParams(tlp);
        navBar.addView(themeRow);

        navItems = new TextView[NAV.length];
        for (int i = 0; i < NAV.length; i++) {
            final int idx = i;
            TextView item = new TextView(this);
            item.setText(NAV[i]);
            item.setTextSize(12);
            item.setGravity(Gravity.CENTER_VERTICAL);
            item.setPadding(UI.dp(10), UI.dp(7), UI.dp(6), UI.dp(7));
            item.setTextColor(UI.TEXT_DIM);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ilp.bottomMargin = UI.dp(2);
            item.setLayoutParams(ilp);
            item.setOnClickListener(v -> switchPage(idx));
            navItems[i] = item;
            navBar.addView(item);
        }
        // 13 项放不下，导航改成可滚动
        scrollNav = new android.widget.ScrollView(this);
        scrollNav.setVerticalScrollBarEnabled(false);
        scrollNav.addView(navBar);
        scrollNav.setLayoutParams(new LinearLayout.LayoutParams(UI.dp(116),
                ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(scrollNav);

        // 右侧：状态条 + 内容区
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        statusBar = new TextView(this);
        statusBar.setTextSize(11); statusBar.setTextColor(UI.TEXT_DIM);
        statusBar.setPadding(UI.dp(16), UI.dp(8), UI.dp(16), UI.dp(6));
        right.addView(statusBar);
        contentWrap = new LinearLayout(this);
        contentWrap.setOrientation(LinearLayout.VERTICAL);
        contentWrap.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        right.addView(contentWrap);
        right.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        root.addView(right);
        return root;
    }

    /** 系统文件选择（开机动画素材） */
    public void openDoc(String mime, boolean multi, int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        if (multi) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            toast("文件选择器不可用: " + e.getMessage());
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == BootAnimPage.REQ_VIDEO || req == BootAnimPage.REQ_PHOTOS) {
            BootAnimPage.processResult(this, this, req, res, data);
        }
    }

    /** 主题切换 / 同意条款后由页面调用，重建整个界面 */
    public void rebuildUi() {
        // ★ 同意页点「同意」后会走到这里：此时 hasAgreed 已为 true，
        //    重建出正常主界面；未同意则仍停在条款页。
        if (!AgreementPage.hasAgreed(this)) {
            setContentView(AgreementPage.build(this, this));
            return;
        }
        final int p = curPage;
        setContentView(buildRootView());
        curPage = -1;
        switchPage(p >= 0 ? p : 0);
    }

    private void switchPage(int idx) {
        if (idx == curPage) return;
        curPage = idx;
        highlightNav();
        contentWrap.removeAllViews();
        View page = buildPage(idx);
        if (page != null) {
            contentWrap.addView(page);
            UI.fadeIn(page, 60);
        }
    }

    private void highlightNav() {
        if (navItems == null) return;
        for (int i = 0; i < navItems.length; i++) {
            TextView tv = navItems[i];
            if (tv == null) continue;
            boolean sel = i == curPage;
            boolean light = UI.getTheme() == UI.Theme.LIGHT_COLORFUL
                    || UI.getTheme() == UI.Theme.LIGHT_MONO;
            tv.setTextColor(sel ? (light ? 0xFF000000 : 0xFFFFFFFF) : UI.TEXT_DIM);
            tv.setTypeface(sel ? android.graphics.Typeface.DEFAULT_BOLD
                    : android.graphics.Typeface.DEFAULT);
            tv.setBackground(sel ? UI.rounded(UI.ACCENT, UI.dp(8), 0, 0) : null);
            tv.setPadding(UI.dp(10), UI.dp(7), UI.dp(6), UI.dp(7));
        }
    }

    private View buildPage(int idx) {
        switch (idx) {
            case 0: return OverviewPage.build(this, this);
            case 1: return PerfPage.build(this, this);
            case 2: return FanPage.build(this, this);
            case 3: return SwapPage.build(this, this);
            case 4: return AppsDeepPage.build(this, this);
            case 5: return ToolsPage.build(this, this);
            case 6: return FilePage.build(this, this);
            case 7: return ModulesPage.build(this, this);
            case 8: return BootAnimPage.build(this, this);
            case 9: return NetworkPage.build(this, this);
            case 10: return LogPage.build(this, this);
            case 11: return BatteryPage.build(this, this);
            case 12: return AutoStartPage.build(this, this);
            case 13: return SystemPage.build(this, this);
            default: return null;
        }
    }

    /** 后台执行 + 全局兜底（v1 崩溃主因之一） */
    public void runBg(final Runnable r) {
        new Thread(() -> {
            try {
                r.run();
            } catch (Throwable t) {
                Log.e(TAG, "runBg 异常", t);
                toast("后台任务异常: " + t.getMessage());
            }
        }).start();
    }

    public void toast(final String s) {
        ui.post(() -> Toast.makeText(this, s, Toast.LENGTH_SHORT).show());
    }

    public void post(Runnable r) { ui.post(r); }

    /** 测试钩子：am start --es action <x> 驱动关键动作，toast+logcat 双通道验证 */
    private void runTestAction(final String action, final int size, final Intent src) {
        // ★ 开机动画生成钩子（触摸注入被 DJI ROM 拦截，只能走这里验证）
        // am start ... --es action bootanim_gen --es path /data/local/tmp/a.mp4 --ei fps 24 --ei mode 0
        if ("bootanim_gen".equals(action)) {
            Intent i = (src != null) ? src : getIntent();
            String path = i == null ? null : i.getStringExtra("path");
            int frames = i == null ? 0 : i.getIntExtra("frames", 0);
            int fps = i == null ? 0 : i.getIntExtra("fps", 0);
            int mode = i == null ? -1 : i.getIntExtra("mode", -1);
            android.util.Log.i(TAG, "bootanim hook path=" + path + " frames=" + frames
                    + " fps=" + fps + " mode=" + mode);
            BootAnimPage.testGenerate(this, this, path, frames, fps, mode);
            return;
        }
        if (action.startsWith("swap_")) {
            runBg(() -> {
                boolean r;
                switch (action) {
                    case "swap_on":  r = SwapPage.doEnable(this, size > 0 ? size : 2048); break;
                    case "swap_off": r = SwapPage.doDisable(this); break;
                    default:         r = SwapPage.doResize(this, size > 0 ? size : 1024); break;
                }
                Log.i(TAG, "test " + action + " -> " + r);
                toast("test " + action + " -> " + (r ? "成功" : "失败"));
            });
            return;
        }
        final boolean r;
        switch (action) {
            case "extreme": r = CpuGpu.applyExtreme(); break;
            case "perf":    r = CpuGpu.applyPerf(); break;
            case "bal":     r = CpuGpu.applyBalanced(); break;
            case "save":    r = CpuGpu.applySave(); break;
            case "perm":    r = RootShell.detect() == RootShell.Mode.ROOT; break;
            case "adb":     r = RootShell.detect() == RootShell.Mode.ADB; break;
            case "mono":
                UI.toggleMono();
                ui.post(this::rebuildUi);
                r = true;
                break;
            case "light":
                UI.toggleLight();
                ui.post(this::rebuildUi);
                r = true;
                break;
            default: r = false;
        }
        Log.i(TAG, "test " + action + " -> " + r + " mode=" + RootShell.modeName());
        toast("test " + action + " -> " + (r ? "成功" : "失败"));
    }

    private void refreshStatusBar() {
        MemInfo.Mem m = MemInfo.get();
        String swap = m.diskActive
                ? "swap " + MemInfo.mb(m.diskSwapKb)
                : "swap 未启用";
        String temp = CpuGpu.cpuTempC();
        String cpu = CpuGpu.curFreqMhz();
        String bat = m.batteryPct >= 0 ? m.batteryPct + "%" : "-";
        statusBar.setText("可用 " + MemInfo.mb(m.availKb) + "  ·  " + swap
                + "  ·  " + temp + "℃  ·  CPU " + cpu + "  ·  电池 " + bat
                + "  ·  " + RootShell.modeName());
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacksAndMessages(null);
    }
}
