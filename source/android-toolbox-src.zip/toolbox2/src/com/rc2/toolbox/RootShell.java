package com.rc2.toolbox;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * RootShell v3 —— 三级权限降级
 *
 * 模式：
 *   ROOT  直接 /debug_ramdisk/su -c（最强）
 *   ADB   adb shell 通道（仅 adb shell 可用时，如通过 USB 调试）
 *   NONE  无权限，只做免 root 读取
 *
 * 探测顺序：先试 ROOT，失败试 ADB，都失败则 NONE。
 * 每次操作自动选当前可用模式。
 */
public class RootShell {

    public static final String TAG = "RC2Toolbox";
    public static final String SU = "/debug_ramdisk/su";
    public static final int DEFAULT_TIMEOUT_SEC = 25;
    public static final int LONG_TIMEOUT_SEC = 180;

    public enum Mode { UNKNOWN, ROOT, ADB, NONE }

    private static final ExecutorService POOL = Executors.newCachedThreadPool();
    private static final Object LOCK = new Object();
    private static volatile Process ACTIVE = null;
    private static volatile Mode mode = Mode.UNKNOWN;

    public static class Result {
        public final boolean ok;
        public final int exit;
        public final String out;
        public final boolean timedOut;
        public final Mode usedMode;

        public Result(boolean ok, int exit, String out, boolean timedOut, Mode m) {
            this.ok = ok; this.exit = exit; this.out = out;
            this.timedOut = timedOut; this.usedMode = m;
        }
        public boolean isSuccess() { return ok && exit == 0; }
        public String trim() { return out == null ? "" : out.trim(); }
    }

    public static Mode currentMode() { return mode; }

    /** 探测并缓存当前可用模式 */
    public static Mode detect() {
        synchronized (LOCK) {
            if (mode != Mode.UNKNOWN && mode != Mode.NONE) return mode;
            // 1) 试 ROOT
            Result r = runRaw(SU, "id", 8, Mode.ROOT);
            if (r.trim().contains("uid=0")) {
                mode = Mode.ROOT;
                Log.i(TAG, "权限模式: ROOT");
                return mode;
            }
            // 2) 试 ADB（adb shell 通道：uid 2000 或 shell）
            Result a = runRaw("sh", "id", 8, Mode.ADB);
            String s = a.trim();
            if (s.contains("uid=2000") || s.contains("uid=1000") || s.contains("shell")) {
                mode = Mode.ADB;
                Log.i(TAG, "权限模式: ADB");
                return mode;
            }
            mode = Mode.NONE;
            Log.w(TAG, "权限模式: NONE（仅免 root 读取）");
            return mode;
        }
    }

    /** 执行命令，自动按当前模式降级 */
    public static Result exec(String cmd) { return exec(cmd, DEFAULT_TIMEOUT_SEC); }

    public static Result exec(String cmd, int timeoutSec) {
        Mode m = detect();
        // ★ v2.25：ROOT 模式下优先走常驻 su 会话（5-20ms，而启进程要 100-300ms）。
        //   常驻会话不加 LOCK，它自己有 SHELL_LOCK；否则所有页面会互相阻塞。
        if (m == Mode.ROOT) {
            String viaShell = shellExec(cmd, timeoutSec);
            if (viaShell != null) return new Result(true, 0, viaShell, false, Mode.ROOT);
        }
        synchronized (LOCK) {
            if (m == Mode.ROOT) {
                Result r = runRaw(SU, cmd, timeoutSec, Mode.ROOT);
                if (r.isSuccess() || r.trim().length() > 0) return r;
            }
            // 降级：普通 shell（adb 可用时相当于 adb shell）
            Result r2 = runRaw("sh", cmd, timeoutSec, Mode.ADB);
            if (r2.isSuccess()) return r2;
            return r2;
        }
    }

    public interface Callback { void onResult(Result r); }

    public static void execAsync(String cmd, Callback cb) {
        Thread t = new Thread(() -> {
            Result r = exec(cmd);
            if (cb != null) cb.onResult(r);
        }, "rc2-async");
        t.setDaemon(true);
        t.start();
    }

    // ============================================================
    // ★ v2.25 启动性能修复：持久 su 会话
    //
    // 旧实现每条命令都 Runtime.exec(SU, "-c", cmd)，每次启进程约 100-300ms，
    // 总览页一次要跑十几条 → 冷启动 2.8 秒白屏（用户体感「点了没反应」）。
    // 现在只启一个常驻 su 进程，命令走 stdin 管道 + 哨兵行回读 stdout，
    // 单条命令降到 ~5-20ms。
    // ============================================================
    private static Process SHELL = null;
    private static DataOutputStream SHELL_IN = null;
    private static BufferedReader SHELL_OUT = null;
    private static final Object SHELL_LOCK = new Object();
    private static final String SENTINEL = "__RC2_EOF__";

    private static boolean ensureShell() {
        synchronized (SHELL_LOCK) {
            if (SHELL != null) {
                try {
                    // 进程还活着就直接用
                    SHELL.exitValue();
                    // 走到这里说明已退出，重建
                    closeShellLocked();
                } catch (IllegalThreadStateException alive) {
                    return true;
                } catch (Exception e) {
                    closeShellLocked();
                }
            }
            try {
                SHELL = Runtime.getRuntime().exec(new String[]{SU, "-c", "sh"});
                SHELL_IN = new DataOutputStream(SHELL.getOutputStream());
                SHELL_OUT = new BufferedReader(new InputStreamReader(SHELL.getInputStream()));
                // 消耗掉 su 可能输出的欢迎信息
                try { Thread.sleep(60); } catch (InterruptedException ignored) {}
                return true;
            } catch (Exception e) {
                Log.w(TAG, "su 常驻会话创建失败: " + e.getMessage());
                closeShellLocked();
                return false;
            }
        }
    }

    private static void closeShellLocked() {
        try { if (SHELL_IN != null) SHELL_IN.close(); } catch (Exception ignored) {}
        try { if (SHELL_OUT != null) SHELL_OUT.close(); } catch (Exception ignored) {}
        try { if (SHELL != null) SHELL.destroyForcibly(); } catch (Exception ignored) {}
        SHELL = null; SHELL_IN = null; SHELL_OUT = null;
    }

    /** 通过常驻会话执行一条命令；失败返回 null 让上层回退到 启进程方式 */
    private static String shellExec(String cmd, int timeoutSec) {
        synchronized (SHELL_LOCK) {
            if (!ensureShell()) return null;
            try {
                SHELL_IN.write(cmd.getBytes("UTF-8"));
                SHELL_IN.write('\n');
                SHELL_IN.write(("echo " + SENTINEL + "$?").getBytes("UTF-8"));
                SHELL_IN.write('\n');
                SHELL_IN.flush();

                StringBuilder sb = new StringBuilder();
                String line;
                long deadline = System.currentTimeMillis() + timeoutSec * 1000L;
                while (System.currentTimeMillis() < deadline) {
                    if (SHELL_OUT.ready()) {
                        line = SHELL_OUT.readLine();
                        if (line == null) { closeShellLocked(); return null; }
                        if (line.startsWith(SENTINEL)) return sb.toString().trim();
                        sb.append(line).append('\n');
                    } else {
                        Thread.sleep(3);
                        try { SHELL.exitValue(); closeShellLocked(); return null; }
                        catch (IllegalThreadStateException stillAlive) { /* ok */ }
                    }
                }
                return sb.toString().trim();
            } catch (Exception e) {
                Log.w(TAG, "常驻会话执行失败: " + e.getMessage());
                closeShellLocked();
                return null;
            }
        }
    }

    private static Result runRaw(String binary, String cmd, int timeoutSec, Mode m) {
        try {
            Future<Result> f = POOL.submit(() -> runProcess(binary, cmd, m));
            return f.get(timeoutSec, TimeUnit.SECONDS);
        } catch (java.util.concurrent.TimeoutException te) {
            Log.w(TAG, "超时(" + timeoutSec + "s): " + cmd);
            Process a = ACTIVE;
            if (a != null) {
                try { a.destroyForcibly(); } catch (Exception ignored) {}
            }
            return new Result(false, -1, "执行超时", true, m);
        } catch (Exception e) {
            return new Result(false, -1, "异常: " + e.getMessage(), false, m);
        }
    }

    private static Result runProcess(String binary, String cmd, Mode m) {
        Process p = null;
        try {
            if (binary.equals(SU)) {
                p = Runtime.getRuntime().exec(new String[]{SU, "-c", cmd});
            } else {
                p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            }
            ACTIVE = p;

            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append('\n');
                if (sb.length() > 200 * 1024) break;
            }
            int exit = p.waitFor();
            String out = sb.toString().trim();

            boolean denied = out.contains("Permission denied") || out.contains("not allowed");
            if (denied) {
                return new Result(false, 1, out, false, m);
            }
            return new Result(true, exit, out, false, m);
        } catch (IOException e) {
            return new Result(false, -1, "IO异常: " + e.getMessage(), false, m);
        } catch (Exception e) {
            return new Result(false, -1, e.getMessage(), false, m);
        } finally {
            ACTIVE = null;
            if (p != null) try { p.destroy(); } catch (Exception ignored) {}
        }
    }

    /** 是否具备 root 能力 */
    public static boolean hasRoot() {
        return detect() == Mode.ROOT;
    }

    /** 是否至少能执行 shell（root 或 adb） */
    public static boolean hasShell() {
        Mode m = detect();
        return m == Mode.ROOT || m == Mode.ADB;
    }

    /** 权限模式显示名 */
    public static String modeName() {
        switch (detect()) {
            case ROOT: return "Root";
            case ADB:  return "ADB";
            default:   return "受限";
        }
    }
}
