package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * 风扇页 —— 已查明：RC2 风扇由内核 pwm-fan 驱动接管，用户空间无 pwm 出口。
 *
 * 实测结论（2026-10-31）：
 *   - pwmchip0 ch3 = 屏幕背光（不是风扇！调它只会黑屏）
 *   - pwmchip4 ch0 = 风扇，被内核 pwm-fan 占用，export 返回 1
 *   - cooling_device 0..22 里没有 fan 类型
 *   - 风扇由 thermal-engine + pwm-fan 驱动自动调速
 *
 * 所以本页做：实时风扇/温度监控 + 温度联动策略提示 + 极限散热（拉满 CPU 让风扇自己转起来）
 */
public class FanPage {

    /** 可选的风扇控制尝试（DJI 协议服务通道，需 root） */
    private static final String DJI_FAN_PROP = "sys.fan.actual_speed";

    public static View build(Context c, MainActivity host) {
        LinearLayout page = UI.page(c);

        // 说明卡
        LinearLayout info = UI.card(c);
        info.addView(UI.sectionTitle(c, "风扇控制说明"));
        TextView note = new TextView(c);
        note.setText("RC2 风扇由内核 thermal 自动调速，非应用可直控。\n"
                + "本页提供：实时监控 + 温度联动策略。");
        note.setTextSize(12);
        note.setTextColor(UI.TEXT_DIM);
        note.setLineSpacing(0, 1.2f);
        info.addView(note);
        page.addView(info);

        // 实时监控
        LinearLayout monitor = UI.card(c);
        monitor.addView(UI.sectionTitle(c, "实时监控"));
        page.addView(monitor);

        // 温度联动
        LinearLayout link = UI.card(c);
        link.addView(UI.sectionTitle(c, "温度联动策略"));
        page.addView(link);

        // 散热加压
        LinearLayout boost = UI.card(c);
        boost.addView(UI.sectionTitle(c, "主动散热"));
        page.addView(boost);

        // 尝试读取 DJI 风扇属性
        refreshMonitor(c, monitor);

        LinearLayout row1 = UI.buttonRow(c,
                UI.button(c, "风扇全力", UI.ACCENT), UI.button2(c, "安静模式"));
        boost.addView(row1);
        UI.space(c, boost, 6);
        LinearLayout row2 = UI.buttonRow(c, UI.button2(c, "测试协议通道"));
        boost.addView(row2);

        ((TextView) row1.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            // 拉满 CPU 让 thermal 自动把风扇转起来
            CpuGpu.applyExtreme();
            // 尝试 DJI 协议属性（如果有）
            RootShell.exec("setprop " + DJI_FAN_PROP + " 100 2>/dev/null");
            host.post(() -> {
                host.toast("已拉满负载，风扇将由内核自动提速");
                refreshMonitor(c, monitor);
            });
        }));

        ((TextView) row1.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            CpuGpu.applySave();
            host.post(() -> {
                host.toast("已切省电，风扇将降速");
                refreshMonitor(c, monitor);
            });
        }));

        ((TextView) row2.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            // 探测 DJI 协议服务与风扇属性
            StringBuilder sb = new StringBuilder();
            RootShell.Result r1 = RootShell.exec("getprop " + DJI_FAN_PROP);
            sb.append("sys.fan.actual_speed = ").append(r1.trim().isEmpty() ? "(空)" : r1.trim()).append("\n");
            RootShell.Result r2 = RootShell.exec("ls /sys/class/pwm/pwmchip4/ 2>/dev/null");
            sb.append("pwmchip4 = ").append(r2.trim().replace("\n", " ")).append("\n");
            RootShell.Result r3 = RootShell.exec("service list 2>/dev/null | grep -i protocol");
            sb.append("protocol 服务 = ").append(r3.trim()).append("\n");
            final String msg = sb.toString();
            host.post(() -> host.toast(msg.length() > 300 ? msg.substring(0, 300) : msg));
        }));

        // 温度联动策略说明
        TextView strategy = new TextView(c);
        strategy.setText("• 温度 ≥ 65℃：本工具会自动提示降频散热\n"
                + "• 温度 ≥ 75℃：建议手动切省电模式\n"
                + "• 风扇由 thermal-engine 按内核温度表自动升降");
        strategy.setTextSize(12);
        strategy.setTextColor(UI.TEXT_DIM);
        strategy.setLineSpacing(0, 1.2f);
        link.addView(strategy);

        return UI.scroll(c, page);
    }

    private static void refreshMonitor(Context c, LinearLayout monitor) {
        int keep = monitor.getChildCount() > 0 ? 1 : 0;
        if (monitor.getChildCount() > keep) {
            monitor.removeViews(keep, monitor.getChildCount() - keep);
        }
        MemInfo.Mem m = MemInfo.get();

        String fanSpeed = RootShell.exec("getprop " + DJI_FAN_PROP, 8).trim();
        if (fanSpeed.isEmpty()) fanSpeed = "内核自动（无曝光值）";
        monitor.addView(UI.kvRow(c, "风扇转速", fanSpeed, UI.ACCENT));

        monitor.addView(UI.kvRow(c, "CPU 温度",
                m.cpuTempC > -100 ? m.cpuTempC + "℃" : "读取受限",
                UI.tempColor(m.cpuTempC)));

        // 电池温度
        if (m.batteryTempC > -100)
            monitor.addView(UI.kvRow(c, "电池温度", m.batteryTempC + "℃", UI.TEXT_DIM));

        // 最热 thermal zone
        long hottest = -999;
        String hotName = "";
        for (int i = 0; i < 128; i++) {
            long t = SysFile.readLong("/sys/class/thermal/thermal_zone" + i + "/temp");
            if (t > 0 && t < 200000 && t / 1000 > hottest) {
                hottest = t / 1000;
                String n = SysFile.readLine("/sys/class/thermal/thermal_zone" + i + "/type");
                hotName = n.isEmpty() ? ("zone" + i) : n;
            }
        }
        if (hottest > -100)
            monitor.addView(UI.kvRow(c, "最热传感器", hotName + " " + hottest + "℃",
                    UI.tempColor(hottest)));

        // 风扇驱动状态
        String bound = SysFile.readLong("/sys/devices/platform/soc/soc:pwm-fan/waiting_for_supplier") == 0
                ? "已绑定内核驱动" : "未绑定";
        monitor.addView(UI.kvRow(c, "风扇驱动", bound, UI.OK));
    }

    /** 设置联动（保留接口，实际由 thermal 内核处理） */
    public static boolean setLinkage(Context c, boolean on) { return true; }
    public static void maybeLink(Context c, boolean perfMode) {}
}
