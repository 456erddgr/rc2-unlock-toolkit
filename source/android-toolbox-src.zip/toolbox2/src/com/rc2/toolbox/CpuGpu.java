package com.rc2.toolbox;

/**
 * CPU/GPU 状态与调控
 * 读：全部免 root（sysfs）
 * 写：走 RootShell（自动降级 root → adb）
 */
public class CpuGpu {

    private static final String GPU = "/sys/class/kgsl/kgsl-3d0";
    private static final String CPUF = "/sys/devices/system/cpu/cpu%d/cpufreq/";

    // ---------- 读 ----------

    public static String governor() {
        String s = SysFile.readLine(String.format(CPUF, 0) + "scaling_governor");
        return s.isEmpty() ? "-" : s;
    }

    public static String availGovernors() {
        return SysFile.readLine(String.format(CPUF, 0) + "scaling_available_governors");
    }

    public static long curFreqKhz() {
        return SysFile.readLong(String.format(CPUF, 0) + "scaling_cur_freq");
    }

    public static String curFreqMhz() {
        long hz = curFreqKhz();
        return hz <= 0 ? "-" : (hz / 1000) + "MHz";
    }

    /** CPU 上限：scaling_max_freq 权限是 system:system，普通 app 读不到，需 root */
    public static String cpuMaxMhz() {
        // 先试免 root
        long hz = SysFile.readLong(String.format(CPUF, 0) + "scaling_max_freq");
        if (hz <= 0) {
            // 降级：走 root/adb
            String s = RootShell.exec("cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq", 8).trim();
            hz = SysFile.parseLong(s);
        }
        if (hz <= 0) {
            // 再兜底：用 cpuinfo_max_freq（这个免 root 可读）
            hz = SysFile.readLong(String.format(CPUF, 0) + "cpuinfo_max_freq");
        }
        return hz <= 0 ? "-" : (hz / 1000) + "MHz";
    }

    /** 所有簇的最高频（实测 cpu0=1.958GHz, cpu4=2.4GHz, cpu7=2.707GHz） */
    public static String clusterMaxMhz(int cpu) {
        long hz = SysFile.readLong(String.format(CPUF, cpu) + "cpuinfo_max_freq");
        return hz <= 0 ? "-" : (hz / 1000) + "MHz";
    }

    public static String availCpuFreqs() {
        return SysFile.readLine(String.format(CPUF, 0) + "scaling_available_frequencies");
    }

    public static String gpuFreqs() {
        return SysFile.readLine(GPU + "/gpu_available_frequencies");
    }

    public static String gpuCurMhz() {
        long hz = SysFile.readLong(GPU + "/gpuclk");
        return hz <= 0 ? "-" : (hz / 1000000) + "MHz";
    }

    public static String gpuMaxMhz() {
        long hz = SysFile.readLong(GPU + "/max_gpuclk");
        return hz <= 0 ? "-" : (hz / 1000000) + "MHz";
    }

    /**
     * CPU 温度：优先 *_usr 后缀的常用 zone，读不到再遍历。
     * 免 root 可读 thermal_zone40 等（实测 41300 = 41.3℃）
     */
    public static String cpuTempC() {
        String[] prefer = {"thermal_zone40", "thermal_zone44", "thermal_zone16"};
        for (String z : prefer) {
            long t = SysFile.readLong("/sys/class/thermal/" + z + "/temp");
            if (t > 0 && t < 200000) return String.valueOf(t / 1000);
        }
        for (int i = 0; i < 128; i++) {
            String type = SysFile.readLine("/sys/class/thermal/thermal_zone" + i + "/type");
            if (type.contains("cpu-0-0-usr") || type.contains("cpuss-0-usr")) {
                long t = SysFile.readLong("/sys/class/thermal/thermal_zone" + i + "/temp");
                if (t > 0 && t < 200000) return String.valueOf(t / 1000);
            }
        }
        return "-";
    }

    /** 电池容量：真实节点 aprimary-bat */
    public static String battery() {
        long c = SysFile.readLong("/sys/class/power_supply/aprimary-bat/capacity");
        if (c <= 0) c = SysFile.readLong("/sys/class/power_supply/battery/capacity");
        return c <= 0 ? "-" : c + "%";
    }

    // ---------- 写（走 RootShell，自动降级） ----------

    private static String maxOf(String s) {
        long best = 0;
        for (String p : SysFile.splitWs(s)) {
            long v = SysFile.parseLong(p);
            if (v > best) best = v;
        }
        return best > 0 ? String.valueOf(best) : "";
    }

    private static String minOf(String s) {
        long best = Long.MAX_VALUE;
        for (String p : SysFile.splitWs(s)) {
            long v = SysFile.parseLong(p);
            if (v > 0 && v < best) best = v;
        }
        return best != Long.MAX_VALUE ? String.valueOf(best) : "";
    }

    private static void setGovernor(String gov) {
        StringBuilder sb = new StringBuilder();
        for (int c = 0; c < 8; c++) {
            sb.append("echo ").append(gov).append(" > ")
              .append(String.format(CPUF, c)).append("scaling_governor 2>/dev/null; ");
        }
        RootShell.exec(sb.toString());
    }

    private static void setCpuMax(String hz) {
        if (hz == null || hz.isEmpty()) return;
        StringBuilder sb = new StringBuilder();
        for (int c = 0; c < 8; c++) {
            sb.append("echo ").append(hz).append(" > ")
              .append(String.format(CPUF, c)).append("scaling_max_freq 2>/dev/null; ");
        }
        RootShell.exec(sb.toString());
    }

    private static boolean setGpuMax(String hz) {
        if (hz == null || hz.isEmpty()) return false;
        return RootShell.exec("echo " + hz + " > " + GPU + "/max_gpuclk 2>/dev/null").isSuccess();
    }

    /** 省电：schedutil + CPU 最低频 + GPU 最低 */
    public static boolean applySave() {
        setGovernor("schedutil");
        setCpuMax("300000");
        return setGpuMax(minOf(gpuFreqs()));
    }

    /** 均衡：schedutil + 全频 + GPU 全速 */
    public static boolean applyBalanced() {
        setGovernor("schedutil");
        setCpuMax(maxOf(availCpuFreqs()));
        return setGpuMax(maxOf(gpuFreqs()));
    }

    /** 性能：performance + 全频 + GPU 全速 */
    public static boolean applyPerf() {
        setGovernor("performance");
        setCpuMax(maxOf(availCpuFreqs()));
        return setGpuMax(maxOf(gpuFreqs()));
    }

    /**
     * 极速：每个 CPU 簇拉到自己的最高频。
     * 实测设备是 3 簇：cpu0-3 小核(1.958GHz) / cpu4-6 大核(2.4GHz) / cpu7 超大核(2.707GHz)。
     * 之前全写 cpu0 的上限（1.958GHz）会浪费大核性能。
     */
    public static boolean applyExtreme() {
        setGovernor("performance");
        // 逐簇拉各自最高
        for (int c = 0; c < 8; c++) {
            String max = SysFile.readLine(String.format(CPUF, c) + "cpuinfo_max_freq");
            if (max.isEmpty()) continue;
            RootShell.exec("echo " + max + " > " + String.format(CPUF, c)
                    + "scaling_max_freq 2>/dev/null");
        }
        setGpuMax(maxOf(gpuFreqs()));
        // 解禁 thermal 限频（cooling_device0/1/2 是 cpufreq，19 是 devfreq）
        RootShell.exec("for i in 0 1 2 19; do echo 0 > /sys/class/thermal/cooling_device$i/cur_state 2>/dev/null; done");
        return true;
    }

    /** 恢复默认：每簇回到 cpuinfo 默认 */

    /** 读每簇最高频，拼成展示串 */
    public static String allClusterMax() {
        StringBuilder sb = new StringBuilder();
        int[] cls = {0, 4, 7};
        for (int i : cls) {
            String m = clusterMaxMhz(i);
            if (sb.length() > 0) sb.append(" / ");
            sb.append("cpu").append(i).append(" ").append(m);
        }
        return sb.toString();
    }
}
