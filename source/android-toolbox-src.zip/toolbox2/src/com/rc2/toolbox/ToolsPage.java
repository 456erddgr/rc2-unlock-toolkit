package com.rc2.toolbox;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 工具页：系统/网络/存储/快捷操作/高级 —— 大量免 root 实用功能 */
public class ToolsPage {

    private static Context ctx;
    private static LinearLayout sysCard, netCard, storageCard, quickCard, advCard;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);

        sysCard = UI.card(c);
        sysCard.addView(UI.sectionTitle(c, "系统详情"));
        page.addView(sysCard);

        netCard = UI.card(c);
        netCard.addView(UI.sectionTitle(c, "网络"));
        page.addView(netCard);

        storageCard = UI.card(c);
        storageCard.addView(UI.sectionTitle(c, "存储"));
        page.addView(storageCard);

        quickCard = UI.card(c);
        quickCard.addView(UI.sectionTitle(c, "快捷操作"));
        page.addView(quickCard);

        advCard = UI.card(c);
        advCard.addView(UI.sectionTitle(c, "高级调控"));
        page.addView(advCard);

        bindButtons(c, host, quickCard, advCard);
        refresh();
        return UI.scroll(c, page);
    }

    private static void bindButtons(Context c, MainActivity host,
                                    LinearLayout quickCard, LinearLayout advCard) {
        LinearLayout r1 = UI.buttonRow(c,
                UI.button2(c, "复制系统信息"), UI.button2(c, "清空缓存"));
        quickCard.addView(r1);
        UI.space(c, quickCard, 6);
        LinearLayout r2 = UI.buttonRow(c,
                UI.button2(c, "屏幕常亮"), UI.button2(c, "重启系统UI"));
        quickCard.addView(r2);
        UI.space(c, quickCard, 6);
        LinearLayout r3 = UI.buttonRow(c,
                UI.button2(c, "清理后台"), UI.button2(c, "查看进程数"));
        quickCard.addView(r3);

        LinearLayout r4 = UI.buttonRow(c,
                UI.button2(c, "GPU 全速"), UI.button2(c, "CPU 全速"));
        advCard.addView(r4);
        UI.space(c, advCard, 6);
        LinearLayout r5 = UI.buttonRow(c,
                UI.button2(c, "解禁温控"), UI.button2(c, "全部恢复"));
        advCard.addView(r5);

        ((TextView) r1.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            final String info = collectSysInfo();
            host.post(() -> {
                try {
                    ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("RC2", info));
                    host.toast("系统信息已复制到剪贴板");
                } catch (Throwable t) { host.toast("复制失败"); }
            });
        }));

        ((TextView) r1.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("rm -rf /data/local/tmp/*.png /data/local/tmp/*.log 2>/dev/null; echo done", 20);
            host.post(() -> { host.toast("缓存已清理"); refresh(); });
        }));

        ((TextView) r2.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = RootShell.exec("svc power stayon true; echo ok", 10).trim().contains("ok");
            host.post(() -> host.toast(ok ? "屏幕将常亮" : "失败"));
        }));

        ((TextView) r2.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("pkill -f com.android.systemui 2>/dev/null; echo done", 15);
            host.post(() -> host.toast("系统UI 已重启"));
        }));

        ((TextView) r3.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("am kill-all 2>/dev/null; echo done", 20);
            host.post(() -> host.toast("已清理后台进程"));
        }));

        ((TextView) r3.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            String n = RootShell.exec("ps -A 2>/dev/null | wc -l", 10).trim();
            host.post(() -> host.toast("当前进程数: " + n));
        }));

        ((TextView) r4.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            String g = maxOfStr(CpuGpu.gpuFreqs());
            RootShell.exec("echo " + g + " > /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null", 12);
            final String mhz = g.isEmpty() ? "失败" : (SysFile.parseLong(g) / 1000000 + "MHz");
            host.post(() -> { host.toast("GPU 上限 -> " + mhz); refresh(); });
        }));

        ((TextView) r4.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            CpuGpu.applyPerf();
            host.post(() -> { host.toast("CPU 已全速"); refresh(); });
        }));

        ((TextView) r5.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i <= 22; i++) {
                sb.append("echo 0 > /sys/class/thermal/cooling_device").append(i)
                  .append("/cur_state 2>/dev/null; ");
            }
            RootShell.exec(sb.toString(), 25);
            host.post(() -> host.toast("温控限频已解禁"));
        }));

        ((TextView) r5.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            CpuGpu.applyBalanced();
            host.post(() -> { host.toast("已恢复均衡"); refresh(); });
        }));
    }

    private static String maxOfStr(String s) {
        long best = 0;
        for (String p : SysFile.splitWs(s)) {
            long v = SysFile.parseLong(p);
            if (v > best) best = v;
        }
        return best > 0 ? String.valueOf(best) : "";
    }

    private static String collectSysInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== RC2 工具箱系统信息 ===\n");
        sb.append("型号: ").append(RootShell.exec("getprop ro.product.model", 8).trim()).append('\n');
        sb.append("Android: ").append(RootShell.exec("getprop ro.build.version.release", 8).trim()).append('\n');
        sb.append("SDK: ").append(RootShell.exec("getprop ro.build.version.sdk", 8).trim()).append('\n');
        sb.append("内核: ").append(RootShell.exec("uname -r", 8).trim()).append('\n');
        sb.append("权限模式: ").append(RootShell.modeName()).append('\n');
        MemInfo.Mem m = MemInfo.get();
        sb.append("内存: ").append(MemInfo.mb(m.availKb)).append('/').append(MemInfo.mb(m.totalKb)).append('\n');
        sb.append("磁盘swap: ").append(MemInfo.mb(m.diskSwapKb)).append('\n');
        sb.append("zram: ").append(MemInfo.mb(m.zramSizeKb)).append('\n');
        sb.append("电池: ").append(m.batteryPct).append("%\n");
        sb.append("CPU温度: ").append(m.cpuTempC).append("℃\n");
        sb.append("CPU当前: ").append(CpuGpu.curFreqMhz()).append('\n');
        sb.append("各簇最高: ").append(CpuGpu.allClusterMax()).append('\n');
        sb.append("GPU: ").append(CpuGpu.gpuCurMhz()).append('\n');
        return sb.toString();
    }

    private static void refresh() {
        if (ctx == null) return;
        MemInfo.Mem m = MemInfo.get();

        rebuild(sysCard);
        sysCard.addView(UI.kvRow(ctx, "型号", RootShell.exec("getprop ro.product.model", 6).trim(), UI.ACCENT));
        sysCard.addView(UI.kvRow(ctx, "Android", RootShell.exec("getprop ro.build.version.release", 6).trim(), UI.ACCENT));
        sysCard.addView(UI.kvRow(ctx, "ABI", RootShell.exec("getprop ro.product.cpu.abi", 6).trim(), UI.TEXT_DIM));
        sysCard.addView(UI.kvRow(ctx, "屏幕", screenRes(), UI.TEXT_DIM));
        sysCard.addView(UI.kvRow(ctx, "内核", shorten(RootShell.exec("uname -r", 6).trim(), 26), UI.TEXT_DIM));

        rebuild(netCard);
        String ip = RootShell.exec("ip addr show wlan0 2>/dev/null | grep 'inet ' | head -1", 12).trim();
        String[] ipParts = SysFile.splitWs(ip);
        String ipStr = ipParts.length >= 2 ? ipParts[1] : "-";
        netCard.addView(UI.kvRow(ctx, "WiFi IP", ipStr, UI.ACCENT));
        String usb = RootShell.exec("getprop sys.usb.config", 6).trim();
        netCard.addView(UI.kvRow(ctx, "USB", usb.isEmpty() ? "-" : usb, usb.contains("adb") ? UI.OK : UI.TEXT_DIM));

        rebuild(storageCard);
        String df = RootShell.exec("df -h /data 2>/dev/null | tail -1", 8).trim();
        String[] p = SysFile.splitWs(df);
        if (p.length >= 5) {
            storageCard.addView(UI.kvRow(ctx, "总容量", p[1], UI.TEXT_DIM));
            storageCard.addView(UI.kvRow(ctx, "已用", p[2] + " (" + p[4] + ")", UI.WARN));
            storageCard.addView(UI.kvRow(ctx, "可用", p[3], UI.OK));
        } else {
            storageCard.addView(UI.kvRow(ctx, "存储", df.isEmpty() ? "-" : df, UI.TEXT_DIM));
        }

        rebuild(advCard);
        String gq = RootShell.exec("cat /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null", 8).trim();
        advCard.addView(UI.kvRow(ctx, "GPU 上限",
                gq.isEmpty() ? "-" : (SysFile.parseLong(gq) / 1000000 + "MHz"), UI.ACCENT2));
        advCard.addView(UI.kvRow(ctx, "CPU 策略", CpuGpu.governor(), UI.ACCENT));
        advCard.addView(UI.kvRow(ctx, "权限模式", RootShell.modeName(),
                RootShell.hasRoot() ? UI.OK : UI.WARN));
        advCard.addView(UI.kvRow(ctx, "可用内存", MemInfo.mb(m.availKb), UI.levelColor(
                m.totalKb > 0 ? (int) (100 - m.availKb * 100 / m.totalKb) : 50)));
    }

    private static String screenRes() {
        try {
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            android.view.WindowManager wm = (android.view.WindowManager)
                    ctx.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                wm.getDefaultDisplay().getRealMetrics(dm);
                return dm.widthPixels + "×" + dm.heightPixels;
            }
        } catch (Throwable ignored) {}
        return "-";
    }

    private static String shorten(String s, int n) {
        return s == null ? "-" : (s.length() > n ? s.substring(0, n) : s);
    }

    private static void rebuild(LinearLayout card) {
        int keep = card.getChildCount() > 0 ? 1 : 0;
        if (card.getChildCount() > keep) card.removeViews(keep, card.getChildCount() - keep);
    }
}
