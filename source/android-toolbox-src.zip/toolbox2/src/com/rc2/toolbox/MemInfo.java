package com.rc2.toolbox;

/** 内存 / swap / 温度 / 电池信息（全部免 root 读，带正确路径） */
public class MemInfo {

    public static class Mem {
        public long totalKb, availKb;
        public long zramSizeKb, zramUsedKb;
        public long diskSwapKb, diskUsedKb;
        public int diskPriority = -1;
        public boolean diskActive = false;
        public boolean zramActive = false;
        public long batteryPct = -1;
        public long batteryTempC = -999;
        public boolean charging = false;
        public long cpuTempC = -999;
    }

    public static Mem get() {
        Mem m = new Mem();
        parseMemInfo(m);
        parseSwaps(m);
        parseBattery(m);
        parseTemp(m);
        return m;
    }

    private static void parseMemInfo(Mem m) {
        for (String line : SysFile.readLines("/proc/meminfo")) {
            if (line.startsWith("MemTotal:")) m.totalKb = valueAfterColon(line);
            else if (line.startsWith("MemAvailable:")) m.availKb = valueAfterColon(line);
        }
    }

    private static long valueAfterColon(String line) {
        int i = line.indexOf(':');
        if (i < 0) return 0;
        String[] p = SysFile.splitWs(line.substring(i + 1));
        return p.length > 0 ? SysFile.parseLong(p[0]) : 0;
    }

    /**
     * /proc/swaps 格式（关键：列之间是空格填充 + TAB 混合，必须按 \s+ 切分）：
     * Filename  Type  Size  Used  Priority
     */
    private static void parseSwaps(Mem m) {
        java.util.List<String> lines = SysFile.readLines("/proc/swaps");
        for (String line : lines) {
            if (!line.startsWith("/")) continue;   // 跳过表头
            String[] p = SysFile.splitWs(line);
            if (p.length < 4) continue;
            String dev = p[0];
            long size = SysFile.parseLong(p[2]);
            long used = SysFile.parseLong(p[3]);
            int prio = p.length >= 5 ? (int) SysFile.parseLong(p[4]) : 0;
            if (dev.contains("zram")) {
                m.zramSizeKb = size;
                m.zramUsedKb = used;
                m.zramActive = true;
            } else {
                m.diskSwapKb = size;
                m.diskUsedKb = used;
                m.diskPriority = prio;
                m.diskActive = true;
            }
        }
    }

    /** 电池：真实节点是 aprimary-bat（不是 battery） */
    private static void parseBattery(Mem m) {
        String[] bases = {
            "/sys/class/power_supply/aprimary-bat",
            "/sys/class/power_supply/battery"
        };
        for (String base : bases) {
            long cap = SysFile.readLong(base + "/capacity");
            if (cap > 0) {
                m.batteryPct = cap;
                String status = SysFile.readLine(base + "/status");
                m.charging = status.contains("Charging") || status.contains("Full");
                long t = SysFile.readLong(base + "/temp");
                if (t > 0) m.batteryTempC = t / 10;   // 单位 0.1℃
                break;
            }
        }
    }

    /**
     * 温度：thermal_zone 里 *_usr 后缀的是用户空间可读的（*_step 多为驱动内部）。
     * 优先选 cpu/gpuss/skin 相关，读不到就跳过，不浪费循环。
     */
    private static void parseTemp(Mem m) {
        String[] preferred = {
            "thermal_zone40",  // cpu-0-0-usr
            "thermal_zone44",  // cpuss-0-usr
            "msm-skin-therm-usr",
            "quiet-therm-usr",
        };
        long best = -999;
        for (String z : preferred) {
            long t = SysFile.readLong("/sys/class/thermal/" + z + "/temp");
            if (t > 0 && t < 200000) {
                // 取最高（最热）的那个
                if (t > best) best = t;
            }
        }
        if (best > 0) m.cpuTempC = best / 1000;
        // 兜底：如果是短名 zone，按名称找
        if (m.cpuTempC <= 0) {
            for (int i = 0; i < 128; i++) {
                String base = "/sys/class/thermal/thermal_zone" + i;
                String type = SysFile.readLine(base + "/type");
                if (type.isEmpty()) continue;
                if (type.contains("cpu-0-0-usr") || type.contains("cpuss-0-usr")) {
                    long t = SysFile.readLong(base + "/temp");
                    if (t > 0 && t < 200000) { m.cpuTempC = t / 1000; break; }
                }
            }
        }
    }

    public static String mb(long kb) { return (kb / 1024) + "MB"; }
    public static String gb(long kb) { return String.format("%.2fGB", kb / 1024.0 / 1024.0); }
}
