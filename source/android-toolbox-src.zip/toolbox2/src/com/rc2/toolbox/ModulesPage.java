package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** 模块页：Magisk 模块管理（单次 su 批量列表 + 禁用/启用/移除） */
public class ModulesPage {
    public static class Mod {
        public String id, name, version, description = "";
        public boolean disabled;
    }

    public static View build(Context c, MainActivity host) {
        LinearLayout page = UI.page(c);
        LinearLayout card = UI.card(c);
        card.addView(UI.sectionTitle(c, "Magisk 模块"));
        TextView loading = UI.dim(c, "读取中…");
        card.addView(loading);
        page.addView(card);
        host.runBg(() -> {
            List<Mod> mods = list();
            host.post(() -> {
                card.removeView(loading);
                if (mods.isEmpty()) {
                    card.addView(UI.dim(c, "没有已安装的模块"));
                    return;
                }
                for (Mod m : mods) card.addView(modRow(c, host, m));
            });
        });
        return UI.scroll(c, page);
    }

    private static List<Mod> list() {
        RootShell.Result r = RootShell.exec("for d in /data/adb/modules/*; do "
                + "[ -d \"$d\" ] || continue; echo __M__${d##*/}; "
                + "grep -E '^(name|version|description)=' \"$d/module.prop\" 2>/dev/null; "
                + "[ -f \"$d/disable\" ] && echo __DIS__; done; "
                + "echo __END__");
        List<Mod> mods = new ArrayList<>();
        Mod cur = null;
        for (String l : r.out.split("\n")) {
            String t = l.trim();
            if (t.startsWith("__M__")) {
                cur = new Mod();
                cur.id = t.substring(5);
                mods.add(cur);
            } else if (t.startsWith("name=") && cur != null) cur.name = t.substring(5);
            else if (t.startsWith("version=") && cur != null) cur.version = t.substring(8);
            else if (t.startsWith("description=") && cur != null) cur.description = t.substring(12);
            else if (t.equals("__DIS__") && cur != null) cur.disabled = true;
        }
        return mods;
    }

    private static View modRow(Context c, MainActivity host, final Mod m) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, UI.dp(6), 0, UI.dp(6));
        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView name = new TextView(c);
        name.setText((m.disabled ? "〔禁用〕" : "") + (m.name.isEmpty() ? m.id : m.name));
        name.setTextSize(14);
        name.setTextColor(m.disabled ? UI.TEXT_DIM : 0xFFFFFFFF);
        name.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        name.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(name);
        TextView ver = new TextView(c);
        ver.setText(m.version);
        ver.setTextSize(12);
        ver.setTextColor(UI.ACCENT);
        top.addView(ver);
        row.addView(top);
        if (!m.description.isEmpty()) row.addView(UI.dim(c, m.description));
        LinearLayout btns = UI.buttonRow(c,
                UI.button2(c, m.disabled ? "启用" : "禁用"), UI.button2(c, "移除"));
        row.addView(btns);
        btns.getChildAt(0).setOnClickListener(v -> host.runBg(() -> {
            String cmd = m.disabled
                    ? "rm -f /data/adb/modules/" + m.id + "/disable"
                    : "touch /data/adb/modules/" + m.id + "/disable";
            boolean ok = RootShell.exec(cmd).isSuccess();
            host.toast((m.disabled ? "启用" : "禁用") + " " + m.id + (ok ? " 完成（重启生效）" : " 失败"));
        }));
        btns.getChildAt(1).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = RootShell.exec("touch /data/adb/modules/" + m.id + "/remove").isSuccess();
            host.toast("移除 " + m.id + (ok ? " 已标记（重启清除）" : " 失败"));
        }));
        return row;
    }
}
