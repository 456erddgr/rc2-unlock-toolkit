package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 日志与诊断页：logcat/崩溃记录/内核日志/导出 */
public class LogPage {

    private static Context ctx;
    private static TextView logView;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);

        LinearLayout btnCard = UI.card(c);
        btnCard.addView(UI.sectionTitle(c, "日志来源"));
        LinearLayout r1 = UI.buttonRow(c, UI.button2(c, "应用日志"), UI.button2(c, "崩溃日志"));
        btnCard.addView(r1);
        UI.space(c, btnCard, 6);
        LinearLayout r2 = UI.buttonRow(c, UI.button2(c, "内核日志"), UI.button2(c, "工具箱日志"));
        btnCard.addView(r2);
        UI.space(c, btnCard, 6);
        LinearLayout r3 = UI.buttonRow(c,
                UI.button(c, "刷新", UI.ACCENT), UI.button2(c, "清空显示"));
        btnCard.addView(r3);
        page.addView(btnCard);

        LinearLayout showCard = UI.card(c);
        showCard.addView(UI.sectionTitle(c, "日志内容"));
        logView = new TextView(c);
        logView.setTextSize(10);
        logView.setTextColor(UI.TEXT);
        logView.setLineSpacing(0, 1.1f);
        logView.setText("选择上方来源…");
        showCard.addView(logView);
        page.addView(showCard);

        ((TextView) r1.getChildAt(0)).setOnClickListener(v ->
                load(host, "logcat -d -t 120 2>/dev/null"));
        ((TextView) r1.getChildAt(1)).setOnClickListener(v ->
                load(host, "logcat -d -b crash -t 80 2>/dev/null"));
        ((TextView) r2.getChildAt(0)).setOnClickListener(v ->
                load(host, "dmesg 2>/dev/null | tail -80"));
        ((TextView) r2.getChildAt(1)).setOnClickListener(v ->
                load(host, "cat /data/data/com.rc2.toolbox/files/toolbox.log 2>/dev/null | tail -80"));
        ((TextView) r3.getChildAt(0)).setOnClickListener(v -> load(host, "logcat -d -t 120 2>/dev/null"));
        ((TextView) r3.getChildAt(1)).setOnClickListener(v -> {
            if (logView != null) logView.setText("已清空");
        });

        return UI.scroll(c, page);
    }

    private static void load(MainActivity host, final String cmd) {
        if (logView != null) logView.setText("读取中…");
        host.runBg(() -> {
            RootShell.Result r = RootShell.exec(cmd, 25);
            String out = r.trim();
            if (out.isEmpty()) out = "（无日志或无权限）";
            if (out.length() > 20000) out = out.substring(out.length() - 20000);
            final String f = out;
            if (logView != null) logView.post(() -> logView.setText(f));
        });
    }
}
