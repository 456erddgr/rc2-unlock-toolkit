package com.rc2.toolbox;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 文件管理页：目录浏览/大小统计/清理 */
public class FilePage {

    private static Context ctx;
    private static LinearLayout listCard;
    private static String curPath = "/data/local/tmp";

    public static View build(Context c, MainActivity host) {
        ctx = c;
        curPath = "/data/local/tmp";
        LinearLayout page = UI.page(c);

        LinearLayout navCard = UI.card(c);
        navCard.addView(UI.sectionTitle(c, "路径"));
        LinearLayout r1 = UI.buttonRow(c,
                UI.button2(c, "/data/local/tmp"), UI.button2(c, "/sdcard"));
        navCard.addView(r1);
        UI.space(c, navCard, 6);
        LinearLayout r2 = UI.buttonRow(c,
                UI.button(c, "返回上级", UI.ACCENT), UI.button2(c, "清理本目录临时文件"));
        navCard.addView(r2);
        page.addView(navCard);

        LinearLayout statCard = UI.card(c);
        statCard.addView(UI.sectionTitle(c, "空间统计"));
        LinearLayout r3 = UI.buttonRow(c,
                UI.button2(c, "各分区占用"), UI.button2(c, "大文件 Top5"));
        statCard.addView(r3);
        page.addView(statCard);

        listCard = UI.card(c);
        listCard.addView(UI.sectionTitle(c, "目录内容"));
        page.addView(listCard);

        ((TextView) r1.getChildAt(0)).setOnClickListener(v -> load(host, "/data/local/tmp"));
        ((TextView) r1.getChildAt(1)).setOnClickListener(v -> load(host, "/sdcard"));
        ((TextView) r2.getChildAt(0)).setOnClickListener(v -> {
            String up = curPath;
            int i = up.lastIndexOf('/');
            if (i > 0) up = up.substring(0, i);
            load(host, up);
        });
        ((TextView) r2.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("find " + curPath + " -maxdepth 1 -name '*.png' -delete 2>/dev/null; "
                    + "find " + curPath + " -maxdepth 1 -name '*.log' -delete 2>/dev/null; echo done", 20);
            host.post(() -> { host.toast("已清理"); load(host, curPath); });
        }));
        ((TextView) r3.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            String o = RootShell.exec("df -h 2>/dev/null | grep -E 'Filesystem|/data|/system|/product'", 15).trim();
            host.post(() -> host.toast(o.length() > 300 ? o.substring(0, 300) : o));
        }));
        ((TextView) r3.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            String o = RootShell.exec("find /data/local/tmp /sdcard -maxdepth 2 -type f -size +5M 2>/dev/null | head -6", 25).trim();
            final String fs = o.isEmpty() ? "无大文件" : (o.length() > 300 ? o.substring(0, 300) : o);
            host.post(() -> host.toast(fs));
        }));

        load(host, curPath);
        return UI.scroll(c, page);
    }

    /** 人类可读大小 */
    private static String humanSize(long bytes) {
        if (bytes <= 0) return "0B";
        if (bytes < 1024) return bytes + "B";
        if (bytes < 1024 * 1024) return (bytes / 1024) + "KB";
        if (bytes < 1024L * 1024 * 1024) return (bytes / 1024 / 1024) + "MB";
        return String.format("%.2fGB", bytes / 1024.0 / 1024 / 1024);
    }

    private static void load(MainActivity host, final String path) {
        curPath = path;
        int keep = listCard.getChildCount() > 0 ? 1 : 0;
        if (listCard.getChildCount() > keep) listCard.removeViews(keep, listCard.getChildCount() - keep);
        TextView loading = UI.dim(ctx, "读取 " + path + " …");
        listCard.addView(loading);

        host.runBg(() -> {
            // 用 ls -la 取详细列表
            RootShell.Result r = RootShell.exec("ls -la " + path + " 2>/dev/null", 15);
            String out = r.trim();
            host.post(() -> {
                listCard.removeView(loading);
                if (out.isEmpty()) {
                    listCard.addView(UI.dim(ctx, "无法读取（权限或路径不存在）"));
                    return;
                }
                int count = 0;
                for (String line : out.split("\n")) {
                    String t = line.trim();
                    if (t.isEmpty() || t.startsWith("total")) continue;
                    if (count++ > 50) { listCard.addView(UI.dim(ctx, "…更多已省略")); break; }
                    String[] p = SysFile.splitWs(t);
                    if (p.length < 8) continue;
                    String perms = p[0];
                    String size = p[4];
                    String name = p[p.length - 1];
                    boolean isDir = perms.startsWith("d");
                    long sizeN = SysFile.parseLong(size);
                    LinearLayout row = UI.kvRow(ctx,
                            (isDir ? "📁 " : "📄 ") + name,
                            isDir ? "" : humanSize(sizeN),
                            isDir ? UI.ACCENT : (sizeN > 1000000 ? UI.WARN : UI.TEXT_DIM));
                    listCard.addView(row);
                }
            });
        });
    }
}
