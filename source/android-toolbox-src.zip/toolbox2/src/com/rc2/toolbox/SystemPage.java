package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 系统页：信息 + 重启 / zygote / 日志 + 主题切换 */
public class SystemPage {

    private static LinearLayout infoCard;
    private static Context ctx;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);

        infoCard = UI.card(c);
        infoCard.addView(UI.sectionTitle(c, "系统信息"));
        page.addView(infoCard);

        // 主题
        LinearLayout themeCard = UI.card(c);
        themeCard.addView(UI.sectionTitle(c, "外观主题"));
        TextView themeName = new TextView(c);
        themeName.setTextSize(13);
        themeName.setTextColor(UI.TEXT_DIM);
        themeName.setPadding(0, UI.dp(3), 0, UI.dp(5));
        themeName.setText("当前：" + themeLabel());
        themeCard.addView(themeName);

        LinearLayout trow1 = UI.buttonRow(c,
                UI.button2(c, "炫彩深色"), UI.button2(c, "黑白"));
        themeCard.addView(trow1);
        UI.space(c, themeCard, 6);
        LinearLayout trow2 = UI.buttonRow(c,
                UI.button2(c, "炫彩浅色"), UI.button2(c, "黑白浅色"));
        themeCard.addView(trow2);

        ((TextView) trow1.getChildAt(0)).setOnClickListener(v -> { UI.setTheme(UI.Theme.DARK_COLORFUL); host.rebuildUi(); });
        ((TextView) trow1.getChildAt(1)).setOnClickListener(v -> { UI.setTheme(UI.Theme.DARK_MONO); host.rebuildUi(); });
        ((TextView) trow2.getChildAt(0)).setOnClickListener(v -> { UI.setTheme(UI.Theme.LIGHT_COLORFUL); host.rebuildUi(); });
        ((TextView) trow2.getChildAt(1)).setOnClickListener(v -> { UI.setTheme(UI.Theme.LIGHT_MONO); host.rebuildUi(); });
        page.addView(themeCard);

        // 控制
        LinearLayout actCard = UI.card(c);
        actCard.addView(UI.sectionTitle(c, "系统控制"));
        LinearLayout row1 = UI.buttonRow(c, UI.button2(c, "重启设备"), UI.button2(c, "重启 zygote"));
        actCard.addView(row1);
        UI.space(c, actCard, 6);
        LinearLayout row2 = UI.buttonRow(c, UI.button2(c, "查看日志"), UI.button2(c, "刷新信息"));
        actCard.addView(row2);

        ((TextView) row1.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("reboot", 10);
            host.post(() -> host.toast("已发送重启指令"));
        }));
        ((TextView) row1.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = RootShell.exec(
                    "stop zygote_secondary 2>/dev/null; sleep 1; start zygote_secondary 2>/dev/null; echo done")
                    .isSuccess();
            host.post(() -> host.toast(ok ? "zygote 已重启" : "重启失败"));
        }));
        ((TextView) row2.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.Result r = RootShell.exec("logcat -d -t 60 2>/dev/null", 15);
            String out = r.trim();
            if (out.length() > 400) out = out.substring(out.length() - 400);
            final String f = out;
            host.post(() -> host.toast(f));
        }));
        ((TextView) row2.getChildAt(1)).setOnClickListener(v -> {
            refresh();
            host.toast("已刷新");
        });
        page.addView(actCard);

        refresh();
        return UI.scroll(c, page);
    }

    private static String themeLabel() {
        switch (UI.getTheme()) {
            case DARK_COLORFUL: return "炫彩深色";
            case DARK_MONO: return "黑白深色";
            case LIGHT_COLORFUL: return "炫彩浅色";
            default: return "黑白浅色";
        }
    }

    private static void refresh() {
        if (infoCard == null || ctx == null) return;
        int keep = infoCard.getChildCount() > 0 ? 1 : 0;
        if (infoCard.getChildCount() > keep) infoCard.removeViews(keep, infoCard.getChildCount() - keep);

        String ver = RootShell.exec("getprop ro.build.version.release", 8).trim();
        String policy = RootShell.exec("getprop persist.dji.zygote_policy", 8).trim();
        String zyg = RootShell.exec("getprop init.svc.zygote", 8).trim();
        String zyg2 = RootShell.exec("getprop init.svc.zygote_secondary", 8).trim();
        String up = RootShell.exec("uptime", 8).trim();
        MemInfo.Mem m = MemInfo.get();

        infoCard.addView(UI.kvRow(ctx, "Android", ver.isEmpty() ? "-" : ver, UI.ACCENT));
        infoCard.addView(UI.kvRow(ctx, "zygote 策略", policy.isEmpty() ? "-" : policy, UI.TEXT_DIM));
        infoCard.addView(UI.kvRow(ctx, "zygote 64位",
                zyg.isEmpty() || zyg.equals("stopped") ? "已停止" : "运行中",
                zyg.equals("running") ? UI.OK : UI.TEXT_DIM));
        infoCard.addView(UI.kvRow(ctx, "zygote 32位",
                zyg2.isEmpty() || zyg2.equals("stopped") ? "已停止" : "运行中",
                zyg2.equals("running") ? UI.OK : UI.TEXT_DIM));
        infoCard.addView(UI.kvRow(ctx, "运行时间",
                up.length() > 40 ? up.substring(0, 40) : up, UI.TEXT_DIM));
        infoCard.addView(UI.kvRow(ctx, "CPU 温度",
                m.cpuTempC > -100 ? m.cpuTempC + "℃" : "-", UI.tempColor(m.cpuTempC)));
        infoCard.addView(UI.kvRow(ctx, "电池", CpuGpu.battery(),
                m.batteryPct > 20 ? UI.OK : UI.WARN));
        infoCard.addView(UI.kvRow(ctx, "权限模式", RootShell.modeName(),
                RootShell.hasRoot() ? UI.OK : UI.WARN));
    }
}
