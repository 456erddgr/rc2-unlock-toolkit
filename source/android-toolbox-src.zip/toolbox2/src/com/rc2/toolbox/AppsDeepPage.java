package com.rc2.toolbox;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** 应用深度管理：批量操作/备份/冻结/权限查看 */
public class AppsDeepPage {

    private static Context ctx;
    private static MainActivity hostRef;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        hostRef = host;
        LinearLayout page = UI.page(c);

        LinearLayout batchCard = UI.card(c);
        batchCard.addView(UI.sectionTitle(c, "批量操作"));
        LinearLayout b1 = UI.buttonRow(c,
                UI.button2(c, "冻结全部3方"), UI.button2(c, "解冻全部"));
        batchCard.addView(b1);
        UI.space(c, batchCard, 6);
        LinearLayout b2 = UI.buttonRow(c,
                UI.button2(c, "清理后台"), UI.button2(c, "应用统计"));
        batchCard.addView(b2);
        page.addView(batchCard);

        LinearLayout listCard = UI.card(c);
        listCard.addView(UI.sectionTitle(c, "应用列表（点按切换状态）"));
        TextView load = UI.dim(c, "读取中…");
        listCard.addView(load);
        page.addView(listCard);

        ((TextView) b1.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            int n = 0;
            for (ApplicationInfo a : getApps(c)) {
                if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                if (a.packageName.equals("com.rc2.toolbox")) continue;
                RootShell.exec("pm disable-user --user 0 " + a.packageName, 12);
                n++;
                if (n > 40) break;
            }
            final int fn = n;
            host.post(() -> host.toast("已冻结 " + fn + " 个应用"));
        }));

        ((TextView) b1.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.Result r = RootShell.exec("pm list packages -d 2>/dev/null", 15);
            int n = 0;
            for (String l : r.trim().split("\n")) {
                String t = l.trim();
                if (t.startsWith("package:")) {
                    RootShell.exec("pm enable " + t.substring(8).trim(), 12);
                    n++;
                }
            }
            final int fn = n;
            host.post(() -> host.toast("已解冻 " + fn + " 个应用"));
        }));

        ((TextView) b2.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("am kill-all 2>/dev/null", 20);
            host.post(() -> host.toast("后台已清理"));
        }));

        ((TextView) b2.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            List<ApplicationInfo> apps = getApps(c);
            int sys = 0, third = 0;
            for (ApplicationInfo a : apps) {
                if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0) sys++; else third++;
            }
            final int fs = sys, ft = third;
            host.post(() -> host.toast("系统 " + fs + " 个 / 三方 " + ft + " 个"));
        }));

        host.runBg(() -> {
            List<ApplicationInfo> apps = getApps(c);
            RootShell.Result d = RootShell.exec("pm list packages -d 2>/dev/null", 15);
            java.util.Set<String> disabled = new java.util.HashSet<>();
            for (String l : d.trim().split("\n")) {
                String t = l.trim();
                if (t.startsWith("package:")) disabled.add(t.substring(8).trim());
            }
            host.post(() -> {
                listCard.removeView(load);
                int count = 0;
                for (ApplicationInfo a : apps) {
                    if ((a.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;
                    if (count++ > 40) break;
                    listCard.addView(appRow(c, host, a, disabled.contains(a.packageName)));
                }
                listCard.addView(UI.dim(c, "共 " + count + " 个第三方应用"));
            });
        });

        return UI.scroll(c, page);
    }

    private static List<ApplicationInfo> getApps(Context c) {
        List<ApplicationInfo> out = new ArrayList<>();
        try {
            out.addAll(c.getPackageManager().getInstalledApplications(PackageManager.MATCH_ALL));
        } catch (Throwable ignored) {}
        return out;
    }

    private static View appRow(Context c, MainActivity host, final ApplicationInfo a, boolean disabled) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, UI.dp(4), 0, UI.dp(4));

        TextView name = new TextView(c);
        String label;
        try { label = a.loadLabel(c.getPackageManager()).toString(); }
        catch (Throwable t) { label = a.packageName; }
        name.setText((disabled ? "〔冻〕" : "") + label);
        name.setTextSize(12);
        name.setTextColor(disabled ? UI.TEXT_DIM : UI.TEXT);
        name.setMaxLines(1);
        name.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(name);

        TextView btn = UI.button2(c, disabled ? "解冻" : "冻结");
        btn.setTextSize(11);
        btn.setPadding(UI.dp(8), UI.dp(4), UI.dp(8), UI.dp(4));
        btn.setLayoutParams(new LinearLayout.LayoutParams(UI.dp(52), ViewGroup.LayoutParams.WRAP_CONTENT));
        btn.setOnClickListener(v -> host.runBg(() -> {
            String cmd = disabled ? "pm enable " + a.packageName
                                 : "pm disable-user --user 0 " + a.packageName;
            boolean ok = RootShell.exec(cmd, 12).isSuccess();
            host.post(() -> host.toast((disabled ? "解冻 " : "冻结 ") + (ok ? "完成" : "失败")));
        }));
        row.addView(btn);

        TextView stop = UI.button2(c, "停");
        stop.setTextSize(11);
        stop.setPadding(UI.dp(8), UI.dp(4), UI.dp(8), UI.dp(4));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(UI.dp(36), ViewGroup.LayoutParams.WRAP_CONTENT);
        slp.leftMargin = UI.dp(4);
        stop.setLayoutParams(slp);
        stop.setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("am force-stop " + a.packageName, 12);
            host.post(() -> host.toast("已停止"));
        }));
        row.addView(stop);

        return row;
    }
}
