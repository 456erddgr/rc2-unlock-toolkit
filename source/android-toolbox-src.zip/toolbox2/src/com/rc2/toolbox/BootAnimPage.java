package com.rc2.toolbox;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 开机动画页 v3：设备端选视频/照片 → 生成 bootanimation.zip → 装 Magisk 模块
 *
 * ★ v3 修复（2026-10-31，用户实测反馈「4 秒视频只抽 18 帧 → 开机动画黑屏」）：
 *   根因 1：framesFromVideo 里 Math.min(20, ...) 把上限焊死在 20 帧，
 *           4 秒视频按 durMs/250 算出 16~20 帧，远达不到流畅所需。
 *   根因 2：取帧用 OPTION_CLOSEST_SYNC 只抓关键帧 —— 关键帧稀疏时
 *           同一关键帧被重复取多次 / 大量时间点取到 null，实际帧数更少。
 *   根因 3：desc.txt 写死 "24" 帧率，且不区分用户想要的播放速度。
 *   根因 4：**所有帧 Bitmap 同时留在内存里**（1920×1080 ARGB ≈ 8MB/帧，
 *           45 帧 ≈ 380MB），1.7GB 设备直接 OOM / 被 LMK 杀掉，
 *           生成出来的 zip 是残的 → 开机只显示一张或黑屏。
 *
 *   修复：
 *   - 帧数与播放速度**做成滑块由用户决定**（帧数 12~120，帧率 10~30fps）
 *   - 取帧改 OPTION_CLOSEST（精度优先），并按时间均匀采样
 *   - **边取帧边写 zip，取完立刻 recycle**（峰值内存 = 1 帧，不再爆内存）
 *   - 帧总数受「内存预算」保护：按实时 MemAvailable 自动降级，避免 OOM
 *   - desc.txt 用用户选的 fps；并明确写 c 1 0 part0 循环
 */
public class BootAnimPage {
    public static final int REQ_VIDEO = 101, REQ_PHOTOS = 102;
    public static final String MODULE = "/data/adb/modules/rc2_bootanim";
    public static final int W = 1920, H = 1080; // 兜底（真实值走 realScreenSize）
    private static final String TAG = "RC2Toolbox";

    /** 帧数档位：12 ~ 120 */
    private static final int FRAMES_MIN = 12, FRAMES_MAX = 120, FRAMES_DEF = 48;
    /** 播放帧率档位：10 ~ 30 fps */
    private static final int FPS_MIN = 10, FPS_MAX = 30, FPS_DEF = 24;

    /** ★ 模式：0=同步原时长（动画多长 = 视频多长），1=手动设置 */
    private static final int MODE_SYNC = 0, MODE_MANUAL = 1;
    private static int mode = MODE_SYNC;

    /** 同步模式的帧数硬上限（防超长视频撑爆存储；1920×1080 JPEG≈150KB/帧） */
    private static final int MAX_SYNC_FRAMES = 360;

    private static TextView statusText, progressText;
    private static SeekBar frameBar, fpsBar;
    private static TextView frameVal, fpsVal;
    private static TextView frameHint, modeHint;
    private static LinearLayout manualBox, syncBox;
    private static TextView syncInfo;

    /** 用户上次的选择（页面重建后保持） */
    private static int wantFrames = FRAMES_DEF;
    private static int wantFps = FPS_DEF;

    public static View build(Context c, MainActivity host) {
        LinearLayout page = UI.page(c);

        // ===== 状态 =====
        LinearLayout stCard = UI.card(c);
        stCard.addView(UI.sectionTitle(c, "状态"));
        statusText = UI.dim(c, "读取中…");
        stCard.addView(statusText);
        page.addView(stCard);

        // ===== 素材 =====
        LinearLayout pickCard = UI.card(c);
        pickCard.addView(UI.sectionTitle(c, "素材（设备端选择，无需电脑）"));
        LinearLayout b1 = UI.buttonRow(c,
                UI.button(c, "选视频", UI.ACCENT), UI.button2(c, "选照片(多张)"));
        pickCard.addView(b1);
        int[] scr = realScreenSize(c);
        TextView hint = UI.dim(c, "自动按设备真实分辨率 " + scr[0] + "×" + scr[1]
                + " 生成。照片按文件名排序播放。");
        hint.setPadding(0, UI.dp(6), 0, 0);
        pickCard.addView(hint);
        page.addView(pickCard);

        // ===== ★ 播放参数：同步原时长 / 手动设置（两种都保留，用户自选）=====
        LinearLayout paramCard = UI.card(c);
        paramCard.addView(UI.sectionTitle(c, "播放参数"));

        // 模式切换（分段控件）
        LinearLayout modeSeg = UI.segmented(c,
                new String[]{"同步原时长", "手动设置"}, mode,
                (idx, label) -> {
                    mode = idx;
                    boolean sync = (idx == MODE_SYNC);
                    if (syncBox != null) syncBox.setVisibility(sync ? View.VISIBLE : View.GONE);
                    if (manualBox != null) manualBox.setVisibility(sync ? View.GONE : View.VISIBLE);
                });
        paramCard.addView(modeSeg);

        // ---- 同步模式说明 ----
        syncBox = new LinearLayout(c);
        syncBox.setOrientation(LinearLayout.VERTICAL);
        syncBox.setPadding(0, UI.dp(7), 0, 0);
        syncInfo = UI.text(c, "视频多长，开机动画就播多长（4 秒视频 = 4 秒动画）", UI.OK, 12.5f);
        syncInfo.setLineSpacing(0, 1.25f);
        syncBox.addView(syncInfo);
        TextView syncTip = UI.dim(c, "• 帧数由「时长 × 帧率」自动算出，取帧均匀铺满整段\n"
                + "• 帧率仍可调（下面滑块），帧率越高越流畅、文件越大\n"
                + "• 适合想让动画和原视频节奏一致的场景");
        syncTip.setLineSpacing(0, 1.2f);
        syncTip.setPadding(0, UI.dp(4), 0, 0);
        syncBox.addView(syncTip);
        paramCard.addView(syncBox);

        // ---- 手动模式（帧数滑块）----
        manualBox = new LinearLayout(c);
        manualBox.setOrientation(LinearLayout.VERTICAL);

        LinearLayout fRow = new LinearLayout(c);
        fRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView fLabel = new TextView(c);
        fLabel.setText("抽帧数量");
        fLabel.setTextSize(13);
        fLabel.setTextColor(UI.TEXT);
        frameVal = new TextView(c);
        frameVal.setTextSize(15);
        frameVal.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        frameVal.setTextColor(UI.ACCENT);
        frameVal.setGravity(android.view.Gravity.END);
        frameVal.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        fRow.addView(fLabel);
        fRow.addView(frameVal);
        manualBox.addView(fRow);

        frameBar = new SeekBar(c);
        frameBar.setMax(FRAMES_MAX - FRAMES_MIN);
        frameBar.setProgress(wantFrames - FRAMES_MIN);
        frameVal.setText(wantFrames + " 帧");
        frameBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                wantFrames = v + FRAMES_MIN;
                frameVal.setText(wantFrames + " 帧");
                if (frameHint != null) frameHint.setText(framesHint(wantFrames));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        manualBox.addView(frameBar);

        frameHint = UI.dim(c, framesHint(wantFrames));
        frameHint.setLineSpacing(0, 1.15f);
        manualBox.addView(frameHint);
        paramCard.addView(manualBox);

        // 初始可见性
        boolean syncInit = (mode == MODE_SYNC);
        syncBox.setVisibility(syncInit ? View.VISIBLE : View.GONE);
        manualBox.setVisibility(syncInit ? View.GONE : View.VISIBLE);

        UI.space(c, paramCard, 8);

        // 帧率
        LinearLayout pRow = new LinearLayout(c);
        pRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView pLabel = new TextView(c);
        pLabel.setText("播放速度");
        pLabel.setTextSize(13);
        pLabel.setTextColor(UI.TEXT);
        fpsVal = new TextView(c);
        fpsVal.setTextSize(15);
        fpsVal.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        fpsVal.setTextColor(UI.ACCENT2);
        fpsVal.setGravity(android.view.Gravity.END);
        fpsVal.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        pRow.addView(pLabel);
        pRow.addView(fpsVal);
        paramCard.addView(pRow);

        fpsBar = new SeekBar(c);
        fpsBar.setMax(FPS_MAX - FPS_MIN);
        fpsBar.setProgress(wantFps - FPS_MIN);
        fpsVal.setText(wantFps + " fps");
        fpsBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                wantFps = v + FPS_MIN;
                fpsVal.setText(wantFps + " fps");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        paramCard.addView(fpsBar);

        LinearLayout presetRow = UI.buttonRow(c,
                UI.button2(c, "流畅 60帧/24fps"), UI.button2(c, "极流畅 90帧/30fps"));
        paramCard.addView(presetRow);
        ((TextView) presetRow.getChildAt(0)).setOnClickListener(v -> {
            wantFrames = 60; wantFps = 24;
            frameBar.setProgress(wantFrames - FRAMES_MIN);
            fpsBar.setProgress(wantFps - FPS_MIN);
            frameVal.setText(wantFrames + " 帧");
            fpsVal.setText(wantFps + " fps");
            frameHint.setText(framesHint(wantFrames));
        });
        ((TextView) presetRow.getChildAt(1)).setOnClickListener(v -> {
            wantFrames = 90; wantFps = 30;
            frameBar.setProgress(wantFrames - FRAMES_MIN);
            fpsBar.setProgress(wantFps - FPS_MIN);
            frameVal.setText(wantFrames + " 帧");
            fpsVal.setText(wantFps + " fps");
            frameHint.setText(framesHint(wantFrames));
        });

        paramCard.addView(UI.dim(c, "• 帧数越多越流畅，但文件更大、开机加载更久\n"
                + "• 播放速度 = 每秒播几帧；24fps 接近视频原速\n"
                + "• 内存紧张时程序会自动降到安全帧数（会提示）"));
        page.addView(paramCard);

        // ===== 生成与安装 =====
        LinearLayout genCard = UI.card(c);
        genCard.addView(UI.sectionTitle(c, "生成与安装"));
        progressText = UI.dim(c, "未开始");
        genCard.addView(progressText);
        LinearLayout b2 = UI.buttonRow(c, UI.button(c, "重新生成并安装", UI.OK), UI.button2(c, "停用动画"));
        genCard.addView(b2);
        UI.space(c, genCard, 6);
        LinearLayout b3 = UI.buttonRow(c, UI.button(c, "恢复原装动画", UI.WARN));
        genCard.addView(b3);
        page.addView(genCard);

        LinearLayout tipCard = UI.card(c);
        tipCard.addView(UI.sectionTitle(c, "说明"));
        TextView tip = UI.dim(c, "• 安装后重启生效，动画在开机时播放\n"
                + "• 恢复原装 = 删除模块，回到出厂动画\n"
                + "• 帧尺寸必须等于设备分辨率（已自动处理）\n"
                + "• zip 必须 STORED 不压缩（已自动处理）");
        tip.setLineSpacing(0, 1.2f);
        tipCard.addView(tip);
        page.addView(tipCard);

        b1.getChildAt(0).setOnClickListener(v ->
                host.openDoc("video/*", false, REQ_VIDEO));
        b1.getChildAt(1).setOnClickListener(v ->
                host.openDoc("image/*", true, REQ_PHOTOS));
        // 「重新生成并安装」：用上次选的素材重新生成
        b2.getChildAt(0).setOnClickListener(v -> host.runBg(() -> {
            host.post(() -> host.toast("请先点「选视频」或「选照片」选择素材"));
        }));
        b2.getChildAt(1).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = RootShell.exec("touch " + MODULE + "/disable").isSuccess();
            host.post(() -> {
                host.toast("停用动画 -> " + (ok ? "完成（重启生效）" : "失败"));
                refreshStatus(c);
            });
        }));
        b3.getChildAt(0).setOnClickListener(v -> host.runBg(() -> {
            String cmd = "rm -rf " + MODULE + "; "
                    + "rm -f /data/local/tmp/rc2_bootanim_bak 2>/dev/null; "
                    + "test -d " + MODULE + " && echo STILL_THERE || echo REMOVED";
            RootShell.Result r = RootShell.exec(cmd, 40);
            boolean ok = r.trim().contains("REMOVED");
            host.post(() -> {
                host.toast(ok ? "已恢复原装动画（重启生效）" : "恢复失败");
                refreshStatus(c);
            });
        }));
        refreshStatus(c);
        return UI.scroll(c, page);
    }

    private static String framesHint(int f) {
        if (f <= 24) return "省内存 · 短动画够用，文件小";
        if (f <= 48) return "平衡（推荐）· 4 秒素材约 6fps 观感 / 配 24fps 约 2 秒";
        if (f <= 72) return "流畅 · 画面顺滑，文件约 3-5MB";
        return "极流畅 · 最顺滑，但开机加载更久（内存紧张会自动降级）";
    }

    private static void refreshStatus(Context c) {
        if (statusText == null) return;
        RootShell.Result r = RootShell.exec(
                "test -f " + MODULE + "/system/product/media/bootanimation.zip"
                        + " && stat -c %s " + MODULE + "/system/product/media/bootanimation.zip"
                        + " || echo MISSING");
        String s = r.out.trim();
        if (s.equals("MISSING") || s.isEmpty()) {
            statusText.setText("开机动画模块：未安装（默认开机画面）");
        } else {
            long sz = 0;
            try { sz = Long.parseLong(s.trim()); } catch (Exception ignored) {}
            String d = RootShell.exec("test -f " + MODULE + "/disable && echo D || echo E").trim();
            statusText.setText("已安装，bootanimation.zip " + (sz / 1024) + "KB"
                    + (d.contains("D") ? "（当前已停用）" : "，重启后生效"));
        }
    }

    /** 处理选择结果（MainActivity.onActivityResult 转发） */
    public static void processResult(Context c, MainActivity host, int req, int res, Intent data) {
        if (res != android.app.Activity.RESULT_OK || data == null) {
            host.toast("未选择素材");
            return;
        }
        final List<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++)
                uris.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) uris.add(data.getData());
        if (uris.isEmpty()) { host.toast("未选择素材"); return; }

        final int fps = Math.max(FPS_MIN, Math.min(FPS_MAX, wantFps));
        final boolean sync = (mode == MODE_SYNC);
        final int manualFrames = Math.max(FRAMES_MIN, Math.min(FRAMES_MAX, wantFrames));

        host.runBg(() -> {
            try {
                File zip;
                if (req == REQ_VIDEO) {
                    if (sync) {
                        progress(c, "同步原时长模式：读取视频时长…");
                        zip = generateFromVideoSync(c, uris.get(0), fps, host);
                    } else {
                        progress(c, "手动模式：" + manualFrames + " 帧 / " + fps + "fps …");
                        zip = generateFromVideo(c, uris.get(0), manualFrames, fps, host);
                    }
                } else {
                    // 照片没有「原时长」，同步模式按当前帧率把所选照片铺平均播放
                    if (sync) {
                        progress(c, "照片同步模式：" + fps + "fps …");
                        zip = generateFromImagesSync(c, uris, fps, host);
                    } else {
                        progress(c, "照片手动模式：" + manualFrames + " 帧 / " + fps + "fps …");
                        zip = generateFromImages(c, uris, manualFrames, fps, host);
                    }
                }
                if (zip == null) {
                    host.toast("生成失败");
                    return;
                }
                progress(c, "打包完成 " + (zip.length() / 1024) + "KB，安装模块…");
                boolean ok = installModule(zip);
                host.toast("开机动画安装 -> " + (ok ? "成功（重启后生效）" : "失败"));
                progress(c, ok ? "完成：重启后显示新开机动画" : "安装失败，查看日志");
                refreshStatus(c);
            } catch (Throwable t) {
                android.util.Log.e(TAG, "bootanim gen", t);
                host.toast("生成失败: " + t.getMessage());
            }
        });
    }

    /**
     * ★ 同步原时长模式：动画时长 = 视频时长。
     *
     * 例：4.48 秒视频 @24fps → ⌈4.48 × 24⌉ = 108 帧 → 播放 108/24 = 4.5 秒，
     *     与原视频一致（旧版固定 20 帧 → 只播 0.83 秒，看起来像没播）。
     *
     * 帧数上限保护：最多 MAX_SYNC_FRAMES 帧（避免 10 分钟视频撑爆存储）。
     * 仍然边取帧边写 zip，内存峰值 1 帧。
     */
    private static File generateFromVideoSync(Context c, Uri uri, int fps,
                                               MainActivity host) throws Exception {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(c, uri);
            String durS = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long durMs = 4000;
            try { durMs = Long.parseLong(durS == null ? "4000" : durS); } catch (Exception ignored) {}
            if (durMs < 200) durMs = 200;

            double sec = durMs / 1000.0;
            int need = (int) Math.ceil(sec * fps);
            int frames = Math.max(2, Math.min(MAX_SYNC_FRAMES, need));

            // 若被上限截断，用更低的实际 fps 保证时长仍匹配
            int realFps = fps;
            if (need > MAX_SYNC_FRAMES) {
                realFps = Math.max(1, (int) Math.round(MAX_SYNC_FRAMES / sec));
                android.util.Log.w(TAG, "视频过长，fps 从 " + fps + " 降到 " + realFps
                        + " 以保持时长一致");
            }

            int[] scr = realScreenSize(c);
            int rw = scr[0], rh = scr[1];
            final String msg = String.format("视频 %.2f 秒 → %d 帧 / %d fps = 播放 %.2f 秒",
                    sec, frames, realFps, (double) frames / realFps);
            android.util.Log.i(TAG, "同步模式 " + msg);
            host.post(() -> host.toast(msg));

            File zip = new File(c.getFilesDir(), "bootanimation.zip");
            ZipWriter zw = new ZipWriter(zip, rw, rh, realFps);
            try {
                zw.open();
                for (int i = 0; i < frames; i++) {
                    // ★ 采样点：把 frames 帧均匀铺在 [0, durMs] 上，
                    //   用 (i + 0.5) 居中，避免首帧与末帧时间点重合造成重复
                    long us;
                    if (frames <= 1) {
                        us = 0;
                    } else {
                        double frac = (i + 0.5) / frames;      // 0..1 居中分布
                        us = (long) (frac * durMs * 1000.0);
                    }
                    if (us < 0) us = 0;
                    // ★ 尾部保护：实测 MediaMetadataRetriever 在接近时长末端取帧时
                    //   会回退成开头画面（该视频只有 1 个关键帧，seek 不可靠），
                    //   导致末帧与首帧相同。最后一个采样点限制在 96% 处规避。
                    long maxUs = (i >= frames - 1)
                            ? (long) (durMs * 1000L * 0.96)
                            : Math.max(0, durMs * 1000L - 1);
                    if (us > maxUs) us = maxUs;
                    Bitmap b = grabFrame(mmr, us, rw, rh);
                    if (b == null) continue;
                    zw.addFrame(b);
                    b.recycle();
                    final int done = i + 1;
                    if (done % 8 == 0 || done == frames) {
                        progress(c, "取帧 " + done + " / " + frames + " …");
                    }
                }
            } finally {
                zw.close();
            }
            return zip;
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
    }

    /** 照片同步模式：按 fps 播放所选照片（每张 1 帧，循环次数由 bootanimation 控制） */
    private static File generateFromImagesSync(Context c, List<Uri> uris, int fps,
                                                MainActivity host) throws Exception {
        int[] scr = realScreenSize(c);
        int rw = scr[0], rh = scr[1];
        int limit = Math.min(uris.size(), MAX_SYNC_FRAMES);

        List<String> names = new ArrayList<>();
        for (Uri u : uris) {
            String n = queryName(c, u);
            names.add(n == null ? u.toString() : n);
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < uris.size(); i++) order.add(i);
        order.sort((a, b) -> names.get(a).compareTo(names.get(b)));

        File zip = new File(c.getFilesDir(), "bootanimation.zip");
        ZipWriter zw = new ZipWriter(zip, rw, rh, fps);
        try {
            zw.open();
            int done = 0;
            for (int idx : order) {
                if (done >= limit) break;
                InputStream in = null;
                Bitmap b = null;
                try {
                    in = c.getContentResolver().openInputStream(uris.get(idx));
                    b = BitmapFactory.decodeStream(in);
                } finally {
                    if (in != null) try { in.close(); } catch (Exception ignored) {}
                }
                if (b == null) continue;
                zw.addFrame(scaleCropTo(b, rw, rh));
                b.recycle();
                done++;
                final int d = done;
                if (d % 4 == 0 || d == limit) progress(c, "处理照片 " + d + " / " + limit + " …");
            }
            if (done == 0) return null;
        } finally {
            zw.close();
        }
        return zip;
    }

    /**
     * ★ 边取帧边写 zip：内存峰值 = 1 帧，彻底解决 OOM 导致的黑屏。
     * 帧数由用户指定；若 MemAvailable 不足则自动降级（并告知）。
     */
    private static File generateFromVideo(Context c, Uri uri, int wantFrames, int fps,
                                          MainActivity host) throws Exception {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(c, uri);
            String durS = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            long durMs = 3000;
            try { durMs = Long.parseLong(durS == null ? "3000" : durS); } catch (Exception ignored) {}
            if (durMs < 200) durMs = 200;

            int[] scr = realScreenSize(c);
            int rw = scr[0], rh = scr[1];

            // 内存预算保护：每帧估算 rw*rh*4 字节，留 120MB 安全余量
            int safe = safeFrameCount(rw, rh);
            int frames = Math.min(wantFrames, safe);
            if (frames < wantFrames) {
                final String msg = "内存紧张，帧数自动从 " + wantFrames + " 降到 " + frames;
                android.util.Log.w(TAG, msg);
                host.post(() -> host.toast(msg));
            }
            frames = Math.max(6, frames);

            android.util.Log.i(TAG, "bootanim video dur=" + durMs + "ms frames=" + frames
                    + " fps=" + fps + " res=" + rw + "x" + rh);

            File zip = new File(c.getFilesDir(), "bootanimation.zip");
            ZipWriter zw = new ZipWriter(zip, rw, rh, fps);
            try {
                zw.open();
                for (int i = 0; i < frames; i++) {
                    // ★ 居中均匀采样（避免首末帧时间点重合 → 重复帧）
                    long us;
                    if (frames <= 1) {
                        us = 0;
                    } else {
                        double frac = (i + 0.5) / frames;
                        us = (long) (frac * durMs * 1000.0);
                    }
                    if (us < 0) us = 0;
                    // ★ 尾部保护：实测 MediaMetadataRetriever 在接近时长末端取帧时
                    //   会回退成开头画面（该视频只有 1 个关键帧，seek 不可靠），
                    //   导致末帧与首帧相同。最后一个采样点限制在 96% 处规避。
                    long maxUs = (i >= frames - 1)
                            ? (long) (durMs * 1000L * 0.96)
                            : Math.max(0, durMs * 1000L - 1);
                    if (us > maxUs) us = maxUs;
                    Bitmap b = grabFrame(mmr, us, rw, rh);
                    if (b == null) {
                        android.util.Log.w(TAG, "取帧失败 t=" + us + "us，跳过");
                        continue;
                    }
                    zw.addFrame(b);
                    b.recycle();
                    final int done = i + 1;
                    if (done % 6 == 0 || done == frames) {
                        progress(c, "取帧 " + done + " / " + frames + " …");
                    }
                }
            } finally {
                zw.close();
            }
            return zip;
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
    }

    /** 照片：按名称排序，同样边缩放边写 zip */
    private static File generateFromImages(Context c, List<Uri> uris, int wantFrames, int fps,
                                           MainActivity host) throws Exception {
        int[] scr = realScreenSize(c);
        int rw = scr[0], rh = scr[1];

        List<String> names = new ArrayList<>();
        for (Uri u : uris) {
            String n = queryName(c, u);
            names.add(n == null ? u.toString() : n);
        }
        List<Integer> order = new ArrayList<>();
        for (int i = 0; i < uris.size(); i++) order.add(i);
        order.sort((a, b) -> names.get(a).compareTo(names.get(b)));

        int safe = safeFrameCount(rw, rh);
        int limit = Math.min(Math.min(wantFrames, uris.size()), safe);
        if (limit < Math.min(wantFrames, uris.size())) {
            final String msg = "内存紧张，改用 " + limit + " 张";
            host.post(() -> host.toast(msg));
        }
        android.util.Log.i(TAG, "bootanim images n=" + uris.size() + " use=" + limit
                + " fps=" + fps + " res=" + rw + "x" + rh);

        File zip = new File(c.getFilesDir(), "bootanimation.zip");
        ZipWriter zw = new ZipWriter(zip, rw, rh, fps);
        try {
            zw.open();
            int done = 0;
            for (int idx : order) {
                if (done >= limit) break;
                InputStream in = null;
                Bitmap b = null;
                try {
                    in = c.getContentResolver().openInputStream(uris.get(idx));
                    b = BitmapFactory.decodeStream(in);
                } finally {
                    if (in != null) try { in.close(); } catch (Exception ignored) {}
                }
                if (b == null) continue;
                zw.addFrame(scaleCropTo(b, rw, rh));
                b.recycle();
                done++;
                final int d = done;
                if (d % 4 == 0 || d == limit) progress(c, "处理照片 " + d + " / " + limit + " …");
            }
            if (done == 0) return null;
        } finally {
            zw.close();
        }
        return zip;
    }

    /**
     * ★ 精确取帧（v2.21 修复「重复帧」问题）。
     *
     * 旧实现直接 getFrameAtTime + OPTION_CLOSEST，在关键帧稀疏的视频上会退化：
     * 实测 4.48 秒视频抽 109 帧里有 15 帧重复（开头连续 14 帧一样）→ 动画卡顿。
     *
     * 新实现：
     *   1) 优先 getScaledFrameAtTime(OPTION_CLOSEST) —— 解码分辨率更低，更省内存，
     *      且时间定位比 getFrameAtTime 精确（不依赖完整解码帧）。
     *   2) 失败再退回 getFrameAtTime(OPTION_CLOSEST) 原尺寸解码。
     *   3) 最后兜底 OPTION_CLOSEST_SYNC。
     *   4) 统一 scaleCropTo 到目标尺寸，保证每帧尺寸一致。
     */
    private static Bitmap grabFrame(MediaMetadataRetriever mmr, long us, int rw, int rh) {
        Bitmap raw = null;
        try {
            raw = mmr.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, rw, rh);
        } catch (Throwable ignored) {}
        if (raw == null) {
            try {
                raw = mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST);
            } catch (Throwable ignored) {}
        }
        if (raw == null) {
            try {
                raw = mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            } catch (Throwable ignored) {}
        }
        if (raw == null) return null;
        Bitmap out;
        if (raw.getWidth() == rw && raw.getHeight() == rh) {
            out = raw;
        } else {
            out = scaleCropTo(raw, rw, rh);
            if (out != raw) raw.recycle();
        }
        return out;
    }

    /** 依据当前 MemAvailable 估算安全帧数（v3 流式写入后仅作低内存保护） */
    private static int safeFrameCount(int rw, int rh) {
        long availKb = MemInfo.get().availKb;
        if (availKb <= 0) return FRAMES_MAX;
        if (availKb < 80 * 1024L) {
            // <80MB：极度紧张，保守取 24 帧，保证能生成出来
            android.util.Log.w(TAG, "MemAvailable 极低 " + availKb + "KB，帧数限制到 24");
            return 24;
        }
        if (availKb < 150 * 1024L) {
            android.util.Log.w(TAG, "MemAvailable 偏低 " + availKb + "KB，帧数限制到 60");
            return 60;
        }
        return FRAMES_MAX; // 正常情况完全按用户选择，不降级
    }

    /**
     * 流式 zip 写入器：STORE 不压缩 + desc.txt 用真实分辨率与用户 fps。
     * 每帧写进 zip 后立刻可回收，全程只有一个 Bitmap 在内存。
     */
    private static class ZipWriter {
        private final File file;
        private final int rw, rh, fps;
        private ZipOutputStream zos;
        private FileOutputStream fos;
        private int index = 0;

        ZipWriter(File file, int rw, int rh, int fps) {
            this.file = file; this.rw = rw; this.rh = rh; this.fps = fps;
        }

        void open() throws Exception {
            fos = new FileOutputStream(file);
            zos = new ZipOutputStream(fos);
            zos.setMethod(ZipOutputStream.STORED);
            String desc = rw + " " + rh + " " + fps + "\nc 1 0 part0\n";
            android.util.Log.i(TAG, "bootanim desc=[" + desc.replace("\n", "\\n") + "]");
            writeStored("desc.txt", desc.getBytes("UTF-8"));
        }

        void addFrame(Bitmap fixed) throws Exception {
            index++;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            fixed.compress(Bitmap.CompressFormat.JPEG, 85, bos);
            writeStored(String.format("part0/f%03d.jpg", index), bos.toByteArray());
            fixed.recycle();
        }

        private void writeStored(String name, byte[] bytes) throws Exception {
            ZipEntry e = new ZipEntry(name);
            e.setMethod(ZipEntry.STORED);
            e.setSize(bytes.length);
            e.setCompressedSize(bytes.length);
            java.util.zip.CRC32 crc = new java.util.zip.CRC32();
            crc.update(bytes);
            e.setCrc(crc.getValue());
            zos.putNextEntry(e);
            zos.write(bytes);
            zos.closeEntry();
        }

        void close() {
            try { if (zos != null) zos.close(); } catch (Exception ignored) {}
            try { if (fos != null) fos.close(); } catch (Exception ignored) {}
            android.util.Log.i(TAG, "bootanim zip 完成 帧数=" + index
                    + " 大小=" + (file.length() / 1024) + "KB");
        }
    }

    private static String queryName(Context c, Uri u) {
        try {
            android.database.Cursor cur = c.getContentResolver().query(u, null, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                int col = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                String n = col >= 0 ? cur.getString(col) : null;
                cur.close();
                return n;
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** 关键：必须用设备真实分辨率（RC2 是 1920x1080 横屏！不是 1080x1920） */
    public static int[] realScreenSize(Context c) {
        try {
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            android.view.WindowManager wm = (android.view.WindowManager)
                    c.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) {
                wm.getDefaultDisplay().getRealMetrics(dm);
                if (dm.widthPixels > 0 && dm.heightPixels > 0) {
                    return new int[]{dm.widthPixels, dm.heightPixels};
                }
            }
        } catch (Throwable ignored) {}
        return new int[]{W, H};
    }

    /** 按指定尺寸等比放大裁切（居中） */
    private static Bitmap scaleCropTo(Bitmap src, int tw, int th) {
        int sw = src.getWidth(), sh = src.getHeight();
        float scale = Math.max((float) tw / sw, (float) th / sh);
        int nw = Math.round(sw * scale), nh = Math.round(sh * scale);
        Bitmap scaled = Bitmap.createScaledBitmap(src, nw, nh, true);
        int sx = Math.max(0, (nw - tw) / 2), sy = Math.max(0, (nh - th) / 2);
        Bitmap out = Bitmap.createBitmap(scaled, sx, sy, tw, th);
        if (scaled != src) scaled.recycle();
        return out;
    }

    /**
     * 安装为 Magisk 模块。
     * 关键（实测）：模块 overlay 必须放 system/product/media/ 才会被 overlay 到 /product/media
     * （ROM 的 /system/media 目录根本不存在，放那里不生效）。
     */
    private static boolean installModule(File zip) {
        String path = MODULE + "/system/product/media";
        String cmd = "mkdir -p " + path + "; rm -f " + path + "/bootanimation.zip; "
                + "printf 'id=rc2_bootanim\\nname=RC2 Boot Animation\\nversion=v1.1\\n"
                + "description=device generated\\n' > " + MODULE + "/module.prop; "
                + "rm -f " + MODULE + "/disable; "
                + "cp " + zip.getAbsolutePath() + " " + path + "/bootanimation.zip; "
                + "chmod 644 " + path + "/bootanimation.zip; "
                + "ls -l " + path + "/bootanimation.zip";
        RootShell.Result r = RootShell.exec(cmd, 90);
        return r.isSuccess() && r.trim().contains("bootanimation.zip");
    }

    private static void progress(Context c, String s) {
        if (progressText == null) return;
        final String f = s;
        android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.post(() -> progressText.setText(f));
    }

    // ===== 测试钩子：am start --es action bootanim_gen --es path /sdcard/x.mp4
    //                 [--ei frames N] [--ei fps M] [--ei mode 0|1] =====
    // mode: 0=同步原时长（默认），1=手动帧数
    public static void testGenerate(final Context c, final MainActivity host,
                                    final String path, final int frames, final int fps,
                                    final int testMode) {
        if (path == null || path.isEmpty()) { host.toast("缺少 path"); return; }
        wantFrames = Math.max(FRAMES_MIN, Math.min(FRAMES_MAX, frames > 0 ? frames : FRAMES_DEF));
        wantFps = Math.max(FPS_MIN, Math.min(FPS_MAX, fps > 0 ? fps : FPS_DEF));
        mode = (testMode == MODE_MANUAL) ? MODE_MANUAL : (testMode == MODE_SYNC ? MODE_SYNC : mode);
        final boolean sync = (mode == MODE_SYNC);
        host.runBg(() -> {
            try {
                progress(c, sync ? "测试生成（同步原时长）…"
                        : "测试生成 " + wantFrames + " 帧 / " + wantFps + "fps …");
                File f = new File(path);
                File zip;
                if (path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".jpeg")) {
                    List<Uri> one = new ArrayList<>();
                    one.add(Uri.fromFile(f));
                    List<Uri> all = new ArrayList<>();
                    File dir = f.getParentFile();
                    if (dir != null && dir.isDirectory()) {
                        File[] fs = dir.listFiles();
                        if (fs != null) {
                            java.util.Arrays.sort(fs);
                            for (File x : fs) {
                                String ln = x.getName().toLowerCase();
                                if (ln.endsWith(".png") || ln.endsWith(".jpg") || ln.endsWith(".jpeg"))
                                    all.add(Uri.fromFile(x));
                            }
                        }
                    }
                    if (all.isEmpty()) all = one;
                    zip = sync ? generateFromImagesSync(c, all, wantFps, host)
                               : generateFromImages(c, all, wantFrames, wantFps, host);
                } else {
                    zip = sync ? generateFromVideoSync(c, Uri.fromFile(f), wantFps, host)
                               : generateFromVideo(c, Uri.fromFile(f), wantFrames, wantFps, host);
                }
                if (zip == null) { host.toast("test bootanim_gen -> 失败"); return; }
                boolean ok = installModule(zip);
                android.util.Log.i(TAG, "test bootanim_gen -> " + ok
                        + " zip=" + zip.getAbsolutePath() + " size=" + zip.length());
                host.toast("test bootanim_gen -> " + (ok ? "成功" : "失败"));
                progress(c, ok ? "完成：" + (zip.length() / 1024) + "KB" : "安装失败");
                refreshStatus(c);
            } catch (Throwable t) {
                android.util.Log.e(TAG, "test bootanim_gen", t);
                host.toast("测试生成失败: " + t.getMessage());
            }
        });
    }
}
