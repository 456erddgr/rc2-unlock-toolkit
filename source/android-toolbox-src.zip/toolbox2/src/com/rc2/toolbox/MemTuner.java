package com.rc2.toolbox;

/**
 * 虚拟内存「使用量」调节器
 *
 * 用户要的是「滑块控制虚拟内存实际用多少」，实际通过这几个内核参数实现：
 *   swappiness         0-100  换出倾向（最直接、最有效）
 *   extra_free_kbytes         强制保留的额外真实内存（越大越挤到 swap）
 *   watermark_scale_factor    水位缩放，影响 kswapd 积极性
 *
 * 实测：swappiness 100→0，MemAvailable 从 279MB 涨到 391MB（+112MB 真实内存）
 */
public class MemTuner {

    /** 档位：0=几乎不用swap  50=平衡  100=积极用swap */
    public static final int[] SWAPPINESS_LEVELS = {0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100};

    /** 当前 swappiness */
    public static int getSwappiness() {
        int v = (int) SysFile.readLong("/proc/sys/vm/swappiness");
        return v < 0 ? 100 : Math.min(v, 100);
    }

    /** 当前 extra_free_kbytes（KB） */
    public static long getExtraFree() {
        return SysFile.readLong("/proc/sys/vm/extra_free_kbytes");
    }

    /**
     * 按百分比设置虚拟内存使用倾向。
     * @param pct 0-100，0=最省 swap（多用真实内存），100=最积极用 swap
     */
    public static boolean setUsagePercent(int pct, MainActivity host) {
        if (pct < 0) pct = 0;
        if (pct > 100) pct = 100;

        // 1) swappiness（核心参数，安全，直接映射）
        boolean a = RootShell.exec("echo " + pct + " > /proc/sys/vm/swappiness", 20).isSuccess();

        // 2) extra_free_kbytes：★保守幅度，最多 32MB
        //    1.7GB 设备上强制保留 125MB 会直接 OOM（实测导致死机）
        long extraKb = (long) (100 - pct) * 320L;   // 0%→32000KB(31MB), 100%→0
        RootShell.exec("echo " + extraKb + " > /proc/sys/vm/extra_free_kbytes 2>/dev/null", 20);

        android.util.Log.i("RC2Toolbox", "内存调节 pct=" + pct
                + " swappiness=" + getSwappiness()
                + " extraFree=" + getExtraFree() + "KB");
        return a;
    }

    /** 立刻生效（只温和丢缓存，不做 compact——compact 会长时间卡 CPU） */
    public static void applyNow() {
        RootShell.exec("echo 1 > /proc/sys/vm/drop_caches 2>/dev/null", 20);
    }

    /** 恢复系统默认 */
    public static boolean restore() {
        RootShell.exec("echo 100 > /proc/sys/vm/swappiness 2>/dev/null; "
                + "echo 0 > /proc/sys/vm/extra_free_kbytes 2>/dev/null", 20);
        return true;
    }

    /** 当前真实内存可用（MB） */
    public static long availMb() {
        return MemInfo.get().availKb / 1024;
    }

    /** 当前 swap 总用量（MB） */
    public static long swapUsedMb() {
        MemInfo.Mem m = MemInfo.get();
        return (m.zramUsedKb + m.diskUsedKb) / 1024;
    }
}
