package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 性能页：四档模式（带点击！）+ 实时状态 + 手动调控 */
public class PerfPage {

    private static TextView statusLine;
    private static LinearLayout segBox;
    private static int curMode = 0;

    public static View build(final Context c, final MainActivity host) {
        LinearLayout page = UI.page(c);

        // 模式卡片
        LinearLayout modeCard = UI.card(c);
        modeCard.addView(UI.sectionTitle(c, "性能模式"));
        segBox = UI.segmented(c, new String[]{"省电", "均衡", "性能", "极速"}, curMode,
                (idx, label) -> {
                    boolean ok;
                    switch (idx) {
                        case 0: ok = CpuGpu.applySave(); break;
                        case 1: ok = CpuGpu.applyBalanced(); break;
                        case 2: ok = CpuGpu.applyPerf(); break;
                        default: ok = CpuGpu.applyExtreme(); break;
                    }
                    curMode = idx;
                    host.toast(label + " 已应用" + (ok ? "" : "（部分失败）"));
                    refreshStatus(c);
                });
        modeCard.addView(segBox);
        page.addView(modeCard);

        // 实时状态
        LinearLayout infoCard = UI.card(c);
        infoCard.addView(UI.sectionTitle(c, "实时状态"));
        statusLine = new TextView(c);
        statusLine.setTextSize(13);
        statusLine.setTextColor(UI.TEXT_DIM);
        statusLine.setPadding(0, UI.dp(4), 0, UI.dp(4));
        infoCard.addView(statusLine);
        page.addView(infoCard);

        // 手动调控
        LinearLayout actCard = UI.card(c);
        actCard.addView(UI.sectionTitle(c, "手动调控"));
        LinearLayout row1 = UI.buttonRow(c,
                UI.button2(c, "省电"), UI.button2(c, "均衡"), UI.button2(c, "性能"));
        actCard.addView(row1);
        UI.space(c, actCard, 6);
        LinearLayout row2 = UI.buttonRow(c,
                UI.button(c, "极速模式", UI.DANGER), UI.button2(c, "恢复默认"));
        actCard.addView(row2);

        ((TextView) row1.getChildAt(0)).setOnClickListener(v -> applyAndToast(host, c, 0, "省电"));
        ((TextView) row1.getChildAt(1)).setOnClickListener(v -> applyAndToast(host, c, 1, "均衡"));
        ((TextView) row1.getChildAt(2)).setOnClickListener(v -> applyAndToast(host, c, 2, "性能"));
        ((TextView) row2.getChildAt(0)).setOnClickListener(v -> applyAndToast(host, c, 3, "极速"));
        ((TextView) row2.getChildAt(1)).setOnClickListener(v -> {
            boolean ok = CpuGpu.applyBalanced();
            host.toast(ok ? "已恢复默认" : "恢复失败");
            refreshStatus(c);
        });
        page.addView(actCard);

        refreshStatus(c);
        return UI.scroll(c, page);
    }

    private static void applyAndToast(MainActivity host, Context c, int idx, String label) {
        host.runBg(() -> {
            boolean ok;
            switch (idx) {
                case 0: ok = CpuGpu.applySave(); break;
                case 1: ok = CpuGpu.applyBalanced(); break;
                case 2: ok = CpuGpu.applyPerf(); break;
                default: ok = CpuGpu.applyExtreme(); break;
            }
            final boolean okf = ok;
            curMode = idx;
            host.post(() -> {
                host.toast(label + " 已应用" + (okf ? "" : "（部分失败）"));
                syncSeg(segBox, idx);
                refreshStatus(c);
            });
        });
    }

    /** 同步分段控件高亮 */
    private static void syncSeg(LinearLayout box, int idx) {
        if (box == null) return;
        for (int i = 0; i < box.getChildCount(); i++) {
            View v = box.getChildAt(i);
            if (!(v instanceof TextView)) continue;
            TextView t = (TextView) v;
            if (i == idx) {
                t.setTextColor(0xFFFFFFFF);
                t.setBackground(UI.rounded(UI.ACCENT, UI.dp(7), 0, 0));
                t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            } else {
                t.setTextColor(UI.TEXT_DIM);
                t.setBackgroundColor(0x00000000);
                t.setTypeface(android.graphics.Typeface.DEFAULT);
            }
        }
    }

    private static void refreshStatus(Context c) {
        if (statusLine == null) return;
        host_runBg(() -> {
            String gov = CpuGpu.governor();
            String cpu = CpuGpu.curFreqMhz();
            String gpu = CpuGpu.gpuCurMhz();
            String gpuMax = CpuGpu.gpuMaxMhz();
            String cpuMax = CpuGpu.cpuMaxMhz();
            String clusters = CpuGpu.allClusterMax();
            String t = CpuGpu.cpuTempC();
            final String s = "策略 " + gov + "\n"
                    + "当前 CPU " + cpu + "  ·  GPU " + gpu + "/" + gpuMax + "\n"
                    + "已设上限 " + cpuMax + "\n"
                    + "各簇最高 " + clusters + "\n"
                    + "温度 " + t + "℃";
            if (statusLine != null) {
                statusLine.post(() -> {
                    statusLine.setText(s);
                    statusLine.setTextColor(UI.TEXT);
                });
            }
        });
    }

    private static void host_runBg(Runnable r) {
        Thread t = new Thread(r, "perf-refresh");
        t.setDaemon(true);
        t.start();
    }
}
