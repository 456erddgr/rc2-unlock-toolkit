package com.rc2.toolbox;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 自启与系统服务管理：开机自启/系统服务/进程管理 */
public class AutoStartPage {

    private static Context ctx;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);

        LinearLayout modCard = UI.card(c);
        modCard.addView(UI.sectionTitle(c, "已装 Magisk 模块"));
        page.addView(modCard);

        LinearLayout svcCard = UI.card(c);
        svcCard.addView(UI.sectionTitle(c, "系统服务（点按停止/启动）"));
        page.addView(svcCard);

        LinearLayout procCard = UI.card(c);
        procCard.addView(UI.sectionTitle(c, "高占用进程 Top 8"));
        page.addView(procCard);

        host.runBg(() -> {
            // 用简单命令，避免 shell 变量在字符串里被处理
            RootShell.Result r = RootShell.exec("ls -1 /data/adb/modules/ 2>/dev/null", 15);
            java.util.List<String> ids = new java.util.ArrayList<>();
            for (String l : r.trim().split("\n")) {
                String t = l.trim();
                if (!t.isEmpty() && !t.startsWith(".")) ids.add(t);
            }
            // 再逐个取版本
            java.util.List<String[]> mods = new java.util.ArrayList<>();
            for (String id : ids) {
                String ver = RootShell.exec("grep -m1 version= /data/adb/modules/" + id
                        + "/module.prop 2>/dev/null", 8).trim();
                int eq = ver.indexOf('=');
                String v = eq >= 0 ? ver.substring(eq + 1).trim() : "";
                mods.add(new String[]{id, v});
            }
            host.post(() -> {
                int keep = modCard.getChildCount() > 0 ? 1 : 0;
                if (modCard.getChildCount() > keep) modCard.removeViews(keep, modCard.getChildCount() - keep);
                for (String[] mm : mods) {
                    String ver = mm[1];
                    String show = ver.isEmpty() ? "?" : (ver.startsWith("v") ? ver : "v" + ver);
                    modCard.addView(UI.kvRow(c, mm[0], show, UI.OK));
                }
                if (mods.isEmpty()) modCard.addView(UI.dim(c, "无模块"));
            });
        });

        host.runBg(() -> {
            String[] svcs = {"zygote", "zygote_secondary", "bootanim", "thermal-hal", "surfaceflinger"};
            java.util.List<String[]> list = new java.util.ArrayList<>();
            for (String s : svcs) {
                String st = RootShell.exec("getprop init.svc." + s, 8).trim();
                if (!st.isEmpty()) list.add(new String[]{s, st});
            }
            host.post(() -> {
                int keep = svcCard.getChildCount() > 0 ? 1 : 0;
                if (svcCard.getChildCount() > keep) svcCard.removeViews(keep, svcCard.getChildCount() - keep);
                for (String[] sp : list) {
                    LinearLayout row = UI.kvRow(c, sp[0], sp[1],
                            sp[1].contains("running") ? UI.OK : UI.TEXT_DIM);
                    svcCard.addView(row);
                }
            });
        });

        host.runBg(() -> {
            RootShell.Result r = RootShell.exec(
                    "ps -A -o RSS,NAME --sort=-rss 2>/dev/null | head -9", 20);
            host.post(() -> {
                int keep = procCard.getChildCount() > 0 ? 1 : 0;
                if (procCard.getChildCount() > keep) procCard.removeViews(keep, procCard.getChildCount() - keep);
                for (String l : r.trim().split("\n")) {
                    String t = l.trim();
                    if (t.isEmpty()) continue;
                    String[] p = SysFile.splitWs(t);
                    if (p.length < 2) continue;
                    if (p[0].equals("RSS")) continue;
                    long kb = SysFile.parseLong(p[0]);
                    procCard.addView(UI.kvRow(c, p[1], MemInfo.mb(kb),
                            kb > 200000 ? UI.DANGER : UI.TEXT_DIM));
                }
            });
        });

        return UI.scroll(c, page);
    }
}
