package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 电池详情页：容量/温度/电流/健康/充电状态 */
public class BatteryPage {

    private static Context ctx;
    private static LinearLayout infoCard, healthCard;
    private static long lastPct = -1;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);

        infoCard = UI.card(c);
        infoCard.addView(UI.sectionTitle(c, "电池状态"));
        page.addView(infoCard);

        healthCard = UI.card(c);
        healthCard.addView(UI.sectionTitle(c, "健康与充电"));
        page.addView(healthCard);

        LinearLayout actCard = UI.card(c);
        actCard.addView(UI.sectionTitle(c, "操作"));
        LinearLayout r1 = UI.buttonRow(c,
                UI.button(c, "立即刷新", UI.ACCENT), UI.button2(c, "导出"));
        actCard.addView(r1);
        page.addView(actCard);

        ((TextView) r1.getChildAt(0)).setOnClickListener(v -> { refresh(); host.toast("已刷新"); });
        ((TextView) r1.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            StringBuilder sb = new StringBuilder();
            for (String f : new String[]{"capacity", "status", "health", "temp", "voltage_now",
                    "current_now", "charge_type", "technology", "present"}) {
                String val = RootShell.exec("cat /sys/class/power_supply/aprimary-bat/" + f + " 2>/dev/null", 8).trim();
                sb.append(f).append(" = ").append(val).append('\n');
            }
            final String s = sb.toString();
            host.post(() -> host.toast(s.replace("\n", "  ")));
        }));

        refresh();
        return UI.scroll(c, page);
    }

    private static void refresh() {
        if (ctx == null) return;
        MemInfo.Mem m = MemInfo.get();
        String base = "/sys/class/power_supply/aprimary-bat";

        rebuild(infoCard);
        int pct = (int) m.batteryPct;
        infoCard.addView(UI.kvRow(ctx, "电量", (pct >= 0 ? pct + "%" : "-"),
                pct <= 20 ? UI.DANGER : (pct <= 40 ? UI.WARN : UI.OK)));
        infoCard.addView(UI.kvRow(ctx, "状态",
                RootShell.exec("cat " + base + "/status 2>/dev/null", 8).trim(), UI.ACCENT));
        long temp = SysFile.readLong(base + "/temp");
        infoCard.addView(UI.kvRow(ctx, "温度",
                temp > 0 ? (temp / 10) + "℃" : "-", UI.tempColor(temp / 10)));
        long volt = SysFile.readLong(base + "/voltage_now");
        infoCard.addView(UI.kvRow(ctx, "电压",
                volt > 0 ? (volt / 1000) + " mV" : "-", UI.TEXT_DIM));

        rebuild(healthCard);
        long cur = SysFile.readLong(base + "/current_now");
        healthCard.addView(UI.kvRow(ctx, "电流",
                cur != 0 ? (cur / 1000) + " mA" : "-", UI.ACCENT2));
        healthCard.addView(UI.kvRow(ctx, "健康",
                RootShell.exec("cat " + base + "/health 2>/dev/null", 8).trim(), UI.OK));
        healthCard.addView(UI.kvRow(ctx, "技术",
                RootShell.exec("cat " + base + "/technology 2>/dev/null", 8).trim(), UI.TEXT_DIM));
        healthCard.addView(UI.kvRow(ctx, "充电类型",
                RootShell.exec("cat " + base + "/charge_type 2>/dev/null", 8).trim(), UI.TEXT_DIM));
        String ac = RootShell.exec("cat /sys/class/power_supply/aprimary-ac/online 2>/dev/null", 8).trim();
        healthCard.addView(UI.kvRow(ctx, "充电器", ac.equals("1") ? "已连接" : "未连接",
                ac.equals("1") ? UI.OK : UI.TEXT_DIM));
    }

    private static void rebuild(LinearLayout card) {
        int keep = card.getChildCount() > 0 ? 1 : 0;
        if (card.getChildCount() > keep) card.removeViews(keep, card.getChildCount() - keep);
    }
}
