package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

/** 虚拟内存页：与 Magisk 模块 rc2_swapfile 打通 */
public class SwapPage {

    public static final String MODULE = "/data/adb/modules/rc2_swapfile";
    private static final String CTL = MODULE + "/swapctl.sh";
    private static final String DISABLE_MARK = MODULE + "/disable";
    private static final String SWAPFILE = "/data/local/rc2_swapfile";
    /** 磁盘 swap 优先级：必须 **低于** zram(32758)，否则内容全塞慢速磁盘 → 系统卡顿（铁律 4） */
    private static final int PRIORITY = 10;
    private static final String TAG = "RC2Toolbox";
    private static LinearLayout statusCard;
    private static Context ctx;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);
        statusCard = UI.card(c);
        statusCard.addView(UI.sectionTitle(c, "当前状态"));
        page.addView(statusCard);

        LinearLayout cfgCard = UI.card(c);
        cfgCard.addView(UI.sectionTitle(c, "容量设置"));
        int curSize = readSizeMb();
        final TextView sizeText = new TextView(c);
        sizeText.setText(curSize + " MB");
        sizeText.setTextSize(16);
        sizeText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        sizeText.setTextColor(UI.ACCENT);
        cfgCard.addView(sizeText);
        SeekBar sizeBar = new SeekBar(c);
        sizeBar.setMax(4096 - 256);
        sizeBar.setProgress(Math.max(0, curSize - 256));
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) { if (u) sizeText.setText((v + 256) + " MB"); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        cfgCard.addView(sizeBar);
        cfgCard.addView(UI.dim(c, "范围 256MB ~ 4096MB，建议 1024-2048MB"));
        page.addView(cfgCard);

        // ★★ 虚拟内存「使用量」调节（用户核心需求）★★
        LinearLayout swCard = UI.card(c);
        swCard.addView(UI.sectionTitle(c, "虚拟内存使用量"));

        int curSw = MemTuner.getSwappiness();
        final TextView swText = new TextView(c);
        swText.setText("使用倾向 " + curSw + "%");
        swText.setTextSize(17);
        swText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        swText.setTextColor(UI.ACCENT2);
        swCard.addView(swText);

        final TextView swHint = new TextView(c);
        swHint.setTextSize(12);
        swHint.setTextColor(UI.TEXT_DIM);
        swHint.setPadding(0, UI.dp(2), 0, UI.dp(6));
        swCard.addView(swHint);

        SeekBar swBar = new SeekBar(c);
        swBar.setMax(100);
        swBar.setProgress(curSw);
        swBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (!u) return;
                swText.setText("使用倾向 " + v + "%");
                swHint.setText(hintFor(v));
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        swCard.addView(swBar);
        swHint.setText(hintFor(curSw));

        LinearLayout swBtnRow = UI.buttonRow(c,
                UI.button(c, "应用并立即生效", UI.ACCENT), UI.button2(c, "恢复默认"));
        swCard.addView(swBtnRow);

        ((TextView) swBtnRow.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            final int pct = swBar.getProgress();
            boolean ok = MemTuner.setUsagePercent(pct, host);
            MemTuner.applyNow();
            host.post(() -> {
                host.toast(ok ? "虚拟内存使用倾向已设为 " + pct + "%" : "设置失败");
                refreshStatus();
            });
        }));
        ((TextView) swBtnRow.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            MemTuner.restore();
            host.post(() -> { host.toast("已恢复系统默认"); refreshStatus(); });
        }));

        swCard.addView(UI.dim(c, "• 低 % = 少用虚拟内存，多用真实内存（更快但内存紧张）\n"
                + "• 高 % = 积极换出到虚拟内存（真实内存更宽松）\n"
                + "• 实测：100%→0% 可让真实可用内存多出 100MB 以上"));

        // ★ zram 容量调节（新功能）
        LinearLayout zCard = UI.card(c);
        zCard.addView(UI.sectionTitle(c, "zram 压缩内存容量"));
        long zCur = ZramManager.currentSizeMb();
        final TextView zText = new TextView(c);
        zText.setText(zCur + " MB（当前）");
        zText.setTextSize(16);
        zText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        zText.setTextColor(UI.OK);
        zCard.addView(zText);

        SeekBar zBar = new SeekBar(c);
        int zMaxMb = 6144;               // 上限 6GB
        zBar.setMax((zMaxMb - 256) / 64);
        zBar.setProgress((int) ((zCur - 256) / 64));
        zBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int v, boolean u) {
                if (u) zText.setText((v * 64 + 256) + " MB");
            }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
        });
        zCard.addView(zBar);
        zCard.addView(UI.dim(c, "范围 256MB ~ 6GB。扩容让 swap 总量变大，"
                + "但「总内存」= 物理内存（硬件值，任何软件都改不了）"));

        TextView zApply = UI.button(c, "应用 zram 容量", UI.OK);
        zApply.setOnClickListener(v -> host.runBg(() -> {
            final int mb = zBar.getProgress() * 64 + 256;
            host.post(() -> host.toast("正在调整 zram 到 " + mb + "MB，请稍候…"));
            boolean ok = ZramManager.resize(mb, 32758);
            host.post(() -> {
                host.toast(ok ? "zram 已设为 " + ZramManager.currentSizeMb() + "MB"
                              : "zram 调整失败");
                refreshStatus();
            });
        }));
        zCard.addView(zApply);

        UI.space(c, zCard, 6);
        LinearLayout zAlgoRow = UI.buttonRow(c,
                UI.button2(c, "切 lz4"), UI.button2(c, "切 zstd"));
        zCard.addView(zAlgoRow);
        ((TextView) zAlgoRow.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = ZramManager.setAlgo("lz4");
            host.post(() -> { host.toast(ok ? "已切 lz4" : "切换失败(zram 使用中)"); refreshStatus(); });
        }));
        ((TextView) zAlgoRow.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = ZramManager.setAlgo("zstd");
            host.post(() -> { host.toast(ok ? "已切 zstd" : "切换失败(zram 使用中)"); refreshStatus(); });
        }));
        page.addView(swCard);
        page.addView(zCard);

        // ★ 单应用堆上限（扩大后 App 能用更多内存）
        LinearLayout heapCard = UI.card(c);
        heapCard.addView(UI.sectionTitle(c, "单应用堆上限（dalvik）"));
        String hs = RootShell.exec("getprop dalvik.vm.heapsize", 10).trim();
        String hg = RootShell.exec("getprop dalvik.vm.heapgrowthlimit", 10).trim();
        heapCard.addView(UI.kvRow(c, "heapsize", hs.isEmpty() ? "-" : hs, UI.ACCENT));
        heapCard.addView(UI.kvRow(c, "heapgrowthlimit", hg.isEmpty() ? "-" : hg, UI.ACCENT2));
        heapCard.addView(UI.dim(c, "默认 256m/192m。提到 512m/384m 后单应用可用内存翻倍，"
                + "系统「总内存」仍显示物理值（硬件事实）"));
        LinearLayout heapRow = UI.buttonRow(c,
                UI.button(c, "提升到 512m", UI.OK), UI.button2(c, "恢复默认"));
        heapCard.addView(heapRow);
        ((TextView) heapRow.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("/debug_ramdisk/resetprop -n dalvik.vm.heapsize 512m 2>/dev/null; "
                    + "/debug_ramdisk/resetprop -n dalvik.vm.heapgrowthlimit 384m 2>/dev/null", 30);
            final String ns = RootShell.exec("getprop dalvik.vm.heapsize", 10).trim();
            host.post(() -> {
                host.toast("堆上限已提到 " + ns + "（重启后由 rc2_memexp 模块保持）");
                refreshStatus();
            });
        }));
        ((TextView) heapRow.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            RootShell.exec("/debug_ramdisk/resetprop -n dalvik.vm.heapsize 256m 2>/dev/null; "
                    + "/debug_ramdisk/resetprop -n dalvik.vm.heapgrowthlimit 192m 2>/dev/null", 30);
            host.post(() -> { host.toast("已恢复默认 256m/192m"); refreshStatus(); });
        }));
        page.addView(heapCard);

        LinearLayout actCard = UI.card(c);
        actCard.addView(UI.sectionTitle(c, "操作"));
        LinearLayout row1 = UI.buttonRow(c, UI.button(c, "开启 swap", UI.OK), UI.button2(c, "关闭"));
        actCard.addView(row1);
        UI.space(c, actCard, 6);
        TextView applyBtn = UI.button(c, "应用容量 + 换出设置", UI.ACCENT);
        actCard.addView(applyBtn);
        page.addView(actCard);

        // 开启：文件在→秒级 swapon；文件不在/大小不符→自动重建（会提示耗时）
        ((TextView) row1.getChildAt(0)).setOnClickListener(v -> host.runBg(() -> {
            int size = sizeBar.getProgress() + 256;
            boolean needRebuild = isDiskActive() ? false
                    : swapFileSizeBytes() != (long) size * 1048576L;
            if (needRebuild) {
                host.post(() -> host.toast("正在创建 " + size + "MB swap 文件，请稍候 1-2 分钟…"));
            }
            boolean ok = doEnable(c, size);
            host.post(() -> {
                if (ok) host.toast("swap 已开启（磁盘 " + (size) + "MB，优先级 10）");
                else host.toast("开启失败：内存不足或创建超时，请稍后重试");
                refreshStatus();
            });
        }));

        ((TextView) row1.getChildAt(1)).setOnClickListener(v -> host.runBg(() -> {
            boolean ok = doDisable(c);
            host.post(() -> {
                if (ok) {
                    host.toast("磁盘 swap 已关闭；zram 是系统必需，保持启用");
                } else {
                    // 如实说明为什么没关掉
                    boolean disk = isDiskActive();
                    host.toast(disk
                            ? "swap 仍在用（数据未换出完），已设开机禁用；重启后彻底关闭"
                            : "关闭失败：无法写入 disable 标记（检查 root 权限）");
                }
                refreshStatus();
            });
        }));

        // 应用容量 = 重建（慢操作，明确提示）
        applyBtn.setOnClickListener(v -> host.runBg(() -> {
            final int size = sizeBar.getProgress() + 256;
            final int sw = swBar.getProgress();
            host.post(() -> host.toast("正在重建 " + size + "MB，请稍候 1-2 分钟…"));
            boolean ok = doResize(c, size);
            RootShell.exec("echo " + sw + " > /proc/sys/vm/swappiness 2>/dev/null");
            host.post(() -> {
                host.toast(ok ? "已重建并应用 " + size + "MB" : "重建失败（内存不足或超时）");
                refreshStatus();
            });
        }));

        refreshStatus();
        return UI.scroll(c, page);
    }

    private static void refreshStatus() {
        if (statusCard == null || ctx == null) return;
        int keep = statusCard.getChildCount() > 0 ? 1 : 0;
        if (statusCard.getChildCount() > keep) statusCard.removeViews(keep, statusCard.getChildCount() - keep);
        MemInfo.Mem m = MemInfo.get();

        // 真实内存（最关心）
        int realPct = m.totalKb > 0 ? (int) (m.availKb * 100 / m.totalKb) : 0;
        statusCard.addView(UI.kvRow(ctx, "★ 真实内存可用",
                MemInfo.mb(m.availKb) + "（" + realPct + "%）", UI.levelColor(100 - realPct)));
        statusCard.addView(UI.kvRow(ctx, "虚拟内存使用倾向",
                MemTuner.getSwappiness() + "%", UI.ACCENT2));

        // zram（优先级高，系统优先用）
        if (m.zramActive) {
            int zPct = m.zramSizeKb > 0 ? (int) (m.zramUsedKb * 100 / m.zramSizeKb) : 0;
            statusCard.addView(UI.kvRow(ctx, "zram（优先）",
                    MemInfo.mb(m.zramSizeKb) + " · 用 " + MemInfo.mb(m.zramUsedKb)
                            + " (" + zPct + "%)", UI.OK));
        } else {
            statusCard.addView(UI.kvRow(ctx, "zram（优先）", "未启用", UI.WARN));
        }

        // 磁盘 swap（后备，zram 不够才用）
        if (m.diskActive) {
            int dPct = m.diskSwapKb > 0 ? (int) (m.diskUsedKb * 100 / m.diskSwapKb) : 0;
            int color = dPct > 0 ? UI.OK : UI.ACCENT2;
            statusCard.addView(UI.kvRow(ctx, "磁盘 swap（后备）",
                    MemInfo.mb(m.diskSwapKb) + " · 用 " + MemInfo.mb(m.diskUsedKb)
                            + " (" + dPct + "%)", color));
            statusCard.addView(UI.kvRow(ctx, "磁盘优先级",
                    String.valueOf(m.diskPriority), UI.TEXT_DIM));
        } else {
            statusCard.addView(UI.kvRow(ctx, "磁盘 swap（后备）", "未启用", UI.WARN));
        }

        // 总 swap（含 zram 扩容后的真实总量）
        long totalSwap = m.zramSizeKb + m.diskSwapKb;
        long totalUsed = m.zramUsedKb + m.diskUsedKb;
        statusCard.addView(UI.kvRow(ctx, "swap 合计",
                MemInfo.mb(totalSwap) + " · 用 " + MemInfo.mb(totalUsed), UI.ACCENT));
        statusCard.addView(UI.kvRow(ctx, "系统总内存",
                MemInfo.mb(m.totalKb) + "（物理，不可改）", UI.TEXT_DIM));
        statusCard.addView(UI.kvRow(ctx, "zram 压缩比", ZramManager.ratio(), UI.ACCENT2));

        // 说明（避免"已开启但用0"的困惑）
        if (m.diskActive && m.diskUsedKb < 1024 && m.zramActive) {
            TextView note = new TextView(ctx);
            note.setText("磁盘 swap 已启用但用量为 0 是正常的：\nzram 还有空间，系统优先用 zram（更快），\n只有 zram 吃满才会换到磁盘。");
            note.setTextSize(11);
            note.setTextColor(UI.TEXT_DIM);
            note.setLineSpacing(0, 1.15f);
            note.setPadding(0, UI.dp(4), 0, UI.dp(2));
            statusCard.addView(note);
        }

        boolean modReady = moduleExists();
        statusCard.addView(UI.kvRow(ctx, "开机模块", modReady ? "已安装 ✓" : "缺失 ✗", modReady ? UI.OK : UI.DANGER));
        statusCard.addView(UI.kvRow(ctx, "配置容量", readSizeMb() + " MB", UI.ACCENT));
        int availPct = m.totalKb > 0 ? (int) (m.availKb * 100 / m.totalKb) : 0;
        statusCard.addView(UI.kvRow(ctx, "内存可用", MemInfo.mb(m.availKb) + "（" + availPct + "%）", UI.levelColor(100 - availPct)));
    }

    /**
     * /data/adb 权限 drwx------ root root，普通 app 无法 File.exists，
     * 必须走 root/adb 检查。readSizeMb 同理（虽然 size_mb 也读不到，给默认值）。
     */
    private static boolean moduleExists() {
        return RootShell.exec("test -f " + CTL + " && echo YES", 8).trim().contains("YES");
    }

    private static int readSizeMb() {
        // 先试免 root
        String s = SysFile.readLine(MODULE + "/size_mb");
        int v = (int) SysFile.parseLong(s);
        if (v >= 256 && v <= 4096) return v;
        // 降级走 root
        s = RootShell.exec("cat " + MODULE + "/size_mb", 8).trim();
        v = (int) SysFile.parseLong(s);
        return v >= 256 && v <= 4096 ? v : 2048;
    }

    private static int readSwappiness() {
        int v = (int) SysFile.readLong("/proc/sys/vm/swappiness");
        return v < 0 ? 60 : Math.min(v, 200);
    }

    /**
     * 开启：只做 swapon（秒级，绝不重建文件）
     * ★ 卡死根因：旧版调 swapctl.sh on，若文件大小不符会触发 89 秒重建，
     *   超出超时并让 UI 假死。现在文件大小对就直接 swapon，不对则明确报错。
     */
    public static boolean doEnable(Context c, int sizeMb) {
        // ★ v2.18：有 disable 标记时先清掉，否则开机 service.sh 永远跳过
        RootShell.Result un = RootShell.exec("rm -f " + DISABLE_MARK + " 2>&1", 15);
        android.util.Log.i(TAG, "enable: 清除 disable 标记 exit=" + un.exit);

        // 已经在跑直接成功（幂等，避免重复 swapon 报 Device or resource busy）
        if (isDiskActive()) {
            android.util.Log.i(TAG, "enable: 磁盘 swap 已在运行，幂等返回成功");
            RootShell.exec("echo " + sizeMb + " > " + MODULE + "/size_mb 2>/dev/null");
            return true;
        }

        long want = (long) sizeMb * 1048576L;
        long cur = swapFileSizeBytes();

        // ★ v2.18 关键修复：文件不存在或大小不符时**自动重建**（旧版直接返回 false
        //   → 用户点「开启」永远失败，因为「关闭」会把文件删掉）。
        if (cur != want) {
            android.util.Log.i(TAG, "enable: 需要重建 (cur=" + cur + " want=" + want + ")");
            RootShell.exec("echo " + sizeMb + " > " + MODULE + "/size_mb 2>/dev/null");
            // 重建走模块脚本（分块 dd + sync，已修卡死 bug），超时给足
            RootShell.Result rr = RootShell.exec("sh " + CTL + " resize " + sizeMb,
                    RootShell.LONG_TIMEOUT_SEC);
            android.util.Log.i(TAG, "enable: resize exit=" + rr.exit + " out=" + rr.trim());
            // 重建后脚本内部已 swapon；再兜一次
            if (!isDiskActive()) {
                RootShell.exec("/system/bin/swapon -p " + PRIORITY
                        + " " + SWAPFILE + " 2>&1", 60);
            }
            RootShell.exec("echo " + sizeMb + " > " + MODULE + "/size_mb 2>/dev/null");
            boolean ok2 = isDiskActive();
            android.util.Log.i(TAG, "enable 重建后 active=" + ok2);
            return ok2;
        }

        // 大小正好 → 秒级 swapon
        RootShell.Result r = RootShell.exec(
                "/system/bin/swapon -p " + PRIORITY + " " + SWAPFILE + " 2>&1", 60);
        boolean ok = isDiskActive();
        android.util.Log.i(TAG, "swapon=" + r.trim() + " active=" + ok);
        return ok;
    }

    /** swap 文件字节数（不存在返回 0，纯数字，走 root stat） */
    public static long swapFileSizeBytes() {
        String s = RootShell.exec("stat -c %s " + SWAPFILE + " 2>/dev/null", 20).trim();
        return SysFile.parseLong(s);
    }

    /**
     * 关闭磁盘 swap —— v2.17 改为纯本地逻辑，完全不调 swapctl.sh。
     *
     * 旧版问题：走 `sh swapctl.sh off`，toybox swapoff 对 2GB 文件常报
     * "Invalid argument" 且脚本里还有重试/等待，导致 UI 假死。
     *
     * 新流程（每一步都记 logcat，便于事后取证）：
     *   ① swapoff（失败不致命，继续）
     *   ② rm -f 删文件（释放磁盘；关闭后「开启」需要先重建，这是刻意设计）
     *   ③ touch disable 标记（关键：阻止开机 service.sh 又把 2GB 文件建回来，
     *      历史「开机 56 秒死机」就是它导致的）
     *   ④ 重新读 /proc/swaps 如实判断：只剩 /dev/block/zram0 即成功
     *
     * 铁律：zram 是系统必需，本方法绝不 swapoff /dev/block/zram0。
     */
    public static boolean doDisable(Context c) {
        // ① swapoff（非致命：toybox 对大文件常报 Invalid argument，
        //    但只要 /proc/swaps 里还有它就得先摘掉）
        if (isDiskActive()) {
            RootShell.Result off = RootShell.exec(
                    "/system/bin/swapoff " + SWAPFILE + " 2>&1", 120);
            android.util.Log.i(TAG, "swapoff -> exit=" + off.exit + " out=" + off.trim());
            // 兜底：swapoff 失败（Invalid argument）时，先把 swap 用量尽量换出再重试一次
            if (isDiskActive()) {
                RootShell.exec("echo 100 > /proc/sys/vm/swappiness 2>/dev/null", 10);
                try { Thread.sleep(1500); } catch (InterruptedException ignored) {}
                RootShell.Result off2 = RootShell.exec(
                        "/system/bin/swapoff " + SWAPFILE + " 2>&1", 120);
                android.util.Log.i(TAG, "swapoff retry -> exit=" + off2.exit
                        + " out=" + off2.trim());
            }
        }

        // ② disable 标记（关键：阻止开机 service.sh 又把 2GB 文件建回来，
        //    历史「开机 56 秒死机」就是它导致的）
        RootShell.exec("mkdir -p " + MODULE + " 2>/dev/null", 15);
        RootShell.Result mk = RootShell.exec("touch " + DISABLE_MARK + " 2>&1", 15);
        boolean marked = RootShell.exec(
                "test -f " + DISABLE_MARK + " && echo Y", 10).trim().contains("Y");
        android.util.Log.i(TAG, "disable 标记 -> touchExit=" + mk.exit + " exists=" + marked);

        // ③ 只有确实从 /proc/swaps 摘掉了才删文件；
        //    还在跑就保留文件（删掉会让内核访问已释放 swap → 崩），下次再关
        boolean diskLeft = isDiskActive();
        boolean fileLeft = swapFile();
        boolean removed = false;
        if (!diskLeft && fileLeft) {
            RootShell.Result rm = RootShell.exec("rm -f " + SWAPFILE + " 2>&1", 30);
            android.util.Log.i(TAG, "rm swapfile -> exit=" + rm.exit + " out=" + rm.trim());
            removed = !swapFile();
        } else if (diskLeft) {
            android.util.Log.w(TAG, "swapoff 未成功，保留文件以免内核崩溃（可重启后自动消失）");
        }

        // ④ 如实复查（zram 状态只读，绝不动）
        diskLeft = isDiskActive();
        fileLeft = swapFile();
        boolean zramOn = isZramActive();
        // ★ v2.18：判定标准放宽——只要磁盘 swap 不在 /proc/swaps 里就是关闭成功。
        //   （旧版要求 marked && !fileLeft 全中，任一环境差异就永远报失败）
        boolean ok = !diskLeft && marked;
        android.util.Log.i(TAG, "关闭 swap 结果: diskLeft=" + diskLeft + " fileLeft=" + fileLeft
                + " marked=" + marked + " removed=" + removed + " zramOn=" + zramOn
                + " ok=" + ok);
        android.util.Log.i(TAG, "swaps: " + swapsSnapshot());
        return ok;
    }

    /**
     * 重建（用户明确点"应用容量"才走这里，会耗时 60-120 秒）
     * 调用方必须在后台线程 + 显示进度提示
     */
    public static boolean doResize(Context c, int sizeMb) {
        if (!moduleExists()) return false;
        RootShell.Result r = RootShell.exec("sh " + CTL + " resize " + sizeMb,
                RootShell.LONG_TIMEOUT_SEC);
        RootShell.exec("echo " + sizeMb + " > " + MODULE + "/size_mb 2>/dev/null");
        return r.isSuccess();
    }

    /** 磁盘 swap 是否在跑（用 grep -q + echo 方式，避免 -c 计数格式问题） */
    /** 滑块档位说明 */
    private static String hintFor(int pct) {
        if (pct <= 15) return "极省虚拟内存 · 真实内存优先（最快，内存吃紧）";
        if (pct <= 40) return "偏省 · 真实内存为主";
        if (pct <= 60) return "平衡（推荐）";
        if (pct <= 85) return "偏积极 · 更多内容进虚拟内存";
        return "极积极 · 真实内存最宽松（磁盘 IO 增多）";
    }

    public static boolean isDiskActive() {
        String o = RootShell.exec("grep rc2_swapfile /proc/swaps 2>/dev/null | head -1", 15).trim();
        return o.contains("rc2_swapfile");
    }

    /** zram 是否在挂（只读判断；zram 是系统必需，任何代码都不许 swapoff 它） */
    public static boolean isZramActive() {
        return RootShell.exec("grep zram0 /proc/swaps >/dev/null 2>&1 && echo Y", 10)
                .trim().contains("Y");
    }

    /** /proc/swaps 快照（单行，仅用于 logcat 取证） */
    public static String swapsSnapshot() {
        return RootShell.exec("cat /proc/swaps 2>/dev/null | tr '\\n' '|'", 10).trim();
    }

    /** disable 标记是否存在（开机模块会据此跳过） */
    public static boolean disableMarked() {
        return RootShell.exec("test -f " + DISABLE_MARK + " && echo Y", 10).trim().contains("Y");
    }

    /** swap 文件是否存在 */
    public static boolean swapFile() {
        return RootShell.exec("test -f /data/local/rc2_swapfile && echo Y", 10).trim().contains("Y");
    }
}
