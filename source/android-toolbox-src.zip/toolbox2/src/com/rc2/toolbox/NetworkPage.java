package com.rc2.toolbox;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 网络工具页：连接信息/测速/Ping/端口/IP 配置 */
public class NetworkPage {

    private static Context ctx;
    private static LinearLayout infoCard;
    private static TextView resultText;

    public static View build(Context c, MainActivity host) {
        ctx = c;
        LinearLayout page = UI.page(c);

        infoCard = UI.card(c);
        infoCard.addView(UI.sectionTitle(c, "连接信息"));
        page.addView(infoCard);

        LinearLayout toolCard = UI.card(c);
        toolCard.addView(UI.sectionTitle(c, "网络诊断"));
        LinearLayout r1 = UI.buttonRow(c, UI.button2(c, "Ping 网关"), UI.button2(c, "DNS 查询"));
        toolCard.addView(r1);
        UI.space(c, toolCard, 6);
        LinearLayout r2 = UI.buttonRow(c, UI.button2(c, "测速"), UI.button2(c, "刷新"));
        toolCard.addView(r2);
        page.addView(toolCard);

        LinearLayout resCard = UI.card(c);
        resCard.addView(UI.sectionTitle(c, "结果"));
        resultText = new TextView(c);
        resultText.setTextSize(11);
        resultText.setTextColor(UI.TEXT);
        resultText.setLineSpacing(0, 1.15f);
        resultText.setPadding(0, UI.dp(3), 0, 0);
        resultText.setText("点上方按钮开始检测…");
        resCard.addView(resultText);
        page.addView(resCard);

        ((TextView) r1.getChildAt(0)).setOnClickListener(v -> runCmd(host, "ping -c 4 -W 2 $(ip route | grep default | awk '{print $3}' | head -1) 2>&1"));
        ((TextView) r1.getChildAt(1)).setOnClickListener(v -> runCmd(host, "getprop | grep -iE 'dns' | head -6"));
        ((TextView) r2.getChildAt(0)).setOnClickListener(v -> runCmd(host, "ping -c 3 -W 2 8.8.8.8 2>&1"));
        ((TextView) r2.getChildAt(1)).setOnClickListener(v -> { refresh(); host.toast("已刷新"); });

        refresh();
        return UI.scroll(c, page);
    }

    private static void runCmd(MainActivity host, final String cmd) {
        if (resultText != null) resultText.setText("执行中…");
        host.runBg(() -> {
            RootShell.Result r = RootShell.exec(cmd, 25);
            final String out = r.trim().isEmpty() ? "（无输出）" : r.trim();
            if (resultText != null) {
                resultText.post(() -> {
                    resultText.setText(out.length() > 1200 ? out.substring(0, 1200) + "\n...(截断)" : out);
                });
            }
        });
    }

    private static void refresh() {
        if (ctx == null || infoCard == null) return;
        int keep = infoCard.getChildCount() > 0 ? 1 : 0;
        if (infoCard.getChildCount() > keep) infoCard.removeViews(keep, infoCard.getChildCount() - keep);

        String ip = RootShell.exec("ip addr show wlan0 2>/dev/null | grep 'inet ' | head -1", 12).trim();
        String[] p = SysFile.splitWs(ip);
        infoCard.addView(UI.kvRow(ctx, "WiFi IP", p.length >= 2 ? p[1] : "-", UI.ACCENT));

        // 网关：从 ip route 里找 default 行的第三段
        String route = RootShell.exec("ip route 2>/dev/null", 12).trim();
        String gw = "-";
        for (String line : route.split("\n")) {
            if (line.startsWith("default")) {
                String[] q = SysFile.splitWs(line);
                if (q.length >= 3) { gw = q[2]; break; }
            }
        }
        infoCard.addView(UI.kvRow(ctx, "网关", gw, UI.TEXT_DIM));

        // DNS：优先 net.dns1，再读 resolve 属性
        String dns = RootShell.exec("getprop net.dns1 2>/dev/null", 8).trim();
        if (dns.isEmpty()) {
            dns = RootShell.exec("getprop | grep -m1 'dns1'", 8).trim();
            if (dns.contains("[")) {
                int a = dns.indexOf('[');
                int b = dns.lastIndexOf(']');
                if (b > a) dns = dns.substring(a + 1, b).trim();
            }
        }
        infoCard.addView(UI.kvRow(ctx, "DNS", dns.isEmpty() ? "-" : dns, UI.TEXT_DIM));

        // SSID：从 cmd wifi status 或 dumpsys 找
        String ssid = "-";
        String w = RootShell.exec("cmd wifi status 2>/dev/null | head -3", 15).trim();
        if (w.contains("SSID:")) {
            int i = w.indexOf("SSID:");
            String rest = w.substring(i + 5).trim();
            int nl = rest.indexOf('\n');
            ssid = (nl > 0 ? rest.substring(0, nl) : rest).replace(",", "").trim();
        }
        if (ssid.equals("-") || ssid.isEmpty()) {
            String g = RootShell.exec("getprop | grep -m1 'wifi.interface'", 8).trim();
            ssid = g.isEmpty() ? "-" : "已连接";
        }
        infoCard.addView(UI.kvRow(ctx, "SSID", ssid, UI.OK));

        // 信号强度
        String sig = RootShell.exec("cmd wifi status 2>/dev/null | grep -m1 RSSI", 15).trim();
        infoCard.addView(UI.kvRow(ctx, "信号", sig.isEmpty() ? "-" : sig.replace(",", ""), UI.ACCENT2));

        String usb = RootShell.exec("getprop sys.usb.config", 8).trim();
        infoCard.addView(UI.kvRow(ctx, "USB", usb.isEmpty() ? "-" : usb, UI.TEXT_DIM));

        // 新增：WiFi 状态 + 主机名
        String wstate = RootShell.exec("getprop dhcp.wlan0.ipaddress 2>/dev/null", 8).trim();
        infoCard.addView(UI.kvRow(ctx, "DHCP IP", wstate.isEmpty() ? "-" : wstate, UI.TEXT_DIM));
        infoCard.addView(UI.kvRow(ctx, "主机名",
                RootShell.exec("getprop net.hostname 2>/dev/null", 8).trim(), UI.TEXT_DIM));
    }
}
