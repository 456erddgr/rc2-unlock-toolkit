package com.rc2.toolbox;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 首次启动强制同意页（用户要求 2026-10-31）。
 *
 * 要求：写上风险提示、作者「软糖布丁」、本软件风险；
 *       必须同意全部条款才能用；同意一次永久记住，不再询问。
 */
public class AgreementPage {

    public static final String PREF = "rc2_agree";
    public static final String KEY_AGREED = "agreed";
    public static final String KEY_AGREED_AT = "agreed_at";
    public static final String AUTHOR = "软糖布丁";
    public static final String APP_NAME = "RC2 工具箱";

    public static boolean hasAgreed(Context c) {
        return prefs(c).getBoolean(KEY_AGREED, false);
    }

    public static void setAgreed(Context c) {
        prefs(c).edit()
                .putBoolean(KEY_AGREED, true)
                .putLong(KEY_AGREED_AT, System.currentTimeMillis())
                .apply();
    }

    public static long agreedAt(Context c) {
        return prefs(c).getLong(KEY_AGREED_AT, 0L);
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    /** 条款正文（逐条写清，不美化风险） */
    public static final String[] TERMS = {
            "【一、本软件是什么】",
            "RC2 工具箱是给 DJI RC2 遥控器（rc331 / Android 11）用的自制工具，"
                    + "作者：软糖布丁。它依赖 root 权限直接读写系统参数，"
                    + "属于「玩机工具」，不是大疆官方软件，也未获得大疆任何授权或认可。",

            "【二、必须知道的风险：可能导致设备损坏】",
            "1. 本软件会修改 CPU/GPU 频率、温控、虚拟内存（swap/zram）、"
                    + "开机动画、系统属性等深度参数。参数不当可能造成："
                    + "设备过热、卡死、自动重启、电池加速老化。",
            "2. 刷入 Magisk 模块或修改开机动画后，若模块异常，"
                    + "可能出现开机卡死、黑屏、无法进入系统（俗称变砖）。",
            "3. 屏幕背光由 pwmchip0 控制，误操作可能导致黑屏。"
                    + "作者已在程序里做限制，但无法保证 100% 避免。",
            "4. 以上任何一种情况都可能需要重新刷机才能恢复，"
                    + "严重时可能丢失设备内全部数据。",

            "【三、数据与保修】",
            "1. 修改系统分区、刷入模块、解锁 Bootloader 通常会使官方保修失效。",
            "2. 作者不对任何数据丢失、设备损坏、保修失效承担责任。",
            "3. 请务必在操作前自行备份重要数据。",

            "【四、使用前提】",
            "1. 你已了解 root、Magisk、fastboot 的基本概念，知道自己在做什么。",
            "2. 你自愿承担因使用本软件产生的一切后果。",
            "3. 如果你是新手、或这台设备是唯一的生产工具，请勿使用本软件。",

            "【五、同意方式】",
            "点下方「我已阅读并同意全部条款」后即可正常使用，"
                    + "该同意会被永久保存，以后打开不再询问。",
            "如果你不同意，请直接退出并卸载本软件。"
    };

    public static View build(Context c, final MainActivity host) {
        LinearLayout page = UI.page(c);
        page.setGravity(Gravity.TOP);

        LinearLayout head = UI.card(c);
        head.addView(UI.title(c, APP_NAME));
        TextView sub = UI.text(c, "作者：" + AUTHOR + "   ·   版本 v" + host.versionName(),
                UI.ACCENT2, 13);
        sub.setPadding(0, UI.dp(4), 0, 0);
        head.addView(sub);
        TextView warn = UI.text(c, "⚠ 使用前必读：本软件会修改系统深层参数，可能导致设备损坏",
                UI.DANGER, 13);
        warn.setPadding(0, UI.dp(8), 0, 0);
        warn.setLineSpacing(0, 1.25f);
        head.addView(warn);
        page.addView(head);

        LinearLayout body = UI.card(c);
        body.addView(UI.sectionTitle(c, "使用条款与风险提示"));
        for (String t : TERMS) {
            TextView tv = new TextView(c);
            tv.setText(t);
            boolean isHead = t.startsWith("【");
            tv.setTextSize(isHead ? 14 : 12.5f);
            tv.setTextColor(isHead ? UI.ACCENT : UI.TEXT);
            if (isHead) tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            tv.setLineSpacing(0, 1.35f);
            tv.setPadding(0, UI.dp(isHead ? 10 : 3), 0, UI.dp(2));
            body.addView(tv);
        }
        page.addView(body);

        LinearLayout actCard = UI.card(c);
        TextView agreeBtn = UI.button(c, "我已阅读并同意全部条款", UI.OK);
        agreeBtn.setTextSize(15);
        actCard.addView(agreeBtn);
        actCard.addView(UI.dim(c, "点一次即永久生效，以后打开不再询问。\n"
                + "不同意的，请直接退出并卸载。"));
        page.addView(actCard);

        agreeBtn.setOnClickListener(v -> {
            setAgreed(c);
            host.toast("已同意，欢迎使用");
            host.rebuildUi();
        });

        ScrollView sv = new ScrollView(c);
        sv.setFillViewport(true);
        sv.addView(page);
        return sv;
    }
}
