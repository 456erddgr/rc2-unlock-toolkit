package com.rc2.toolbox;

/** zram 压缩内存管理：扩容 / 换算法 / 状态
 * 实测：zram 可从 1.5GB 扩到 4GB（disksize 写入），SwapTotal 随之变化。
 * 注意：扩容必须 swapoff → reset → 写 disksize → mkswap → swapon
 */
public class ZramManager {

    public static final String ZRAM = "/dev/block/zram0";

    /** 当前 zram 逻辑容量（MB） */
    public static long currentSizeMb() {
        return SysFile.readLong("/sys/block/zram0/disksize") / 1048576L;
    }

    /** 是否正在使用 */
    public static boolean isActive() {
        String o = RootShell.exec("grep zram /proc/swaps 2>/dev/null | head -1", 15).trim();
        return o.contains("zram");
    }

    /** 当前压缩算法 */
    public static String algo() {
        String s = SysFile.readLine("/sys/block/zram0/comp_algorithm");
        for (String p : SysFile.splitWs(s)) {
            if (p.startsWith("[")) return p.replace("[", "").replace("]", "");
        }
        return "";
    }

    /** 可用算法列表 */
    public static String[] algos() {
        String s = SysFile.readLine("/sys/block/zram0/comp_algorithm").trim();
        if (s.isEmpty()) return new String[0];
        String[] p = SysFile.splitWs(s);
        String[] r = new String[p.length];
        for (int i = 0; i < p.length; i++) r[i] = p[i].replace("[", "").replace("]", "");
        return r;
    }

    /**
     * 扩容 / 改容量（MB）。这是慢操作（约 2-10 秒）。
     * 流程：swapoff → reset → disksize → mkswap → swapon -p 32758
     */
    public static boolean resize(int sizeMb, int priority) {
        if (sizeMb < 256) sizeMb = 256;
        long bytes = (long) sizeMb * 1048576L;
        String cmd =
            "/system/bin/swapoff " + ZRAM + " 2>/dev/null; sleep 1; "
          + "echo 1 > /sys/block/zram0/reset 2>/dev/null || true; sleep 1; "
          + "echo " + bytes + " > /sys/block/zram0/disksize 2>/dev/null; "
          + "RC1=$?; "
          + "mkswap " + ZRAM + " 2>/dev/null; "
          + "/system/bin/swapon -p " + priority + " " + ZRAM + " 2>/dev/null; "
          + "echo DONE_$RC1; "
          + "cat /proc/swaps";
        RootShell.Result r = RootShell.exec(cmd, 120);
        boolean ok = r.trim().contains("DONE_0") && isActive();
        android.util.Log.i("RC2Toolbox", "zram resize " + sizeMb + "MB -> " + ok
                + " 实际=" + currentSizeMb() + "MB");
        return ok;
    }

    /** 切换压缩算法（需 zram 空闲时才成功） */
    public static boolean setAlgo(String algo) {
        if (algo == null || algo.isEmpty()) return false;
        RootShell.exec("echo " + algo + " > /sys/block/zram0/comp_algorithm 2>/dev/null", 20);
        return algo().equals(algo);
    }

    /** zram 原始数据 / 压缩后 / 占用内存（KB） */
    public static long[] mmStat() {
        String s = SysFile.readLine("/sys/block/zram0/mm_stat").trim();
        String[] p = SysFile.splitWs(s);
        long[] r = new long[4];
        for (int i = 0; i < 4 && i < p.length; i++) r[i] = SysFile.parseLong(p[i]);
        // r[0]=origBytes, r[1]=compBytes, r[2]=memUsedBytes
        for (int i = 0; i < 3; i++) r[i] = r[i] / 1024;
        return r;
    }

    /** 压缩比 */
    public static String ratio() {
        long[] s = mmStat();
        if (s[1] <= 0) return "-";
        return String.format("%.1f:1", (double) s[0] / s[1]);
    }
}
