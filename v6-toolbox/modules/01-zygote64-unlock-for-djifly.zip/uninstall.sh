#!/system/bin/sh
# ============================================================
# uninstall.sh — 卸载模块时恢复原状
#
# 恢复 persist.dji.zygote_policy = 4（出厂值），
# 让下次开机回到纯 32 位运行时（原始状态）。
# ============================================================

LOG=/data/local/tmp/rc2_zygote64.log
RP=/debug_ramdisk/resetprop

echo "$(date '+%H:%M:%S') === uninstall.sh 开始 ===" >> "$LOG"

if [ -x "$RP" ]; then
    "$RP" -n persist.dji.zygote_policy 4
else
    setprop persist.dji.zygote_policy 4
fi

echo "$(date '+%H:%M:%S') 已恢复 policy=[$(getprop persist.dji.zygote_policy)]" >> "$LOG"
echo "$(date '+%H:%M:%S') 重启后回到出厂纯32位状态 ===" >> "$LOG"

exit 0
