#!/system/bin/sh
# ============================================================
# service.sh — 开机后期（late_start），用于兜底与状态确认
#
# post-fs-data.sh 已把 policy 设为 3，理论上两个 zygote 都会留下。
# 但为防万一（例如 init 在别处又把它设回 4），这里做一次确认 +
# 兜底拉起，并记录最终状态。
#
# 铁律：只用即时命令 + 固定 sleep，绝不用 while/until 循环。
# ============================================================

MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_zygote64.log
RP=/debug_ramdisk/resetprop

log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }

# 等系统把 zygote 都起来（固定等待，不循环）
sleep 90

log "=== service.sh 检查 ==="
log "policy=[$(getprop persist.dji.zygote_policy)]"
log "zygote=[$(getprop init.svc.zygote)]"
log "zygote_secondary=[$(getprop init.svc.zygote_secondary)]"

# 兜底 1：如果 policy 被改回去了，再设一次
CUR=$(getprop persist.dji.zygote_policy)
if [ "$CUR" != "3" ]; then
    log "policy 不是 3（当前 $CUR），重新设置为 3"
    if [ -x "$RP" ]; then
        "$RP" -n persist.dji.zygote_policy 3
    else
        setprop persist.dji.zygote_policy 3
    fi
fi

# 兜底 2：如果 64 位 zygote 没在跑，主动拉起
if [ "$(getprop init.svc.zygote)" != "running" ]; then
    log "64位 zygote 未运行，执行 ctl.start zygote"
    setprop ctl.start zygote
    sleep 5
    log "拉起后 zygote=[$(getprop init.svc.zygote)]"
fi

# 最终状态
log "最终 policy=[$(getprop persist.dji.zygote_policy)]"
log "最终 zygote=[$(getprop init.svc.zygote)]"
log "最终 zygote_secondary=[$(getprop init.svc.zygote_secondary)]"
log "socket: $(ls /dev/socket/ | grep zygote | tr '\n' ' ')"
log "=== service.sh 结束 ==="
exit 0
