#!/system/bin/sh
# ============================================================
# post-fs-data.sh — 开机最早期阶段
#
# 作用：把 persist.dji.zygote_policy 从 4 改成 3。
#
# 为什么是 3：
#   /system/etc/init/hw/init.rc 只有两条规则：
#     on property:...zygote_policy=2  ->  stop zygote_secondary   (只留 64 位)
#     on property:...zygote_policy=4  ->  stop zygote             (只留 32 位)
#   值 = 3 时两条规则都不匹配，两个 zygote 都会正常启动并保留。
#
# 为什么在 post-fs-data：
#   必须在 sys.boot_completed=1 之前改掉，否则 init 已经按 4 把 64 位停掉了。
#
# 安全约定（项目踩过的坑）：
#   * 绝不在 post-fs-data 里做 while/until 等待（会卡死开机）
#   * 全部即时命令
#   * 任何失败只写日志，绝不 exit 非 0
# ============================================================

MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_zygote64.log
RP=/debug_ramdisk/resetprop

log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }

log "=== post-fs-data 启动 ==="
log "原值=[$(getprop persist.dji.zygote_policy)]"

if [ -x "$RP" ]; then
    # -n 表示不写入持久存储，只在当前系统实例生效，重启后由本模块再次设置
    "$RP" -n persist.dji.zygote_policy 3
    log "resetprop 已执行，新值=[$(getprop persist.dji.zygote_policy)]"
else
    log "resetprop 不存在于 $RP，改用 setprop"
    setprop persist.dji.zygote_policy 3
    log "setprop 已执行，新值=[$(getprop persist.dji.zygote_policy)]"
fi

log "=== post-fs-data 结束 ==="
exit 0
