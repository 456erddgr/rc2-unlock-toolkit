#!/system/bin/sh
# ============================================================
# custom.sh — 手动管理工具
# 用法：sh custom.sh status|on|off|install <apk路径>
# ============================================================

RP=/debug_ramdisk/resetprop

case "$1" in
  status)
    echo "=== 当前状态 ==="
    echo "policy           = $(getprop persist.dji.zygote_policy)"
    echo "64位 zygote      = $(getprop init.svc.zygote)"
    echo "32位 zygote      = $(getprop init.svc.zygote_secondary)"
    echo "socket           = $(ls /dev/socket/ | grep zygote | tr '\n' ' ')"
    echo "--- 64位进程数 ---"
    echo "app_process64    = $(ps -A | grep -c app_process64)"
    ;;
  on)
    echo "启用 64 位运行时..."
    "$RP" -n persist.dji.zygote_policy 3
    setprop ctl.start zygote
    sleep 3
    echo "policy=$(getprop persist.dji.zygote_policy) zygote=$(getprop init.svc.zygote)"
    echo "注意：这里是临时生效，重启后由模块自动恢复"
    ;;
  off)
    echo "关闭 64 位运行时（回到纯32位）..."
    setprop ctl.stop zygote
    "$RP" -n persist.dji.zygote_policy 4
    sleep 2
    echo "policy=$(getprop persist.dji.zygote_policy) zygote=$(getprop init.svc.zygote)"
    ;;
  install)
    if [ -z "$2" ]; then echo "用法: sh custom.sh install <apk路径>"; exit 1; fi
    echo "安装 $2 （自动尝试 arm64-v8a）..."
    pm install -r --abi arm64-v8a "$2"
    ;;
  *)
    echo "用法: sh custom.sh status|on|off|install <apk路径>"
    ;;
esac
exit 0
