#!/system/bin/sh
# ============================================================
# post-fs-data.sh — 安装载荷到 /data (不碰 /dji_apk)
#
# 为什么放这里:
#   post-fs-data 阶段 /data 已挂载 (fstab 里 metadata/userdata 是 first_stage_mount,
#   在 post-fs-data 之前就挂好了), 所以 /data 路径可靠。
#
# 上次失败的教训:
#   上次等 /data/adb/magisk/resetprop —— 那是 Magisk 的解压目录, 在这个阶段
#   可能还没就绪。这次只用 /data 自身, 且不做任何等待。
#
# 本脚本只做"复制文件", 不启动任何进程, 不修改属性。
# 真正的启动在 service.sh。
# ============================================================

MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_adbd_root.log

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

log "=== post-fs-data: 开始安装载荷 ==="

PERSIST=/data/adb-persist
mkdir -p "$PERSIST" 2>>"$LOG"
chown 0:0 "$PERSIST" 2>>"$LOG"
chmod 0700 "$PERSIST" 2>>"$LOG"

# 载荷放在模块目录的 payload/ 下
SRC="$MODDIR/payload"

if [ ! -d "$SRC" ]; then
    log "错误: 模块内 payload 目录不存在: $SRC"
    exit 0
fi

for f in adbd-root start-root-adbd.sh injected-start-root-adbd.sh; do
    if [ -f "$SRC/$f" ]; then
        cp -f "$SRC/$f" "$PERSIST/$f" 2>>"$LOG"
        chown 0:0 "$PERSIST/$f" 2>>"$LOG"
        chmod 0755 "$PERSIST/$f" 2>>"$LOG"
        log "已安装: $f -> $PERSIST/$f"
    else
        log "缺失: $SRC/$f"
    fi
done

# 清理上一次的标记文件, 避免状态混乱
rm -f "$PERSIST/disable-custom-adbd" "$PERSIST/root-adbd-ready" "$PERSIST/root-adbd.pid" 2>>"$LOG"

log "=== post-fs-data: 完成 ==="
exit 0
