#!/system/bin/sh
# ============================================================
# uninstall.sh — 恢复系统 adbd
# ============================================================

LOG=/data/local/tmp/rc2_adbd_root.log
PERSIST=/data/adb-persist

echo "$(date '+%Y-%m-%d %H:%M:%S') [uninstall] 开始恢复" >> "$LOG"

# 杀掉 adbd-root
for P in $(/system/bin/busybox pidof adbd-root 2>/dev/null); do
    kill -9 "$P" 2>/dev/null
done

# 清理属性
setprop service.adb.tcp.port "" 2>/dev/null
setprop service.adb.listen_addrs "" 2>/dev/null
setprop service.adb.root 0 2>/dev/null

# 重启系统 adbd
setprop ctl.start adbd 2>/dev/null

# 清理文件
rm -f "$PERSIST/adbd-root" "$PERSIST/start-root-adbd.sh" "$PERSIST/injected-start-root-adbd.sh" 2>/dev/null
rm -f "$PERSIST/root-adbd-ready" "$PERSIST/root-adbd.pid" 2>/dev/null

echo "$(date '+%Y-%m-%d %H:%M:%S') [uninstall] 完成" >> "$LOG"

exit 0
