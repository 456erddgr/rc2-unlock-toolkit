#!/system/bin/sh
# ============================================================
# service.sh — 启动 adbd-root 替换系统 adbd
#
# 原理 (逆向自原版 RC331Setup 工具的 injected-start-root-adbd.sh):
#   1. 停掉系统 adbd:  setprop ctl.stop adbd
#   2. 用 setsid 拉起 adbd-root, 并指定 seclabel u:r:su:s0
#   3. adbd-root 以 root 身份监听, adb 变 root
#
# 与原版的差异:
#   原版靠 am attach-agent system 注入 system_server 来获得完整 capability。
#   本模块直接由 Magisk service.sh 执行 —— Magisk 本身就提供 root + 完整 capability,
#   因此不需要那套注入链。这样避开了 cap_ptrace_injector 和 SELinux 依赖。
#
# 安全设计:
#   * 无 while 循环, 全部即时命令 + 固定 sleep
#   * 后台执行, 不阻塞开机
#   * 失败只写日志
#   * 保留 60 秒窗口: 若 adbd-root 起不来, 自动回滚启动系统 adbd
# ============================================================

MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_adbd_root.log
PERSIST=/data/adb-persist
ADBDBIN=$PERSIST/adbd-root

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"
}

log "=== service.sh 开始 ==="

if [ ! -x "$ADBDBIN" ]; then
    log "adbd-root 不存在或不可执行: $ADBDBIN — 放弃"
    exit 0
fi

log "adbd-root 存在: $ADBDBIN"
log "当前 init.svc.adbd=[$(getprop init.svc.adbd)]"
log "当前 service.adb.root=[$(getprop service.adb.root)]"

# 后台执行, 不阻塞开机
(
    # 等系统服务稳定
    sleep 45

    log "[后台] 开始替换 adbd"

    # 记下原 adbd 的 ? 便于回滚
    setprop service.adb.tcp.port 5555 2>>"$LOG"
    setprop service.adb.listen_addrs "" 2>>"$LOG"

    # 停止系统 adbd
    setprop ctl.stop adbd 2>>"$LOG"
    sleep 3
    log "[后台] 停掉系统 adbd 后 init.svc.adbd=[$(getprop init.svc.adbd)]"

    # 启动 adbd-root
    # LD_LIBRARY_PATH 指向系统 adbd 的库目录 (adbd-root 依赖这些库)
    export LD_LIBRARY_PATH=/apex/com.android.adbd/lib64
    setsid "$ADBDBIN" --root_seclabel=u:r:su:s0 </dev/null >> "$LOG" 2>&1 &
    log "[后台] 已拉起 adbd-root, 等待 5 秒"

    sleep 5

    # 检查是否起来了
    PID=""
    if [ -x /system/bin/pidof ]; then
        PID=$(/system/bin/pidof adbd-root 2>/dev/null)
    fi
    if [ -z "$PID" ] && [ -x /system/bin/busybox ]; then
        PID=$(/system/bin/busybox pidof adbd-root 2>/dev/null)
    fi

    if [ -n "$PID" ]; then
        log "[后台] adbd-root 已运行 PID=$PID"
        if [ -r "/proc/$PID/status" ]; then
            grep -E '^(CapEff|Uid):' "/proc/$PID/status" >> "$LOG" 2>&1
        fi
        echo "$PID" > "$PERSIST/root-adbd.pid" 2>>"$LOG"
        touch "$PERSIST/root-adbd-ready" 2>>"$LOG"
        log "[后台] 成功, adb 应为 root"
    else
        log "[后台] adbd-root 未能启动, 回滚到系统 adbd"
        setprop service.adb.tcp.port "" 2>>"$LOG"
        setprop service.adb.listen_addrs "" 2>>"$LOG"
        setprop ctl.start adbd 2>>"$LOG"
        log "[后台] 已回滚"
    fi

    log "[后台] 完成"
) &

log "=== service.sh 退出, 后台任务已启动 ==="
exit 0
