#!/system/bin/sh
# RC2 内存扩展增强
#
# 作用：
#  1) 提高 dalvik 堆上限（让 App 能用更多内存）
#  2) 确保 zram 优先级高于磁盘 swap（快路径优先）
#  3) 设置合理 swappiness
#
# 说明：物理内存 MemTotal 改不了（内核硬件值），
#       但可以扩大可用的虚拟内存池和单应用堆上限。

MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_memexp.log
RP=/debug_ramdisk/resetprop

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

log "=== rc2_memexp 启动 ==="
sleep 20

# 1) 提高 dalvik 堆上限（256m→512m, 192m→384m）
if [ -x "$RP" ]; then
    "$RP" -n dalvik.vm.heapsize 512m 2>/dev/null
    "$RP" -n dalvik.vm.heapgrowthlimit 384m 2>/dev/null
    "$RP" -n dalvik.vm.heapstartsize 32m 2>/dev/null
    log "dalvik heapsize=$(getprop dalvik.vm.heapsize) growth=$(getprop dalvik.vm.heapgrowthlimit)"
else
    setprop dalvik.vm.heapsize 512m
    setprop dalvik.vm.heapgrowthlimit 384m
    log "setprop 已设置"
fi

# 2) swappiness：60 平衡（太积极伤闪存，太低会吃光真实内存）
echo 60 > /proc/sys/vm/swappiness 2>/dev/null
log "swappiness=$(cat /proc/sys/vm/swappiness)"

# 3) 确保 zram 起在磁盘 swap 之前且优先级更高
if ! grep -q zram /proc/swaps 2>/dev/null; then
    if [ -e /dev/block/zram0 ]; then
        /system/bin/swapon -p 32758 /dev/block/zram0 2>/dev/null
        log "zram 已启用"
    fi
fi

log "swap 状态: $(cat /proc/swaps 2>/dev/null | tail -n +2 | tr '\n' ' ')"
log "内存: $(grep MemAvailable /proc/meminfo 2>/dev/null)"
log "=== 完成 ==="
exit 0
