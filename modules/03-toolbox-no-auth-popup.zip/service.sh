#!/system/bin/sh
# RC2 全能授权模块 —— 开机自动授权工具箱 su
#
# 作用：
#   1) 把 com.rc2.toolbox 加入 Magisk 授权白名单（policy=2 ALLOW），永不弹窗
#   2) 安装当前包名对应的 uid（每次重装 uid 会变，所以要动态查）
#   3) 把 su 软链到 /system/bin/su，让 PATH 里能找到（工具箱已用绝对路径，双保险）
#   4) 记录日志到 /data/local/tmp/rc2_autogrant.log
#
# 铁律：只用即时命令 + 固定 sleep，绝不 while/until 等待
MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_autogrant.log
MAGISK=/debug_ramdisk/magisk

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG"; }

log "=== rc2_autogrant 启动 ==="

# 等系统稳定（固定等待）
sleep 45

# 1) 动态查工具箱当前 uid
UID_LINE=$(dumpsys package com.rc2.toolbox 2>/dev/null | grep -m1 "userId=")
UID_NUM=$(echo "$UID_LINE" | tr -d ' ' | cut -d'=' -f2)
log "工具箱 uid=[$UID_NUM]"

if [ -n "$UID_NUM" ]; then
    # 授权 ALLOW(2)，until=0 永久，logging+notification 开
    $MAGISK --sqlite "INSERT OR REPLACE INTO policies (uid,policy,until,logging,notification) VALUES ($UID_NUM,2,0,1,0);" 2>&1
    log "已授权 uid=$UID_NUM"
    # 验证
    POL=$($MAGISK --sqlite "SELECT policy FROM policies WHERE uid=$UID_NUM;" 2>/dev/null)
    log "验证 policy=[$POL]"
else
    log "未找到 com.rc2.toolbox，跳过授权（等安装后下次开机生效）"
fi

# 2) 同时保底授权旧的可能 uid（重装前遗留）
for U in 10040 10041 10042 10043 10044 10045; do
    $MAGISK --sqlite "INSERT OR IGNORE INTO policies (uid,policy,until,logging,notification) VALUES ($U,2,0,1,0);" 2>/dev/null
done
log "已知 uid 批量授权完成"

# 3) 让 su 进 PATH（工具箱用绝对路径，这只是双保险）
if [ ! -e /system/bin/su ]; then
    ln -sf /debug_ramdisk/su /system/bin/su 2>/dev/null
    log "已创建 /system/bin/su 软链"
fi

# 4) 确认 adb 通道可用（无 root 时工具箱走 adb）
ADB_STATE=$(getprop sys.usb.config 2>/dev/null)
log "adb 通道 usb.config=[$ADB_STATE]"

# 5) 确认工具箱已安装
if pm list packages 2>/dev/null | grep -q com.rc2.toolbox; then
    log "工具箱已安装 ✓"
else
    log "工具箱未安装"
fi

log "=== rc2_autogrant 完成 ==="
log "当前 policies:"
$MAGISK --sqlite "SELECT uid,policy FROM policies;" >> "$LOG" 2>&1

exit 0
