#!/system/bin/sh
# 卸载时清理软链（授权记录保留，用户可手动在 Magisk 里撤销）
rm -f /system/bin/su 2>/dev/null
echo "rc2_autogrant 已卸载" > /data/local/tmp/rc2_autogrant.log
exit 0
