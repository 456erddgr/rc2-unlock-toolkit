#!/system/bin/sh
# 卸载时清理 swap 文件，释放 /data 空间
SWAPFILE=/data/local/rc2_swapfile
LOG=/data/local/tmp/rc2_swap.log

echo "$(date '+%H:%M:%S') === uninstall 开始 ===" >> "$LOG"

if grep -q "$SWAPFILE" /proc/swaps 2>/dev/null; then
    swapoff "$SWAPFILE" 2>/dev/null
    echo "$(date '+%H:%M:%S') 已 swapoff" >> "$LOG"
fi

rm -f "$SWAPFILE"
echo "$(date '+%H:%M:%S') 已删除 swap 文件" >> "$LOG"

exit 0
