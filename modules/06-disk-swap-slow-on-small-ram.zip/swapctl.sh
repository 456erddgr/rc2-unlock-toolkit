#!/system/bin/sh
# ============================================================
# swapctl.sh — 磁盘 swap 管理工具（v2.1，2026-10-31）
#
# 用法:
#   sh swapctl.sh status          查看状态
#   sh swapctl.sh on              启用 swap
#   sh swapctl.sh off             关闭 swap（释放 /data 空间）
#   sh swapctl.sh resize <MB>     重新设定容量（先 off 再 on）
#   sh swapctl.sh swappiness <n>  调整换出倾向 (0-200)
#
# v2.1：swapon/swapoff 用绝对路径 /system/bin/（toybox 支持 -p，
#      BusyBox 版不支持 → 开机必失败）；do_on 按大小校验（expr 64 位）；
#     swapon 错误捕获 + 有界重试。
# ============================================================
MODDIR=${0%/*}
SWAPFILE=/data/local/rc2_swapfile
LOGFILE=/data/local/tmp/rc2_swap.log
SIZE_MB=$(cat "$MODDIR/size_mb" 2>/dev/null | tr -d ' \r\n')
[ -z "$SIZE_MB" ] && SIZE_MB=2048
PRIORITY=32767

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOGFILE"; }

do_on() {
    if grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
        echo "swap 已在运行"
        return 0
    fi
    # 大小校验（expr 64 位，规避 32 位溢出）
    WANT_B=$(expr "$SIZE_MB" '*' 1048576)
    CUR_B=$(stat -c %s "$SWAPFILE" 2>/dev/null || echo 0)
    if [ "$CUR_B" != "$WANT_B" ]; then
        echo "重建 swap 文件 ${SIZE_MB}MB（现有 ${CUR_B}B）..."
        rm -f "$SWAPFILE"
        # 分块 dd + sync（f2fs 上 fallocate 后 swapon 报 Invalid argument；
        # 一次性 dd 2GB 挤爆内存 → watchdog 重启）
        BLK=256; N=$((SIZE_MB / BLK)); R=$((SIZE_MB % BLK))
        if [ "$R" -gt 0 ]; then N=$((N + 1)); fi
        dd if=/dev/zero of="$SWAPFILE" bs=${BLK}M count=1 2>/dev/null
        sync
        i=2
        while [ "$i" -le "$N" ]; do
            dd if=/dev/zero of="$SWAPFILE" bs=${BLK}M count=1 conv=notrunc seek=$((i-1)) 2>/dev/null
            sync
            i=$((i+1))
        done
        if [ ! -s "$SWAPFILE" ]; then
            echo "创建失败"
            return 1
        fi
        mkswap "$SWAPFILE" >/dev/null 2>&1
    fi
    OK=0
    for try in 1 2 3; do
        ERR=$(/system/bin/swapon -p "$PRIORITY" "$SWAPFILE" 2>&1)
        if grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
            OK=1
            break
        fi
        [ "$try" -lt 3 ] && { echo "swapon 尝试 $try 失败: $ERR"; sleep 5; }
    done
    if [ "$OK" = "1" ]; then
        echo "swap 已启用: ${SIZE_MB}MB, 优先级 $PRIORITY"
        log "启用 swap ${SIZE_MB}MB"
    else
        echo "启用失败: $ERR"
        log "启用失败: $ERR"
    fi
}

do_off() {
    if ! grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
        echo "swap 未在运行"
    else
        /system/bin/swapoff "$SWAPFILE" 2>&1
        echo "swap 已关闭"
        log "关闭 swap"
    fi
    rm -f "$SWAPFILE"
    echo "已释放 /data 空间"
}

case "$1" in
  status)
    echo "=== 内存 ==="
    grep -E 'MemTotal|MemAvailable' /proc/meminfo | sed 's/^/  /'
    echo "=== Swap 设备 ==="
    cat /proc/swaps | sed 's/^/  /'
    echo "=== 配置 ==="
    echo "  容量      = ${SIZE_MB} MB"
    echo "  文件      = $SWAPFILE"
    echo "  文件存在  = $([ -f "$SWAPFILE" ] && echo 是 || echo 否)"
    echo "  swappiness= $(cat /proc/sys/vm/swappiness)"
    SZ=$(stat -c %s "$SWAPFILE" 2>/dev/null)
    [ -n "$SZ" ] && echo "  实际大小  = $(expr "$SZ" / 1048576) MB (expr 64 位)"
    ;;
  on)  do_on ;;
  off) do_off ;;
  resize)
    if [ -z "$2" ]; then echo "用法: sh swapctl.sh resize <MB>"; exit 1; fi
    do_off >/dev/null 2>&1
    echo "$2" > "$MODDIR/size_mb"
    SIZE_MB=$2
    echo "容量设为 ${SIZE_MB}MB，正在重建..."
    do_on
    ;;
  swappiness)
    if [ -z "$2" ]; then echo "当前 swappiness = $(cat /proc/sys/vm/swappiness)"; exit 0; fi
    echo "$2" > /proc/sys/vm/swappiness 2>&1 && echo "swappiness 设为 $2" || echo "设置失败（需 root）"
    ;;
  *)
    echo "用法: sh swapctl.sh status|on|off|resize <MB>|swappiness <n>"
    ;;
esac
exit 0
