#!/system/bin/sh
# ============================================================
# service.sh — 开机启用磁盘 swap（v3，2026-10-31 关键修复）
#
# ★★★ v3 核心改动（解决"开机 56 秒后卡死"）★★★
#
# 旧版致命问题：
#   每次开机都"创建 swap 文件"（2046MB 要 89 秒），
#   但设备在 56 秒时就因内存耗尽卡死 —— 永远等不到 swap 建好。
#   而且文件经常是半截（断电/卡死时中断），下次开机又重建，死循环。
#
# v3 方案：**预建文件，开机只做 swapon**
#   1. 文件已存在且大小正确 → 直接 swapon（<1 秒，零内存压力）
#   2. 文件不存在/大小不对 → 不重建！只记录警告，等下批修复
#      （重建必须在系统空闲时由 swapctl.sh resize 手动触发）
#
# 这样开机 swap 在 1 秒内就绪，不会再有内存空窗期。
# ============================================================
MODDIR=${0%/*}
SWAPFILE=/data/local/rc2_swapfile
LOG=/data/local/tmp/rc2_swap.log
PRIORITY=32767

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

log "=== swap service 启动 (v3 · 直接 swapon) ==="

# 尽早启用（不等 60 秒！延迟 8 秒即可，此时系统已把基本服务拉起）
sleep 8

if [ -f "$MODDIR/disable" ]; then
    log "检测到 disable 标记，跳过"
    exit 0
fi

if grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
    log "swap 已在运行，跳过"
    exit 0
fi

# ★ 只做数据校验，不做重建
CUR_B=$(stat -c %s "$SWAPFILE" 2>/dev/null || echo 0)
SIZE_MB=$(cat "$MODDIR/size_mb" 2>/dev/null)
[ -z "$SIZE_MB" ] && SIZE_MB=2046
WANT_B=$(expr "$SIZE_MB" '*' 1048576)

if [ "$CUR_B" != "$WANT_B" ]; then
    log "⚠ 文件大小不符（现有 ${CUR_B}B 期望 ${WANT_B}B），不重建以免卡死"
    log "  如需重建：sh $MODDIR/swapctl.sh resize $SIZE_MB（需断电后空闲时操作）"
    exit 0
fi

# 文件已就绪 → 直接 swapon（1 秒内完成）
ERR=$(/system/bin/swapon -p "$PRIORITY" "$SWAPFILE" 2>&1)
sleep 1

if grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
    log "启用成功 (优先级 $PRIORITY)"
    echo 150 > /proc/sys/vm/swappiness 2>/dev/null
    log "swappiness 设为 150"
else
    log "启用失败: $ERR"
fi

log "=== 完成 ==="
log "swap 状态: $(cat /proc/swaps | tail -n +2 | tr '\n' ' ')"
exit 0
