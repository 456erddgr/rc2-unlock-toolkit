#!/system/bin/sh
# ============================================================
# custom.sh — 手动管理
# 用法: sh custom.sh status|stop|start|enable|disable
# ============================================================

PKG=com.kugou.android.auto
MODDIR=${0%/*}

case "$1" in
  status)
    echo "=== 酷狗状态 ==="
    echo "进程数       = $(ps -A -o NAME 2>/dev/null | grep -c $PKG)"
    echo "启用状态     = $(pm list packages -e 2>/dev/null | grep -q $PKG && echo 已启用 || echo 已禁用)"
    echo "模块停用标记 = $([ -f "$MODDIR/disable" ] && echo 有 || echo 无)"
    echo "--- 最近日志 ---"
    tail -6 /data/local/tmp/rc2_kugou.log 2>/dev/null || echo "(暂无日志)"
    ;;
  stop)
    echo "停止酷狗..."
    am force-stop $PKG
    sleep 2
    echo "进程数 = $(ps -A -o NAME 2>/dev/null | grep -c $PKG)"
    ;;
  start)
    echo "手动启动酷狗..."
    am start -n $PKG/com.kugou.android.auto.ui.activity.SplashPureActivity 2>&1 | tail -1
    sleep 3
    echo "进程数 = $(ps -A -o NAME 2>/dev/null | grep -c $PKG)"
    ;;
  enable)
    echo "恢复酷狗完全正常（下次开机不再压制）..."
    touch "$MODDIR/disable"
    echo "已创建 disable 标记。如需立即撤销本次改动，重启即可。"
    ;;
  disable)
    echo "重新启用压制..."
    rm -f "$MODDIR/disable"
    echo "已移除 disable 标记"
    ;;
  *)
    echo "用法: sh custom.sh status|stop|start|enable|disable"
    ;;
esac
exit 0
