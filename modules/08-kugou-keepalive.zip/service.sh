#!/system/bin/sh
# ============================================================
# service.sh — 开机后压制酷狗音乐自启
#
# 背景（实测结论）:
#   酷狗 com.kugou.android.auto 没有声明 BOOT_COMPLETED，
#   不是被系统开机广播拉起的。
#   真正拉起它的是车机桌面 com.sfcar.launcher ——
#   它把酷狗注册成 MediaButtonReceiver（媒体按键接收者），
#   并在后台预启动其播放服务 KugouPlaybackService。
#
# 方案:
#   用 am force-stop 打断自启链。实测压制后 60 秒未被重新拉起，
#   且手动打开完全正常（force-stop 不改变"启用"状态）。
#
# 为什么不直接 pm disable-user:
#   那会让应用彻底不可用，用户想听歌时还得重新启用。
#   force-stop 只压制后台自启，保留手动打开能力。
#
# 铁律: 只用即时命令 + 固定 sleep，绝不用 while/until（会卡死开机）。
# ============================================================

MODDIR=${0%/*}
LOG=/data/local/tmp/rc2_kugou.log
PKG=com.kugou.android.auto

log() { echo "$(date '+%H:%M:%S') $*" >> "$LOG"; }

log "=== 酷狗压制 service 启动 ==="

# 等系统起完（固定等待，不循环）
sleep 45

# 如果模块被停用（存在 disable 标记），直接退出
[ -f "$MODDIR/disable" ] && { log "模块被停用，退出"; exit 0; }

# 第一次压制：开机后桌面可能已经拉起它
RUNNING=$(ps -A -o NAME 2>/dev/null | grep -c "$PKG")
log "当前酷狗进程数=$RUNNING"

if [ "$RUNNING" -gt 0 ]; then
    log "发现酷狗在跑，执行 force-stop"
    am force-stop "$PKG"
    sleep 3
    RUNNING2=$(ps -A -o NAME 2>/dev/null | grep -c "$PKG")
    log "压制后进程数=$RUNNING2"
else
    log "酷狗未在运行，无需处理"
fi

# 第二次压制：桌面预启动往往有一次延迟拉起的重试
sleep 40
RUNNING3=$(ps -A -o NAME 2>/dev/null | grep -c "$PKG")
if [ "$RUNNING3" -gt 0 ]; then
    log "第二次检查发现又被拉起($RUNNING3)，再压制一次"
    am force-stop "$PKG"
fi

log "=== 结束，最终进程数=$(ps -A -o NAME 2>/dev/null | grep -c "$PKG") ==="
exit 0
