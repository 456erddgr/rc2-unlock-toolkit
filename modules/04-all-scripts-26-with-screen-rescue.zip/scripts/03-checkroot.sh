#!/system/bin/sh
/debug_ramdisk/su -c "id"
/debug_ramdisk/su -c "magisk -v"
getprop init.svc.adbd
