#!/system/bin/sh
# 风扇与温度状态
echo "--- 风扇驱动 ---"; cat /sys/devices/platform/soc/soc:pwm-fan/waiting_for_supplier 2>/dev/null
echo "--- CPU温度 ---"; cat /sys/class/thermal/thermal_zone40/temp 2>/dev/null
echo "--- 最热 ---"
for i in $(seq 0 77); do
  t=$(cat /sys/class/thermal/thermal_zone$i/temp 2>/dev/null)
  n=$(cat /sys/class/thermal/thermal_zone$i/type 2>/dev/null)
  [ -n "$t" ] && [ "$t" -gt 60000 ] 2>/dev/null && echo "$n=$t"
done
