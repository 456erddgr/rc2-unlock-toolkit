#!/system/bin/sh
# 设备信息收集
getprop ro.product.model; getprop ro.build.version.release
getprop ro.build.version.sdk; getprop ro.product.cpu.abi
getprop persist.dji.zygote_policy
echo "--- 内存 ---"; grep -E 'MemTotal|MemAvailable|SwapTotal' /proc/meminfo
echo "--- swap ---"; cat /proc/swaps
echo "--- 电量 ---"; cat /sys/class/power_supply/aprimary-bat/capacity
echo "--- 分区 ---"; ls /dev/block/by-name/ | tr '\n' ' '
