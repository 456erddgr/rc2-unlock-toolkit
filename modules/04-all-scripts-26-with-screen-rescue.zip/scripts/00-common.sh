#!/system/bin/sh
# RC2 PC Toolbox 公共函数
ADB=/debug_ramdisk/su
SU="/debug_ramdisk/su -c"
log() { echo "[$(date '+%H:%M:%S')] $*"; }
bye() { echo "BYE:$1"; exit 0; }
