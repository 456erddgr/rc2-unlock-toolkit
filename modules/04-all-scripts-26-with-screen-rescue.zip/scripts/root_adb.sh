#!/system/bin/sh
setprop service.adb.root 1
stop adbd; sleep 1; start adbd
sleep 2
getprop service.adb.root
id
