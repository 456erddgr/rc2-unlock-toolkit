#!/system/bin/sh
echo "=== 设备 ==="
getprop ro.product.model; getprop ro.build.version.release
getprop ro.product.cpu.abi; getprop persist.dji.zygote_policy
echo "=== 内存 ==="; grep -E 'MemTotal|MemAvailable' /proc/meminfo
echo "=== swap ==="; cat /proc/swaps
echo "=== 电池 ==="; cat /sys/class/power_supply/aprimary-bat/capacity
echo "=== 温度 ==="; cat /sys/class/thermal/thermal_zone40/temp
echo "=== CPU ==="; cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo "=== 分区数 ==="; ls /dev/block/by-name/ | wc -l
