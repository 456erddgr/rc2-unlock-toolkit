#!/system/bin/sh
echo "=== 1. 系统基础 ==="
getprop ro.product.model
getprop ro.build.version.release
getprop ro.debuggable
getprop persist.dji.zygote_policy
getprop init.svc.zygote
getprop init.svc.zygote_secondary
echo "=== 2. 内存 ==="
grep -E 'MemTotal|MemAvailable|SwapTotal|SwapFree|SwapCached' /proc/meminfo
echo "=== 3. /data 空间 ==="
df -h /data 2>&1 | tail -n 2
echo "=== 4. su ==="
ls -l /debug_ramdisk/su 2>&1
echo "=== 5. Magisk 模块 ==="
ls /data/adb/modules/ 2>&1
echo "=== 6. 已装相关包 ==="
pm list packages 2>&1 | grep -E 'rc2|dji|toolbox|volkey'
echo "=== 7. toolbox 版本 ==="
dumpsys package com.rc2.toolbox 2>&1 | grep -E 'versionName|versionCode'
echo "=== 8. 禁用的 DJI 包 ==="
pm list packages -d 2>&1 | grep -i dji
echo "=== 9. swap 现状 ==="
cat /proc/swaps 2>&1
echo "=== 10. 风扇 PWM ==="
ls /sys/class/pwm/pwmchip0/ 2>&1
if [ -d /sys/class/pwm/pwmchip0/pwm3 ]; then
  echo "pwm3: period=$(cat /sys/class/pwm/pwmchip0/pwm3/period 2>&1) duty=$(cat /sys/class/pwm/pwmchip0/pwm3/duty_cycle 2>&1) enable=$(cat /sys/class/pwm/pwmchip0/pwm3/enable 2>&1)"
else
  echo "pwm3 未导出"
fi
echo "=== 11. 模块 swap 目录 ==="
ls -la /data/adb/modules/rc2_swapfile/ 2>&1
cat /data/adb/modules/rc2_swapfile/size_mb 2>&1
echo "=== 12. 工具链文件（设备侧）==="
ls -la /data/local/tmp/ 2>&1 | head -20
echo "=== DONE ==="
