#!/system/bin/sh
MAG=/debug_ramdisk/magisk
echo "=== 当前 policies ==="
$MAG --sqlite "SELECT uid,package_name,policy,until FROM policies;"
echo "=== 插入工具箱授权 (uid 10040 com.rc2.toolbox, policy=2 ALLOW) ==="
$MAG --sqlite "INSERT OR REPLACE INTO policies (uid,package_name,policy,until,logging,notification) VALUES (10040,'com.rc2.toolbox',2,0,1,1);"
echo "=== 插入 volkey 授权 (uid 10033) ==="
$MAG --sqlite "INSERT OR REPLACE INTO policies (uid,package_name,policy,until,logging,notification) VALUES (10033,'com.rc2.volkey',2,0,1,1);"
echo "=== 验证 ==="
$MAG --sqlite "SELECT uid,package_name,policy FROM policies;"
echo "=== DONE ==="
