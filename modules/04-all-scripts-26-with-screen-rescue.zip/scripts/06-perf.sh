#!/system/bin/sh
# 超频/性能调节
/debug_ramdisk/su -c "for c in 0 1 2 3 4 5 6 7; do echo performance > /sys/devices/system/cpu/cpu\$c/cpufreq/scaling_governor 2>/dev/null; done"
/debug_ramdisk/su -c "for c in 0 1 2 3 4 5 6 7; do cat /sys/devices/system/cpu/cpu\$c/cpufreq/cpuinfo_max_freq > /sys/devices/system/cpu/cpu\$c/cpufreq/scaling_max_freq 2>/dev/null; done"
/debug_ramdisk/su -c "echo 812000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null"
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
cat /sys/class/kgsl/kgsl-3d0/max_gpuclk
