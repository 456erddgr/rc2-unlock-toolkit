#!/system/bin/sh
# 备份全部关键分区到 /data/local/tmp/rc2backup
OUT=/data/local/tmp/rc2backup
mkdir -p $OUT
for p in boot_a boot_b dji_apk dji_persist persist modem_a modem_b modemst1 modemst2 misc metadata abl_a xbl_a vbmeta_a; do
  /debug_ramdisk/su -c "dd if=/dev/block/by-name/$p of=$OUT/$p.img bs=1M 2>/dev/null"
  /debug_ramdisk/su -c "ls -l $OUT/$p.img 2>/dev/null | awk '{print \$5, \$9}'"
done
echo "备份完成: $OUT"
