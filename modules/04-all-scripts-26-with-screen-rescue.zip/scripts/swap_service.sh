#!/system/bin/sh
# ============================================================
# service.sh — 开机启用磁盘 swap（v2.1，2026-10-31）
#
# v2.1 修复（实锤 2026-10-31 开机日志）:
#   * swapon 必须用绝对路径 /system/bin/swapon（toybox，支持 -p PRIORITY）。
#     Magisk 模块启动环境 PATH 里 swapon 是 BusyBox v1.36.1.1，
#     不支持 -p → "swapon: invalid option -- p" → 开机必失败。
#   * swapon stderr 捕获 ERR 记入日志；有界重试 3 次。
#   * 大小校验用 expr（64 位），规避 toybox sh 32 位算术溢出。
# ============================================================
MODDIR=${0%/*}
SWAPFILE=/data/local/rc2_swapfile
LOG=/data/local/tmp/rc2_swap.log
PRIORITY=10

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG"; }

log "=== swap service 启动 (v2.1) ==="

# 等系统稳定（固定等待）
sleep 60

# 用户关闭开关检查
if [ -f "$MODDIR/disable" ]; then
    log "检测到 disable 标记，跳过启用"
    exit 0
fi

SIZE_MB=$(cat "$MODDIR/size_mb" 2>/dev/null)
[ -z "$SIZE_MB" ] && SIZE_MB=2048
log "配置容量=${SIZE_MB}MB"

if grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
    log "swap 已在运行，跳过"
    exit 0
fi

# 大小校验（expr 64 位）
WANT_B=$(expr "$SIZE_MB" '*' 1048576)
CUR_B=$(stat -c %s "$SWAPFILE" 2>/dev/null || echo 0)
NEED_CREATE=1
if [ "$CUR_B" = "$WANT_B" ]; then
    NEED_CREATE=0
fi

if [ "$NEED_CREATE" = "1" ]; then
    log "创建 ${SIZE_MB}MB swap 文件（现有 ${CUR_B}B）"
    rm -f "$SWAPFILE"
    # 分块 dd + sync：f2fs 上 fallocate 后 swapon 报 Invalid argument；
    # 一次性 dd 2GB 挤爆 1.7GB 内存 → watchdog 重启（严重事故，禁止）
    BLK=256; N=$((SIZE_MB / BLK)); R=$((SIZE_MB % BLK))
    if [ "$R" -gt 0 ]; then N=$((N + 1)); fi
    dd if=/dev/zero of="$SWAPFILE" bs=${BLK}M count=1 2>/dev/null
    sync
    i=2
    while [ "$i" -le "$N" ]; do
        dd if=/dev/zero of="$SWAPFILE" bs=${BLK}M count=1 conv=notrunc seek=$((i-1)) 2>/dev/null
        sync
        i=$((i+1))
    done
    if [ ! -s "$SWAPFILE" ]; then
        log "创建失败，放弃"
        exit 0
    fi
    mkswap "$SWAPFILE" >/dev/null 2>&1
    log "文件已创建并 mkswap"
fi

# swapon（toybox 绝对路径）+ 错误捕获 + 有界重试
OK=0
for try in 1 2 3; do
    ERR=$(/system/bin/swapon -p "$PRIORITY" "$SWAPFILE" 2>&1)
    if grep -q rc2_swapfile /proc/swaps 2>/dev/null; then
        OK=1
        break
    fi
    log "swapon 尝试 $try 失败: $ERR"
    sleep 5
done

if [ "$OK" = "1" ]; then
    log "启用成功 (优先级 $PRIORITY)"
    echo 60 > /proc/sys/vm/swappiness 2>/dev/null
    log "swappiness 设为 60"
else
    log "启用失败（3 次重试）"
fi
log "=== 完成 ==="
log "swap 状态: $(cat /proc/swaps | tail -n +2 | tr '\n' ' ')"
exit 0
