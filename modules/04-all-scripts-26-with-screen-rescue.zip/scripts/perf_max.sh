#!/system/bin/sh
# CPU 各簇拉满 + GPU 满频
for c in 0 1 2 3 4 5 6 7; do
  echo performance > /sys/devices/system/cpu/cpu$c/cpufreq/scaling_governor 2>/dev/null
  cat /sys/devices/system/cpu/cpu$c/cpufreq/cpuinfo_max_freq > /sys/devices/system/cpu/cpu$c/cpufreq/scaling_max_freq 2>/dev/null
done
echo 812000000 > /sys/class/kgsl/kgsl-3d0/max_gpuclk 2>/dev/null
for i in 0 1 2 19; do echo 0 > /sys/class/thermal/cooling_device$i/cur_state 2>/dev/null; done
echo "性能已拉满"
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
cat /sys/class/kgsl/kgsl-3d0/max_gpuclk
