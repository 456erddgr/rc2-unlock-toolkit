#!/system/bin/sh
# 分块 dd 生成 2GB 文件 → swapon 兼容性验证
rm -f /data/local/tmp/sbig
S=$(date +%s)
dd if=/dev/zero of=/data/local/tmp/sbig bs=256M count=1 2>/dev/null
sync
i=2
while [ "$i" -le 8 ]; do
  dd if=/dev/zero of=/data/local/tmp/sbig bs=256M count=1 conv=notrunc seek=$((i-1)) 2>/dev/null
  sync
  i=$((i+1))
done
E=$(date +%s)
echo "总耗时=$((E-S))秒"
ls -l /data/local/tmp/sbig
echo "MemAvailable before: $(grep MemAvailable /proc/meminfo)"
mkswap /data/local/tmp/sbig >/dev/null 2>&1
echo "mkswap_exit=$?"
swapon -p 10 /data/local/tmp/sbig 2>&1
echo "swapon_exit=$?"
grep sbig /proc/swaps
echo "MemAvailable after: $(grep MemAvailable /proc/meminfo)"
swapoff /data/local/tmp/sbig 2>/dev/null
rm -f /data/local/tmp/sbig
echo "清理完成"
