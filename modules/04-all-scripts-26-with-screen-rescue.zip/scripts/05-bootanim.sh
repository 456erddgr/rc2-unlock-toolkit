#!/system/bin/sh
# 安装开机动画模块
M=/data/adb/modules/rc2_bootanim
mkdir -p $M/system/product/media
cp /data/local/tmp/bootanimation.zip $M/system/product/media/ 2>/dev/null
printf "id=rc2_bootanim\nname=RC2 Boot Animation\nversion=v1.0\ndescription=PC installed\n" > $M/module.prop
/debug_ramdisk/su -c "chmod 644 $M/system/product/media/bootanimation.zip"
ls -l $M/system/product/media/bootanimation.zip
