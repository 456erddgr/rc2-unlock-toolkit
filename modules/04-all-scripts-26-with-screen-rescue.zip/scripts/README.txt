RC2 全脚本合集 v1.0
===================

脚本全部在 /data/adb/modules/rc2_allscripts/scripts/

用法: sh /data/adb/modules/rc2_allscripts/scripts/<脚本名>

【关键脚本】
all_info.sh        - 全部设备信息
perf_max.sh        - 性能拉满（CPU/GPU/温控）
fix_screen.sh      - 紧急修复黑屏（背光恢复）
fan_check.sh       - 风扇与温度状态
root_adb.sh        - root adb
swapctl.sh         - swap 管理（status/on/off/resize）
swap_service.sh    - swap 开机自启
zygote_service.sh  - 64位 zygote 保活
autogrant_service.sh - 自动授权工具箱 su
rgrant.sh          - Magisk 授权
02-backup.sh       - 备份关键分区
08-restore-dji.sh  - 恢复 dji_apk 分区

【重要提醒】
- pwm3 (pwmchip0) 是屏幕背光，不要 unexport，会黑屏
- 黑屏时跑 fix_screen.sh 恢复
- 只有 dji_apk 分区可安全刷回，其他数据分区刷回会损坏
