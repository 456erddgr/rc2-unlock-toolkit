#!/system/bin/sh
# 风扇状态检查
echo "=== 风扇驱动 ==="
cat /sys/devices/platform/soc/soc:pwm-fan/waiting_for_supplier 2>/dev/null
echo "=== 温度 ==="
cat /sys/class/thermal/thermal_zone40/temp 2>/dev/null
echo "=== 背光（勿改！）==="
cat /sys/class/backlight/panel0-backlight/brightness 2>/dev/null
