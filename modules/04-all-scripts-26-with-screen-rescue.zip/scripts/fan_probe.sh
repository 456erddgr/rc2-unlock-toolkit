#!/system/bin/sh
echo "=== 风扇控制探查 ==="
echo "--- pwmchip0 channel 3（设备树 pwms 引用）---"
ls /sys/class/pwm/pwmchip0/ 2>&1
cat /sys/class/pwm/pwmchip0/npwm 2>&1
echo "--- 尝试 export 3 ---"
echo 3 > /sys/class/pwm/pwmchip0/export 2>&1
echo "export_exit=$?"
sleep 1
ls /sys/class/pwm/pwmchip0/pwm3/ 2>&1
echo "--- 若存在则读参数 ---"
[ -d /sys/class/pwm/pwmchip0/pwm3 ] && { cat /sys/class/pwm/pwmchip0/pwm3/period 2>&1; cat /sys/class/pwm/pwmchip0/pwm3/duty_cycle 2>&1; cat /sys/class/pwm/pwmchip0/pwm3/enable 2>&1; }
echo "--- pwm-fan 设备状态 ---"
cat /sys/devices/platform/soc/soc:pwm-fan/waiting_for_supplier 2>&1
cat /sys/devices/platform/soc/soc:pwm-fan/uevent 2>&1
echo "--- 找 fan 相关 thermal ---"
for d in /sys/class/thermal/thermal_zone*/; do
  n=$(cat $d/type 2>/dev/null)
  case "$n" in *fan*|*Fan*) echo "$d type=$n temp=$(cat $d/temp 2>/dev/null)";; esac
done
