#!/system/bin/sh
# 启用 root adb
setprop service.adb.root 1
stop adbd; start adbd
sleep 2
getprop service.adb.root
