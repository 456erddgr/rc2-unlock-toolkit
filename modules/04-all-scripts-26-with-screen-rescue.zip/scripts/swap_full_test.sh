#!/system/bin/sh
echo "========== 全流程测试 =========="
echo "--- 当前现场 ---"
grep rc2_swapfile /proc/swaps || echo "磁盘swap未启用"
cat /proc/sys/vm/swappiness
echo ""
echo "--- ① 开启 1024MB（分块方式）---"
S=$(date +%s)
sh /data/adb/modules/rc2_swapfile/swapctl.sh resize 1024
E=$(date +%s)
echo "耗时=$((E-S))秒"
echo "--- 验证 ---"
grep rc2_swapfile /proc/swaps
ls -l /data/local/rc2_swapfile
echo "MemAvailable: $(grep MemAvailable /proc/meminfo)"
echo ""
echo "--- ② 改到 2048MB ---"
S=$(date +%s)
sh /data/adb/modules/rc2_swapfile/swapctl.sh resize 2048
E=$(date +%s)
echo "耗时=$((E-S))秒"
grep rc2_swapfile /proc/swaps
ls -l /data/local/rc2_swapfile
echo "MemAvailable: $(grep MemAvailable /proc/meminfo)"
echo ""
echo "--- ③ 关闭 ---"
S=$(date +%s)
sh /data/adb/modules/rc2_swapfile/swapctl.sh off
E=$(date +%s)
echo "耗时=$((E-S))秒"
grep rc2_swapfile /proc/swaps || echo "磁盘swap已关闭"
ls -l /data/local/rc2_swapfile 2>&1 | head -1
echo ""
echo "--- ④ swappiness 测试 ---"
sh /data/adb/modules/rc2_swapfile/swapctl.sh swappiness 60
cat /proc/sys/vm/swappiness
sh /data/adb/modules/rc2_swapfile/swapctl.sh swappiness 100
echo "========== 测试完成 =========="
