#!/system/bin/sh
# 64位 zygote 解锁
/debug_ramdisk/resetprop -n persist.dji.zygote_policy 3 2>/dev/null || setprop persist.dji.zygote_policy 3
getprop persist.dji.zygote_policy
setprop ctl.start zygote
sleep 3
getprop init.svc.zygote; getprop init.svc.zygote_secondary
