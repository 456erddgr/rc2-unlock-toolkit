#!/system/bin/sh
# 紧急修复黑屏（背光恢复满亮度）
echo 3 > /sys/class/pwm/pwmchip0/export 2>/dev/null
sleep 1
echo 1000000 > /sys/class/pwm/pwmchip0/pwm3/period 2>/dev/null
echo 1000000 > /sys/class/pwm/pwmchip0/pwm3/duty_cycle 2>/dev/null
echo 1 > /sys/class/pwm/pwmchip0/pwm3/enable 2>/dev/null
echo 255 > /sys/class/backlight/panel0-backlight/brightness 2>/dev/null
echo "屏幕已恢复（背光满亮度）"
