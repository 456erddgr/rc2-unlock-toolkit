#!/system/bin/sh
# 恢复 dji_apk 分区（DJI Fly 原厂数据）
IMG=/data/local/tmp/rc2backup/dji_apk.img
if [ ! -f "$IMG" ]; then echo "ERR: 无备份 $IMG"; exit 1; fi
/debug_ramdisk/su -c "dd if=$IMG of=/dev/block/by-name/dji_apk bs=1M 2>&1"
echo "dji_apk 恢复完成"
